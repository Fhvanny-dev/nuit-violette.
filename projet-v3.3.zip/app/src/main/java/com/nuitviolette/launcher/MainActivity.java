package com.nuitviolette.launcher;

import android.app.ActivityOptions;
import android.bluetooth.BluetoothAdapter;
import android.content.ContentResolver;
import android.graphics.Rect;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.location.LocationManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.net.TrafficStats;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.BooleanSupplier;

public class MainActivity extends Activity {
    // couches
    private FrameLayout root;
    private SwipeLayout home, drawer, panel;
    // accueil
    private LinearLayout favRow, dockRow;
    private TextView clock, dateTv, greetTv;
    // tiroir
    private GridView grid;
    private ShownAdapter adapter;
    private EditText search;
    private LinearLayout chipRow;
    // panneau
    private ScrollView panelScroll;
    private TextView panelClock, panelDate, dataPill, wifiSub, dataSub, panelGreet, panelGreet2;
    private boolean warnedAcc;
    private Stage stage;
    private View dataOff;
    private ImageView ntA, ntB;
    private SearchPill pill;
    private long lastWeather = 0;
    private LinearLayout bigWifi, bigData;
    private VSlider bright, vol;

    private final List<Apps.App> all = new ArrayList<Apps.App>();
    private final List<Apps.App> shown = new ArrayList<Apps.App>();
    private final List<String> dockPk = new ArrayList<String>();
    private final List<String> favPk = new ArrayList<String>();
    private final List<Tile> tiles = new ArrayList<Tile>();

    private int tab = 0;
    private boolean unlocked, drawerOpen, panelOpen, warnedBright;
    private int topIn, navIn, imeIn;
    private final Handler h = new Handler(Looper.getMainLooper());

    private CameraManager camMgr;
    private String torchId;
    private boolean torchOn;
    private AudioManager audio;

    private BroadcastReceiver pkgRx;
    private BroadcastReceiver pwrRx;
    private ChargeView chargeView;
    private long pendingCharge = 0;
    private boolean resumed = false;

    private static final class Tile {
        ImageView bg;
        BooleanSupplier on;
    }

    private final Runnable tickR = new Runnable() {
        @Override public void run() { tick(); h.postDelayed(this, 15000); }
    };
    private final Runnable reloadR = new Runnable() {
        @Override public void run() { loadApps(); }
    };

    private int dp(float v) { return Ui.dp(this, v); }

    // ====================== cycle de vie ======================
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        initTorch();

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0B0220);
        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.bg_home);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        buildHome();
        buildDrawer();
        buildPanel();
        root.addView(home, new FrameLayout.LayoutParams(-1, -1));
        root.addView(drawer, new FrameLayout.LayoutParams(-1, -1));
        root.addView(panel, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets ins) {
                topIn = ins.getSystemWindowInsetTop();
                navIn = ins.getStableInsetBottom();
                imeIn = ins.getSystemWindowInsetBottom();
                home.setPadding(0, 0, 0, 0);
                panel.setPadding(0, 0, 0, 0);
                drawer.setPadding(0, topIn, 0, imeIn);
                return ins;
            }
        });
        root.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r, int bt, int ol, int ot, int orr, int ob) {
                if ((bt - t) == (ob - ot)) return;
                int H = bt - t;
                if (!drawerOpen) drawer.setTranslationY(H);
                if (!panelOpen) panel.setTranslationY(-H);
            }
        });

        pkgRx = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                h.removeCallbacks(reloadR);
                h.postDelayed(reloadR, 700);
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgRx, f);

        pwrRx = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                if (Intent.ACTION_POWER_CONNECTED.equals(i.getAction())) {
                    if (resumed) showCharge(); else pendingCharge = System.currentTimeMillis();
                } else {
                    pendingCharge = 0;
                    if (chargeView != null) chargeView.dismiss();
                }
            }
        };
        IntentFilter pf = new IntentFilter();
        pf.addAction(Intent.ACTION_POWER_CONNECTED);
        pf.addAction(Intent.ACTION_POWER_DISCONNECTED);
        registerReceiver(pwrRx, pf);

        Toast.makeText(this, "Nuit violette v3.2", Toast.LENGTH_LONG).show();
        loadApps();
        if (getIntent() != null && getIntent().getBooleanExtra("panel", false)) {
            h.postDelayed(new Runnable() { @Override public void run() { openPanel(); } }, 350);
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumed = true;
        if (pendingCharge != 0 && System.currentTimeMillis() - pendingCharge < 15000) showCharge();
        pendingCharge = 0;
        h.removeCallbacks(tickR);
        h.post(tickR);
        if (!warnedAcc && !PullService.enabled(this)) {
            warnedAcc = true;
            Toast.makeText(this, "Active « Nuit violette – volet » dans Accessibilité pour remplacer le volet Android", Toast.LENGTH_LONG).show();
        }
        refreshTiles();
        if (!all.isEmpty()) { refreshHome(); refreshGrid(); }
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumed = false;
        h.removeCallbacks(tickR);
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(pkgRx); } catch (Exception ignored) { }
        try { unregisterReceiver(pwrRx); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (i != null && i.getBooleanExtra("panel", false)) {
            if (drawerOpen) closeDrawer();
            openPanel();
            return;
        }
        if (panelOpen) closePanel();
        if (drawerOpen) closeDrawer();
    }

    @Override
    public void onBackPressed() {
        if (panelOpen) closePanel();
        else if (drawerOpen) closeDrawer();
        // launcher : rien d'autre
    }

    // ====================== animation de charge ======================
    private void showCharge() {
        if (chargeView != null && chargeView.getParent() != null) return;
        chargeView = new ChargeView(this, new Runnable() {
            @Override public void run() { chargeView = null; }
        });
        root.addView(chargeView, new FrameLayout.LayoutParams(-1, -1));
        chargeView.start();
    }

    // ====================== données ======================
    private void loadApps() {
        new Thread(new Runnable() {
            @Override public void run() {
                final List<Apps.App> l = Apps.load(MainActivity.this);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        all.clear();
                        all.addAll(l);
                        refreshHome();
                        refreshGrid();
                    }
                });
            }
        }).start();
    }

    private void launch(Apps.App a) { launchWin(a, false); }

    private void launchWin(final Apps.App a, boolean win) {
        if (win) {
            if (!FloatWin.supported(this)) {
                showWinHelp(a);
                return;
            }
            if (FloatWin.open(this, a)) {
                if (drawerOpen) closeDrawer();
                if (panelOpen) closePanel();
            } else {
                Toast.makeText(this, "Impossible d'ouvrir " + a.label + " en fenêtre", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        try {
            Intent li = new Intent(a.launch);
            if (Build.VERSION.SDK_INT >= 24 && isInMultiWindowMode()) {
                li.addFlags(Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            }
            startActivity(li);
            if (drawerOpen) closeDrawer();
            if (panelOpen) closePanel();
        } catch (Exception e) {
            Toast.makeText(this, "Impossible d'ouvrir " + a.label, Toast.LENGTH_SHORT).show();
        }
    }

    /** Le téléphone n'a pas (encore) les fenêtres libres : propose les 3 solutions, de la meilleure à la plus simple. */
    private void showWinHelp(final Apps.App a) {
        final boolean self = FloatWin.canSelfEnable(this);
        String[] items = {
                self ? "1. Activer les fenêtres libres maintenant" : "1. Activer les fenêtres libres (guide)",
                "2. Écran partagé (marche partout)",
                "Annuler"
        };
        new AlertDialog.Builder(this)
                .setTitle("« " + a.label + " » en fenêtre")
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        if (which == 0) {
                            if (self && FloatWin.selfEnable(MainActivity.this)) {
                                new AlertDialog.Builder(MainActivity.this)
                                        .setTitle("Fenêtres libres activées")
                                        .setMessage("Redémarre le téléphone une seule fois, puis rouvre « " + a.label
                                                + " » en fenêtre : elle s'ouvrira en vraie fenêtre flottante.")
                                        .setPositiveButton("OK", null).show();
                            } else {
                                new AlertDialog.Builder(MainActivity.this)
                                        .setTitle("Activer les fenêtres libres")
                                        .setMessage("Dans « Options pour les développeurs » :\n"
                                                + "• active « Activer les fenêtres de forme libre »\n"
                                                + "• active « Forcer le redimensionnement des activités »\n"
                                                + "• redémarre le téléphone.\n\n"
                                                + "(Si les options développeur sont cachées : Paramètres > À propos du téléphone > "
                                                + "appuie 7 fois sur « Numéro de build ».)\n\n"
                                                + "Astuce : avec un ordinateur, cette commande donne une fois la permission à l'application, "
                                                + "qui active tout toute seule ensuite :\n"
                                                + "adb shell pm grant com.nuitviolette.launcher android.permission.WRITE_SECURE_SETTINGS")
                                        .setPositiveButton("Ouvrir les options développeur", new android.content.DialogInterface.OnClickListener() {
                                            @Override public void onClick(android.content.DialogInterface d2, int w2) {
                                                try { startActivity(new Intent(Settings.ACTION_APPLICATION_DEVELOPMENT_SETTINGS)); }
                                                catch (Exception e) { try { startActivity(new Intent(Settings.ACTION_DEVICE_INFO_SETTINGS)); } catch (Exception ignored) { } }
                                            }
                                        })
                                        .setNegativeButton("Fermer", null).show();
                            }
                        } else if (which == 1) {
                            if (!PullService.enabled(MainActivity.this)) {
                                new AlertDialog.Builder(MainActivity.this)
                                        .setTitle("Autoriser l'écran partagé")
                                        .setMessage("Active « Nuit violette – volet » dans Accessibilité. Ensuite, « " + a.label
                                                + " » s'ouvrira dans la moitié haute de l'écran et tu choisiras l'autre appli dans la moitié basse.")
                                        .setPositiveButton("Ouvrir Accessibilité", new android.content.DialogInterface.OnClickListener() {
                                            @Override public void onClick(android.content.DialogInterface d2, int w2) {
                                                try { startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)); } catch (Exception ignored) { }
                                            }
                                        })
                                        .setNegativeButton("Annuler", null).show();
                            } else if (FloatWin.openSplit(MainActivity.this, a)) {
                                if (drawerOpen) closeDrawer();
                                if (panelOpen) closePanel();
                            } else {
                                Toast.makeText(MainActivity.this, "Impossible d'ouvrir " + a.label + " en fenêtre", Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }).show();
    }

    // ====================== ACCUEIL ======================
    private void buildHome() {
        home = new SwipeLayout(this);
        Stage hs = new Stage(this);
        home.addView(hs, new FrameLayout.LayoutParams(-1, -1));
        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.FIT_XY);
        bg.setImageResource(R.drawable.bg_home);
        hs.add(bg, 0, 0, 100, 100);
        hs.add(new ShootingStars(this), 0, 0, 100, 100);

        // gardés pour la mise à jour, non affichés (comme dans le HTML)
        clock = Ui.text(this, "", 14, Color.WHITE, true);
        dateTv = Ui.text(this, "", 14, Ui.LIGHT, false);
        greetTv = Ui.text(this, "", 14, Color.WHITE, false);

        // le chat sur son nuage, au même endroit que dans le HTML
        hs.add(new CatView(this), 73.96f, 23.797f, 26.04f, 9.251f);

        favRow = hs.add(new LinearLayout(this), 5f, 59.2f, 90f, 11f);
        favRow.setOrientation(LinearLayout.HORIZONTAL);

        // grande barre (image 2) : météo | Rechercher ✦ | jour — entièrement dessinée
        pill = new SearchPill(this);
        pill.setOnSearch(new SearchPill.OnSearch() {
            @Override public void go() { openDrawer(true); }
        });
        hs.add(pill, 9f, 72.2f, 82f, 5.3f);

        dockRow = hs.add(new LinearLayout(this), 5f, 84.2f, 90f, 9.5f);
        dockRow.setOrientation(LinearLayout.HORIZONTAL);

        TextView gear = Ui.text(this, "⚙", 20, Ui.LIGHT, false);
        gear.setGravity(Gravity.CENTER);
        gear.setBackground(Ui.glass(this, 25, 0x66200A4A, 0xCC9B5CFF));
        gear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, HubActivity.class)); }
        });
        hs.add(gear, 88f, 5.5f, 8f, 3.6f);

        home.setListener(new SwipeLayout.L() {
            @Override public boolean canUp() { return !drawerOpen && !panelOpen; }
            @Override public boolean canDown() { return !drawerOpen && !panelOpen; }
            @Override public void onUp() { openDrawer(false); }
            @Override public void onDown() { openPanel(); }
        });
    }

    private void tick() {
        Date now = new Date();
        int hr = Integer.parseInt(new SimpleDateFormat("H", Locale.getDefault()).format(now));
        String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(now);
        String d = new SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(now);
        if (!d.isEmpty()) d = Character.toUpperCase(d.charAt(0)) + d.substring(1);
        clock.setText(time);
        if (pill != null) {
            pill.setDay(String.valueOf(Integer.parseInt(new SimpleDateFormat("d", Locale.getDefault()).format(now))));
            if (System.currentTimeMillis() - lastWeather > 60000) {
                lastWeather = System.currentTimeMillis();
                Weather.refresh(this, new Weather.Cb() {
                    @Override public void on(String t, int code, boolean night) { if (pill != null) pill.setWeather(t, code, night); }
                });
            }
        }
        dateTv.setText(d);
        panelClock.setText(time);
        panelDate.setText(d);
        String[] gg = hr >= 6 && hr < 12 ? new String[]{"Bonjour", "Belle journée ♡"}
                : hr >= 12 && hr < 18 ? new String[]{"Bon après-midi", "Profite bien ♡"}
                : hr >= 18 && hr < 22 ? new String[]{"Bonne soirée", "Détends-toi ♡"}
                : new String[]{"Bonne nuit", "Rêve bien ♡"};
        greetTv.setText(gg[0]);
        boolean nightNow = hr >= 22 || hr < 6;
        panelGreet.setText(gg[0].replace(" ", "\n"));
        stage.setCq(panelGreet, gg[0].equals("Bonjour") ? 8.2f : (gg[0].equals("Bon après-midi") ? 5.8f : 7.2f));
        panelGreet2.setText(gg[1]);
        panelGreet.setVisibility(nightNow ? View.GONE : View.VISIBLE);
        panelGreet2.setVisibility(nightNow ? View.GONE : View.VISIBLE);
        ntA.setVisibility(nightNow ? View.VISIBLE : View.GONE);
        ntB.setVisibility(nightNow ? View.VISIBLE : View.GONE);
        refreshDataPill();
    }

    private List<String> dockDefaults() {
        List<String> l = new ArrayList<String>();
        addRes(l, new Intent(Intent.ACTION_DIAL));
        try {
            String sms = android.provider.Telephony.Sms.getDefaultSmsPackage(this);
            if (sms != null) l.add(sms);
        } catch (Exception ignored) { }
        addRes(l, new Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")).addCategory(Intent.CATEGORY_BROWSABLE));
        addRes(l, new Intent(MediaStore.ACTION_IMAGE_CAPTURE));
        return l;
    }

    private void addRes(List<String> l, Intent i) {
        ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        if (ri != null && ri.activityInfo != null && !"android".equals(ri.activityInfo.packageName)) {
            l.add(ri.activityInfo.packageName);
        }
    }

    private List<Apps.App> resolve(String key, int n, List<String> defaults, Set<String> hid, Set<String> exclude) {
        List<String> pk = Prefs.getList(this, key);
        if (pk.isEmpty()) pk = defaults;
        List<Apps.App> out = new ArrayList<Apps.App>();
        Set<String> used = new HashSet<String>(exclude);
        for (String p : pk) {
            if (out.size() >= n) break;
            if (hid.contains(p) || used.contains(p)) continue;
            for (Apps.App a : all) {
                if (a.pkg.equals(p)) { out.add(a); used.add(p); break; }
            }
        }
        for (Apps.App a : all) {
            if (out.size() >= n) break;
            if (hid.contains(a.pkg) || used.contains(a.pkg)) continue;
            out.add(a);
            used.add(a.pkg);
        }
        return out;
    }

    private void refreshHome() {
        favRow.removeAllViews();
        dockRow.removeAllViews();
        Set<String> hid = Prefs.getSet(this, Prefs.HIDDEN);
        List<Apps.App> dock = resolve(Prefs.DOCK, 4, dockDefaults(), hid, new HashSet<String>());
        Set<String> ex = new HashSet<String>();
        for (Apps.App a : dock) ex.add(a.pkg);
        List<String> favDef = new ArrayList<String>();
        favDef.add("com.android.vending");
        favDef.add("com.google.android.apps.maps");
        favDef.add("com.google.android.gm");
        favDef.add("com.google.android.youtube");
        List<Apps.App> fav = resolve(Prefs.FAV, 4, favDef, hid, ex);
        dockPk.clear();
        favPk.clear();
        for (Apps.App a : fav) { favPk.add(a.pkg); favRow.addView(cell(a, true, 62), new LinearLayout.LayoutParams(0, -2, 1f)); }
        for (Apps.App a : dock) { dockPk.add(a.pkg); dockRow.addView(cell(a, false, 62), new LinearLayout.LayoutParams(0, -2, 1f)); }
    }

    private View cell(final Apps.App a, boolean label, int size) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView iv = new ImageView(this);
        iv.setImageBitmap(a.bmp);
        c.addView(iv, new LinearLayout.LayoutParams(dp(size), dp(size)));
        if (label) {
            TextView t = Ui.text(this, a.label, 11, Color.WHITE, false);
            t.setSingleLine(true);
            t.setEllipsize(TextUtils.TruncateAt.END);
            t.setGravity(Gravity.CENTER);
            Ui.glow(t, 0xFF000000, 3);
            c.addView(t, new LinearLayout.LayoutParams(-1, -2));
        }
        c.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { launch(a); }
        });
        c.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { appMenu(a); return true; }
        });
        return c;
    }

    // ====================== TIROIR ======================
    private void buildDrawer() {
        drawer = new SwipeLayout(this);
        drawer.setBackgroundColor(0xFF12042B);
        ImageView bgd = new ImageView(this);
        bgd.setScaleType(ImageView.ScaleType.CENTER_CROP);
        bgd.setImageResource(R.drawable.bg_drawer);
        drawer.addView(bgd, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout dc = new LinearLayout(this);
        dc.setOrientation(LinearLayout.VERTICAL);
        drawer.addView(dc, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout hw = new FrameLayout(this);
        View bar = new View(this);
        bar.setBackground(Ui.glass(this, 3, 0x88FFFFFF, 0x00000000));
        hw.addView(bar, new FrameLayout.LayoutParams(dp(44), dp(5), Gravity.CENTER));
        hw.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeDrawer(); }
        });
        dc.addView(hw, new LinearLayout.LayoutParams(-1, dp(32)));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(chipRow);
        String[] names = {"Tout ♡", "Social", "Médias", "Productivité", "Jeux", "🔒 Masquées"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView chip = Ui.text(this, names[i], 14, Color.WHITE, true);
            chip.setPadding(dp(18), dp(9), dp(18), dp(9));
            chip.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD_ITALIC));
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { selectTab(idx); }
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
            cp.setMargins(0, 0, dp(8), 0);
            chipRow.addView(chip, cp);
        }
        updateChips();
        LinearLayout.LayoutParams hsp = new LinearLayout.LayoutParams(-1, -2);
        hsp.setMargins(dp(16), 0, dp(16), dp(8));
        dc.addView(hs, hsp);

        grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setVerticalSpacing(dp(14));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(new ColorDrawable(0));
        grid.setPadding(dp(8), dp(8), dp(8), dp(8));
        grid.setClipToPadding(false);
        grid.setVerticalScrollBarEnabled(false);
        grid.setOverScrollMode(View.OVER_SCROLL_NEVER);
        adapter = new ShownAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                if (pos >= 0 && pos < shown.size()) launch(shown.get(pos));
            }
        });
        grid.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {
            @Override public boolean onItemLongClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                if (pos >= 0 && pos < shown.size()) appMenu(shown.get(pos));
                return true;
            }
        });
        dc.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1f));

        search = new EditText(this);
        search.setHint("Rechercher");
        search.setHintTextColor(0x99E9D5FF);
        search.setTextColor(Color.WHITE);
        search.setTextSize(16);
        search.setSingleLine(true);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setPadding(dp(20), 0, dp(20), 0);
        search.setBackground(Ui.grad(this, 26, 0xBB7A2BE8, 0xBB3A1380, 0xFFE2C4FF));
        search.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.ITALIC));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { refreshGrid(); }
        });
        search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int a, android.view.KeyEvent e) {
                if (!shown.isEmpty()) launch(shown.get(0));
                return true;
            }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(50));
        sp.setMargins(dp(16), dp(8), dp(16), dp(12));
        dc.addView(search, sp);

        drawer.setListener(new SwipeLayout.L() {
            @Override public boolean canUp() { return false; }
            @Override public boolean canDown() { return drawerOpen && gridAtTop(); }
            @Override public void onUp() { }
            @Override public void onDown() { closeDrawer(); }
        });
    }

    private boolean gridAtTop() {
        return grid.getFirstVisiblePosition() == 0
                && (grid.getChildCount() == 0 || grid.getChildAt(0).getTop() >= grid.getPaddingTop());
    }

    private void selectTab(final int i) {
        if (i == 5 && !unlocked) {
            Pin.ask(this, new Runnable() {
                @Override public void run() {
                    unlocked = true;
                    tab = 5;
                    updateChips();
                    refreshGrid();
                }
            });
            return;
        }
        tab = i;
        updateChips();
        refreshGrid();
    }

    private void updateChips() {
        for (int i = 0; i < chipRow.getChildCount(); i++) {
            TextView t = (TextView) chipRow.getChildAt(i);
            t.setBackground(i == tab
                    ? Ui.grad(this, 24, 0xFF8A3DF0, 0xFF4A16B0, 0xFFF3E6FF)
                    : Ui.glass(this, 24, 0x66200A4A, 0xCC9B5CFF));
        }
    }

    private void refreshGrid() {
        if (search == null || adapter == null) return;
        String q = search.getText().toString().trim().toLowerCase();
        Set<String> hid = Prefs.getSet(this, Prefs.HIDDEN);
        shown.clear();
        for (Apps.App a : all) {
            boolean isH = hid.contains(a.pkg);
            if (tab == 5) {
                if (!isH || !unlocked) continue;
            } else {
                if (isH) continue;
                if (!Apps.inTab(a, tab)) continue;
            }
            if (!q.isEmpty() && !a.label.toLowerCase().contains(q)) continue;
            shown.add(a);
        }
        adapter.notifyDataSetChanged();
    }

    private final class ShownAdapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int i) { return shown.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View cv, ViewGroup parent) {
            LinearLayout c;
            if (cv == null) {
                c = new LinearLayout(MainActivity.this);
                c.setOrientation(LinearLayout.VERTICAL);
                c.setGravity(Gravity.CENTER_HORIZONTAL);
                ImageView iv = new ImageView(MainActivity.this);
                c.addView(iv, new LinearLayout.LayoutParams(dp(64), dp(64)));
                TextView t = Ui.text(MainActivity.this, "", 11, Color.WHITE, false);
                t.setSingleLine(true);
                t.setEllipsize(TextUtils.TruncateAt.END);
                t.setGravity(Gravity.CENTER);
                Ui.glow(t, 0xFF000000, 3);
                c.addView(t, new LinearLayout.LayoutParams(-1, -2));
            } else {
                c = (LinearLayout) cv;
            }
            Apps.App a = shown.get(i);
            ((ImageView) c.getChildAt(0)).setImageBitmap(a.bmp);
            ((TextView) c.getChildAt(1)).setText(a.label);
            return c;
        }
    }

    private void openDrawer(boolean focusSearch) {
        if (drawerOpen) return;
        drawerOpen = true;
        refreshGrid();
        drawer.animate().translationY(0).setDuration(300).setInterpolator(new DecelerateInterpolator()).start();
        home.animate().alpha(0.25f).setDuration(300).start();
        if (focusSearch) {
            h.postDelayed(new Runnable() {
                @Override public void run() {
                    search.requestFocus();
                    InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (im != null) im.showSoftInput(search, 0);
                }
            }, 320);
        }
    }

    private void closeDrawer() {
        if (!drawerOpen) return;
        drawerOpen = false;
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(search.getWindowToken(), 0);
        drawer.animate().translationY(root.getHeight()).setDuration(260)
                .setInterpolator(new AccelerateInterpolator()).start();
        home.animate().alpha(1f).setDuration(260).start();
        search.setText("");
        search.clearFocus();
        tab = 0;
        unlocked = false;
        updateChips();
        refreshGrid();
    }

    // ---------- menu appui long ----------
    private void appMenu(final Apps.App a) {
        final boolean isH = Prefs.getSet(this, Prefs.HIDDEN).contains(a.pkg);
        String[] items = {
                isH ? "Ne plus masquer" : "Masquer l'application",
                "Mettre dans le dock",
                "Épingler à l'accueil",
                "Contrôle des données…",
                "Infos de l'application",
                "Désinstaller",
                "Ouvrir en fenêtre"};
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(a.label)
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        switch (which) {
                            case 0:
                                Pin.ask(MainActivity.this, new Runnable() {
                                    @Override public void run() {
                                        Prefs.toggle(MainActivity.this, Prefs.HIDDEN, a.pkg);
                                        refreshHome();
                                        refreshGrid();
                                    }
                                });
                                break;
                            case 1: pinTo(Prefs.DOCK, a.pkg); break;
                            case 2: pinTo(Prefs.FAV, a.pkg); break;
                            case 3: startActivity(new Intent(MainActivity.this, DataActivity.class)); break;
                            case 4:
                                try {
                                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                            Uri.parse("package:" + a.pkg)));
                                } catch (Exception ignored) { }
                                break;
                            case 6: launchWin(a, true); break;
                            default:
                                try {
                                    startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)));
                                } catch (Exception ignored) { }
                                break;
                        }
                    }
                }).show();
    }

    private void pinTo(String key, String pkg) {
        List<String> cur = new ArrayList<String>(Prefs.getList(this, key));
        if (cur.isEmpty()) cur.addAll(key.equals(Prefs.DOCK) ? dockPk : favPk);
        String other = key.equals(Prefs.DOCK) ? Prefs.FAV : Prefs.DOCK;
        List<String> o = new ArrayList<String>(Prefs.getList(this, other));
        if (o.isEmpty()) o.addAll(key.equals(Prefs.DOCK) ? favPk : dockPk);
        o.remove(pkg);
        cur.remove(pkg);
        cur.add(0, pkg);
        while (cur.size() > 4) cur.remove(cur.size() - 1);
        Prefs.putList(this, key, cur);
        Prefs.putList(this, other, o);
        refreshHome();
        Toast.makeText(this, "C'est fait ♡", Toast.LENGTH_SHORT).show();
    }

    // ====================== PANNEAU RAPIDE ======================
    private void buildPanel() {
        panel = new SwipeLayout(this);
        panel.setBackgroundColor(0xFF12042B);
        stage = new Stage(this);
        panel.addView(stage, new FrameLayout.LayoutParams(-1, -1));

        ImageView pbg = new ImageView(this);
        pbg.setScaleType(ImageView.ScaleType.FIT_XY);
        pbg.setImageResource(R.drawable.bg_panel);
        stage.add(pbg, 0, 0, 100, 100);

        panelClock = Ui.text(this, "", 12, Color.WHITE, true);
        Ui.glow(panelClock, Ui.GLOW, 9);
        stage.text(panelClock, 8.799f, 10.588f, 11.8f);
        panelDate = Ui.text(this, "", 12, Ui.LIGHT, false);
        Ui.glow(panelDate, Ui.GLOW, 6);
        stage.text(panelDate, 9.75f, 16.791f, 5.2f);

        // salutations (image de nuit la nuit, texte cursif le jour)
        ntA = new ImageView(this);
        ntA.setImageResource(R.drawable.nt_a);
        ntA.setScaleType(ImageView.ScaleType.FIT_XY);
        stage.add(ntA, 54.102f, 16.31f, 19.025f, 6.15f);
        panelGreet = Ui.text(this, "", 12, Color.WHITE, false);
        panelGreet.setTypeface(Typeface.create("cursive", Typeface.ITALIC));
        panelGreet.setGravity(Gravity.CENTER);
        panelGreet.setRotation(-4);
        Ui.glow(panelGreet, Ui.GLOW, 9);
        stage.box(panelGreet, 54.102f, 16.31f, 19.025f, 6.417f, 7.2f);
        ntB = new ImageView(this);
        ntB.setImageResource(R.drawable.nt_b);
        ntB.setScaleType(ImageView.ScaleType.FIT_XY);
        stage.add(ntB, 59.453f, 84.759f, 35.077f, 6.417f);
        panelGreet2 = Ui.text(this, "", 12, Color.WHITE, false);
        panelGreet2.setTypeface(Typeface.create("cursive", Typeface.ITALIC));
        panelGreet2.setGravity(Gravity.CENTER);
        Ui.glow(panelGreet2, Ui.GLOW, 9);
        stage.box(panelGreet2, 55.886f, 84.759f, 40.428f, 6.417f, 6.6f);

        // pastille données mobiles
        dataPill = Ui.text(this, "", 12, Ui.LIGHT, false);
        dataPill.setGravity(Gravity.CENTER);
        dataPill.setSingleLine(true);
        dataPill.setBackground(Ui.glass(this, 20, 0xFF1D0242, 0xFF9B5CFF));
        dataPill.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, DataActivity.class)); closePanel(); }
        });
        stage.box(dataPill, 8.4f, 25.9f, 83.2f, 4.4f, 3.9f);

        // Wi-Fi et Données (zones tactiles sur l'image)
        View wifi = new View(this);
        wifi.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                openSettings(Build.VERSION.SDK_INT >= 30 ? new Intent(Settings.Panel.ACTION_WIFI)
                        : new Intent(Settings.ACTION_WIFI_SETTINGS));
            }
        });
        stage.add(wifi, 8.68f, 31.925f, 42.093f, 8.556f);
        dataOff = new View(this);
        dataOff.setBackground(Ui.glass(this, 26, 0xC2100424, 0x00000000));
        stage.add(dataOff, 8.68f, 41.711f, 42.093f, 8.556f);
        View data = new View(this);
        data.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openMobileData(); }
        });
        data.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { startActivity(new Intent(MainActivity.this, DataActivity.class)); closePanel(); return true; }
        });
        stage.add(data, 8.68f, 41.711f, 42.093f, 8.556f);

        // curseurs
        bright = new VSlider(this, 0);
        bright.setOnChange(new VSlider.OnChange() { @Override public void on(float v) { setBrightness(v); } });
        stage.add(bright, 55.291f, 31.925f, 14.982f, 18.503f);
        vol = new VSlider(this, 1);
        vol.setOnChange(new VSlider.OnChange() {
            @Override public void on(float v) {
                int max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(v * max), 0);
            }
        });
        stage.add(vol, 76.219f, 31.925f, 14.982f, 18.503f);

        // tuiles : mêmes emplacements que le HTML
        final float[] X = {8.799f, 31.510f, 53.864f, 75.624f};
        final float[] Y = {51.979f, 59.786f, 67.540f, 75.294f};
        final MainActivity me = this;
        slot(X[0], Y[0], R.drawable.ic_bt, new BooleanSupplier() {
            @Override public boolean getAsBoolean() {
                try { BluetoothAdapter ba = BluetoothAdapter.getDefaultAdapter(); return ba != null && ba.isEnabled(); } catch (Exception e) { return false; }
            }
        }, new Runnable() { @Override public void run() { openSettings(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); } });
        slot(X[1], Y[0], R.drawable.ic_torch, new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return torchOn; }
        }, new Runnable() { @Override public void run() { toggleTorch(); } });
        slot(X[2], Y[0], R.drawable.ic_plane, new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return Settings.Global.getInt(getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) == 1; }
        }, new Runnable() { @Override public void run() { openSettings(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); } });
        slot(X[3], Y[0], R.drawable.ic_vib, new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return audio.getRingerMode() == AudioManager.RINGER_MODE_VIBRATE; }
        }, new Runnable() { @Override public void run() { toggleVibrate(); } });

        slot(X[0], Y[1], R.drawable.ic_rot, new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return Settings.System.getInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 0) == 1; }
        }, new Runnable() { @Override public void run() { toggleRotation(); } });
        slot(X[1], Y[1], R.drawable.ic_loc, new BooleanSupplier() {
            @Override public boolean getAsBoolean() {
                try { LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE); return Build.VERSION.SDK_INT >= 28 && lm.isLocationEnabled(); }
                catch (Exception e) { return false; }
            }
        }, new Runnable() { @Override public void run() { openSettings(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); } });
        slot(X[2], Y[1], R.drawable.ic_sync, new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return ContentResolver.getMasterSyncAutomatically(); }
        }, new Runnable() { @Override public void run() {
            try { ContentResolver.setMasterSyncAutomatically(!ContentResolver.getMasterSyncAutomatically()); }
            catch (Exception e) { openSettings(new Intent(Settings.ACTION_SYNC_SETTINGS)); }
        } });
        slot(X[3], Y[1], R.drawable.ic_moon, new BooleanSupplier() {
            @Override public boolean getAsBoolean() {
                return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES;
            }
        }, new Runnable() { @Override public void run() { openSettings(new Intent(Settings.ACTION_DISPLAY_SETTINGS)); } });

        slot(X[0], Y[2], R.drawable.ic_shot, new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return false; }
        }, new Runnable() { @Override public void run() { openSettings(new Intent(Settings.ACTION_CAST_SETTINGS)); } });
        slot(X[1], Y[2], R.drawable.ic_dnd, new BooleanSupplier() {
            @Override public boolean getAsBoolean() {
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                return nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL
                        && nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_UNKNOWN;
            }
        }, new Runnable() { @Override public void run() { toggleDnd(); } });
        slot(X[2], Y[2], R.drawable.ic_eye, new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return Prefs.bool(me, Prefs.FW_ON, false); }
        }, new Runnable() { @Override public void run() { toggleFirewall(); } });
        slot(X[3], Y[2], R.drawable.ic_contrast, new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return Prefs.bool(me, Prefs.POP, true); }
        }, new Runnable() { @Override public void run() {
            Prefs.sp(me).edit().putBoolean(Prefs.POP, !Prefs.bool(me, Prefs.POP, true)).apply();
            refreshTiles();
        } });

        slot(X[1], Y[3], R.drawable.ic_qr, new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return false; }
        }, new Runnable() { @Override public void run() { openSettings(new Intent("android.media.action.STILL_IMAGE_CAMERA")); } });
        slot(X[2], Y[3], R.drawable.ic_device, new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return false; }
        }, new Runnable() { @Override public void run() { startActivity(new Intent(me, HubActivity.class)); closePanel(); } });
        slot(X[3], Y[3], R.drawable.ic_hot, new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return false; }
        }, new Runnable() { @Override public void run() { openTether(); } });

        View chev = new View(this);
        chev.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { closePanel(); } });
        stage.add(chev, 45.184f, 93.048f, 14.269f, 4.813f);

        panel.setListener(new SwipeLayout.L() {
            @Override public boolean canUp() { return panelOpen; }
            @Override public boolean canDown() { return false; }
            @Override public void onUp() { closePanel(); }
            @Override public void onDown() { }
        });
    }

    private void slot(float x, float y, int icon, BooleanSupplier on, final Runnable click) {
        final FrameLayout f = new FrameLayout(this);
        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.FIT_XY);
        bg.setImageResource(R.drawable.tile_off);
        f.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        final ImageView ic = new ImageView(this);
        ic.setScaleType(ImageView.ScaleType.FIT_XY);
        ic.setImageResource(icon);
        f.addView(ic, new FrameLayout.LayoutParams(-1, -1));
        f.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r, int b, int ol, int ot, int orr, int ob) {
                int w = r - l, hh = b - t;
                ic.setPadding(Math.round(w * .1486f), Math.round(hh * .171f), Math.round(w * .1486f), Math.round(hh * .171f));
            }
        });
        f.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                click.run();
                h.postDelayed(new Runnable() { @Override public void run() { refreshTiles(); } }, 250);
            }
        });
        stage.add(f, x, y, 17.598f, 6.257f);
        Tile tl = new Tile();
        tl.bg = bg;
        tl.on = on;
        tiles.add(tl);
    }

    private LinearLayout tileRow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(12), 0, 0);
        r.setLayoutParams(lp);
        return r;
    }

    private LinearLayout bigTile(View glyph, String title, TextView sub, final Runnable click) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.HORIZONTAL);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(14), dp(8), dp(10), dp(8));
        t.setBackground(Ui.glass(this, 26, 0x55200A4A, 0x889B5CFF));
        t.addView(glyph, new LinearLayout.LayoutParams(dp(34), dp(34)));
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        TextView tt = Ui.text(this, title, 14.5f, Color.WHITE, true);
        tt.setSingleLine(true);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        tx.addView(tt);
        sub.setSingleLine(true);
        sub.setEllipsize(TextUtils.TruncateAt.END);
        tx.addView(sub);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(10), 0, 0, 0);
        t.addView(tx, lp);
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { click.run(); }
        });
        return t;
    }

    private View tile(int icon, String label, BooleanSupplier on, final Runnable click) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));

        FrameLayout f = new FrameLayout(this);
        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.FIT_XY);
        bg.setImageResource(R.drawable.tile_off);
        f.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        ImageView ic = new ImageView(this);
        ic.setImageResource(icon);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER);
        f.addView(ic, ip);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(58));
        fp.setMargins(dp(5), 0, dp(5), 0);
        c.addView(f, fp);

        TextView t = Ui.text(this, label, 10.5f, Ui.LIGHT, false);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        c.addView(t, new LinearLayout.LayoutParams(-1, -2));

        f.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { click.run(); h.postDelayed(new Runnable() {
                @Override public void run() { refreshTiles(); }
            }, 250); }
        });
        Tile tl = new Tile();
        tl.bg = bg;
        tl.on = on;
        tiles.add(tl);
        return c;
    }

    private void refreshTiles() {
        if (tiles.isEmpty()) return;
        for (Tile t : tiles) {
            boolean on;
            try { on = t.on.getAsBoolean(); } catch (Exception e) { on = false; }
            t.bg.setImageResource(on ? R.drawable.tile_on : R.drawable.tile_off);
        }
        if (dataOff != null) dataOff.setVisibility(View.GONE);
        refreshDataPill();
    }

    private void refreshDataPill() {
        if (dataPill == null) return;
        long rx = TrafficStats.getMobileRxBytes(), tx = TrafficStats.getMobileTxBytes();
        String s;
        if (rx == TrafficStats.UNSUPPORTED || tx == TrafficStats.UNSUPPORTED) {
            s = "Données mobiles  ›";
        } else {
            long mb = (rx + tx) / (1024 * 1024);
            s = "💧 " + mb + " Mo utilisés depuis le démarrage  ›";
        }
        dataPill.setText(s);
    }

    private void openPanel() {
        if (panelOpen) return;
        panelOpen = true;
        refreshTiles();
        syncSliders();
        panel.animate().translationY(0).setDuration(300).setInterpolator(new DecelerateInterpolator()).start();
    }

    private void closePanel() {
        if (!panelOpen) return;
        panelOpen = false;
        panel.animate().translationY(-root.getHeight()).setDuration(260)
                .setInterpolator(new AccelerateInterpolator()).start();
    }

    private void syncSliders() {
        try {
            float v = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128) / 255f;
            bright.setValue(v);
        } catch (Exception ignored) { }
        int max = Math.max(1, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        vol.setValue(audio.getStreamVolume(AudioManager.STREAM_MUSIC) / (float) max);
    }

    // ---------- actions des tuiles ----------
    private void openSettings(Intent i) {
        try {
            startActivity(i);
            closePanel();
        } catch (Exception e) {
            Toast.makeText(this, "Réglage indisponible sur ce téléphone", Toast.LENGTH_SHORT).show();
        }
    }

    private void openMobileData() {
        try {
            startActivity(new Intent(Settings.ACTION_DATA_ROAMING_SETTINGS));
            closePanel();
        } catch (Exception e) {
            openSettings(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
        }
    }

    private void openTether() {
        try {
            startActivity(new Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"));
            closePanel();
        } catch (Exception e) {
            openSettings(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
        }
    }

    private void initTorch() {
        try {
            camMgr = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            for (String id : camMgr.getCameraIdList()) {
                CameraCharacteristics cc = camMgr.getCameraCharacteristics(id);
                Boolean fl = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer lf = cc.get(CameraCharacteristics.LENS_FACING);
                if (Boolean.TRUE.equals(fl) && lf != null && lf == CameraCharacteristics.LENS_FACING_BACK) {
                    torchId = id;
                    break;
                }
            }
            camMgr.registerTorchCallback(new CameraManager.TorchCallback() {
                @Override public void onTorchModeChanged(String id, boolean enabled) {
                    if (id.equals(torchId)) { torchOn = enabled; refreshTiles(); }
                }
            }, h);
        } catch (Exception ignored) { }
    }

    private void toggleTorch() {
        try {
            camMgr.setTorchMode(torchId, !torchOn);
        } catch (Exception e) {
            Toast.makeText(this, "Lampe indisponible", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleVibrate() {
        try {
            boolean vib = audio.getRingerMode() == AudioManager.RINGER_MODE_VIBRATE;
            audio.setRingerMode(vib ? AudioManager.RINGER_MODE_NORMAL : AudioManager.RINGER_MODE_VIBRATE);
        } catch (Exception e) {
            Toast.makeText(this, "Active d'abord l'accès « Ne pas déranger » (étape Réglages)", Toast.LENGTH_LONG).show();
        }
    }

    private void toggleRotation() {
        if (!Settings.System.canWrite(this)) {
            askWriteSettings();
            return;
        }
        int cur = Settings.System.getInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 0);
        Settings.System.putInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, cur == 1 ? 0 : 1);
    }

    private void askWriteSettings() {
        Toast.makeText(this, "Autorise la modification des réglages système", Toast.LENGTH_LONG).show();
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) { }
    }

    private void toggleDnd() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm.isNotificationPolicyAccessGranted()) {
            boolean on = nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL;
            nm.setInterruptionFilter(on ? NotificationManager.INTERRUPTION_FILTER_ALL
                    : NotificationManager.INTERRUPTION_FILTER_PRIORITY);
        } else {
            openSettings(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
        }
    }

    private void toggleFirewall() {
        if (Prefs.bool(this, Prefs.FW_ON, false)) {
            FirewallService.stop(this);
        } else if (VpnService.prepare(this) == null) {
            Prefs.sp(this).edit().putBoolean(Prefs.FW_ON, true).apply();
            FirewallService.start(this);
        } else {
            startActivity(new Intent(this, DataActivity.class).putExtra("enable", true));
            closePanel();
        }
    }

    private void setBrightness(float v) {
        v = Math.max(0.02f, Math.min(1f, v));
        if (Settings.System.canWrite(this)) {
            try {
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, Math.round(v * 255));
            } catch (Exception ignored) { }
        } else {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = v;
            getWindow().setAttributes(lp);
            if (!warnedBright) {
                warnedBright = true;
                Toast.makeText(this, "Pour régler toute la luminosité : Réglages Nuit > étape 6", Toast.LENGTH_LONG).show();
            }
        }
    }
}
