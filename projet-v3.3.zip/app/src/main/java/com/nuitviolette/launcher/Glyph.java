package com.nuitviolette.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Pictogrammes nets du lecteur de musique (image 3), dessinés à la main : pas d'emoji, pas de police. */
final class Glyph extends View {
    static final int PREV = 0, NEXT = 1, PAUSE = 2, PLAY = 3, CLOSE = 4, CAST = 5;

    private int kind;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    Glyph(Context c, int kind) { super(c); this.kind = kind; }

    void setKind(int k) { if (k != kind) { kind = k; invalidate(); } }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float s = Math.min(w, h);
        float cx = w / 2f, cy = h / 2f;
        p.setShader(null);
        p.setColor(0xFFF3E9FF);
        p.setStyle(Paint.Style.FILL);
        switch (kind) {
            case PREV:
            case NEXT: {
                float dir = kind == NEXT ? 1f : -1f;
                float tw = s * 0.30f, th = s * 0.30f;
                for (int i = 0; i < 2; i++) {
                    float baseX = cx - dir * tw + dir * i * tw;
                    float tipX = baseX + dir * tw;
                    path.reset();
                    path.moveTo(baseX, cy - th);
                    path.lineTo(tipX, cy);
                    path.lineTo(baseX, cy + th);
                    path.close();
                    c.drawPath(path, p);
                }
                break;
            }
            case PAUSE: {
                float bw = s * 0.16f, bh = s * 0.42f, gap = s * 0.10f;
                RectF r = new RectF();
                r.set(cx - gap - bw, cy - bh, cx - gap, cy + bh);
                c.drawRoundRect(r, bw * 0.3f, bw * 0.3f, p);
                r.set(cx + gap, cy - bh, cx + gap + bw, cy + bh);
                c.drawRoundRect(r, bw * 0.3f, bw * 0.3f, p);
                break;
            }
            case PLAY: {
                float tw = s * 0.34f, th = s * 0.40f;
                path.reset();
                path.moveTo(cx - tw * 0.8f, cy - th);
                path.lineTo(cx + tw * 1.2f, cy);
                path.lineTo(cx - tw * 0.8f, cy + th);
                path.close();
                c.drawPath(path, p);
                break;
            }
            case CLOSE: {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(s * 0.075f);
                float k = s * 0.26f;
                c.drawLine(cx - k, cy - k, cx + k, cy + k, p);
                c.drawLine(cx + k, cy - k, cx - k, cy + k, p);
                break;
            }
            case CAST: {
                // ondes concentriques + triangle (icône « diffuser »)
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(s * 0.07f);
                p.setColor(0xFFB48CFF);
                RectF a = new RectF();
                float oy = cy - s * 0.04f;
                float r1 = s * 0.40f, r2 = s * 0.27f, r3 = s * 0.14f;
                a.set(cx - r1, oy - r1, cx + r1, oy + r1); c.drawArc(a, 150, 240, false, p);
                a.set(cx - r2, oy - r2, cx + r2, oy + r2); c.drawArc(a, 150, 240, false, p);
                a.set(cx - r3, oy - r3, cx + r3, oy + r3); c.drawArc(a, 150, 240, false, p);
                p.setStyle(Paint.Style.FILL);
                path.reset();
                path.moveTo(cx, oy + s * 0.05f);
                path.lineTo(cx + s * 0.22f, oy + s * 0.38f);
                path.lineTo(cx - s * 0.22f, oy + s * 0.38f);
                path.close();
                c.drawPath(path, p);
                break;
            }
            default:
        }
        p.setStrokeCap(Paint.Cap.BUTT);
    }
}

/** Pochette par défaut : galaxie violette + note de musique (image 3). */
final class MusicIcon extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();

    MusicIcon(Context c) { super(c); }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float d = getResources().getDisplayMetrics().density;
        float rad = w * 0.30f;
        // fond galaxie
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(w * 0.62f, h * 0.68f, w * 0.9f,
                new int[]{0xFFE070FF, 0xFF7A33E0, 0xFF1C0652}, new float[]{0f, 0.4f, 1f}, Shader.TileMode.CLAMP));
        rf.set(0, 0, w, h);
        c.drawRoundRect(rf, rad, rad, p);
        c.save();
        path.reset();
        path.addRoundRect(rf, rad, rad, Path.Direction.CW);
        c.clipPath(path);
        // anneau de galaxie incliné
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f * d);
        p.setColor(0xAAF0C8FF);
        c.save();
        c.rotate(-28, w * 0.5f, h * 0.62f);
        rf.set(w * 0.08f, h * 0.44f, w * 0.92f, h * 0.80f);
        c.drawOval(rf, p);
        p.setStrokeWidth(1f * d);
        p.setColor(0x66E7B8FF);
        rf.set(w * 0.02f, h * 0.38f, w * 0.98f, h * 0.86f);
        c.drawOval(rf, p);
        c.restore();
        // cœur lumineux
        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(w * 0.66f, h * 0.70f, w * 0.14f, 0xFFFFFFFF, 0x00FF9AFF, Shader.TileMode.CLAMP));
        c.drawCircle(w * 0.66f, h * 0.70f, w * 0.14f, p);
        p.setShader(null);
        // petites étoiles
        p.setColor(0xFFFFFFFF);
        c.drawCircle(w * 0.18f, h * 0.20f, 1.2f * d, p);
        c.drawCircle(w * 0.82f, h * 0.22f, 1.0f * d, p);
        c.drawCircle(w * 0.30f, h * 0.88f, 1.0f * d, p);
        c.restore();
        // note de musique
        p.setShader(new LinearGradient(0, h * 0.2f, 0, h * 0.8f, 0xFFFFE6FF, 0xFFD890FF, Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.FILL);
        float nx = w * 0.50f, ny = h * 0.64f, nr = w * 0.10f;
        // têtes
        c.save();
        c.rotate(-20, nx - w * 0.14f, ny);
        rf.set(nx - w * 0.14f - nr * 1.2f, ny - nr * 0.85f, nx - w * 0.14f + nr * 1.2f, ny + nr * 0.85f);
        c.drawOval(rf, p);
        c.restore();
        c.save();
        c.rotate(-20, nx + w * 0.14f, ny - h * 0.03f);
        rf.set(nx + w * 0.14f - nr * 1.2f, ny - h * 0.03f - nr * 0.85f, nx + w * 0.14f + nr * 1.2f, ny - h * 0.03f + nr * 0.85f);
        c.drawOval(rf, p);
        c.restore();
        // hampes + barre
        float sw = w * 0.045f;
        float x1 = nx - w * 0.14f + nr * 1.0f, x2 = nx + w * 0.14f + nr * 1.0f;
        float top = h * 0.24f;
        rf.set(x1 - sw, top + h * 0.03f, x1, ny - nr * 0.2f);
        c.drawRect(rf, p);
        rf.set(x2 - sw, top, x2, ny - h * 0.03f - nr * 0.2f);
        c.drawRect(rf, p);
        path.reset();
        path.moveTo(x1 - sw, top + h * 0.03f);
        path.lineTo(x2, top - h * 0.01f);
        path.lineTo(x2, top + h * 0.10f);
        path.lineTo(x1 - sw, top + h * 0.14f);
        path.close();
        c.drawPath(path, p);
        p.setShader(null);
        // bordure lumineuse
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2f * d);
        p.setColor(0xCCE2C4FF);
        rf.set(d, d, w - d, h - d);
        c.drawRoundRect(rf, rad, rad, p);
    }
}
