package com.nuitviolette.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/**
 * Grande barre de l'accueil, dessinée comme l'image 2 :
 * [ météo + température | loupe  Rechercher  ✦ | numéro du jour ] en verre violet lumineux.
 */
final class SearchPill extends View {
    interface OnSearch { void go(); }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();
    private String temp = "--°";
    private String day = "";
    private int code = -1;      // code météo Open-Meteo, -1 = inconnu
    private boolean night = true;
    private OnSearch cb;

    SearchPill(Context c) { super(c); }

    void setOnSearch(OnSearch c) { cb = c; }

    void setDay(String d) {
        if (!d.equals(day)) { day = d; invalidate(); }
    }

    void setWeather(String t, int wmoCode, boolean isNight) {
        temp = t; code = wmoCode; night = isNight;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float d = getResources().getDisplayMetrics().density;
        float r = h / 2f;
        float g = 3f * d;   // marge pour la lueur extérieure

        // lueur extérieure
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(5f * d);
        p.setColor(0x449B5CFF);
        rf.set(g, g, w - g, h - g);
        c.drawRoundRect(rf, r - g, r - g, p);

        // corps en verre : dégradé violet translucide + reflet en haut
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, g, 0, h - g, 0xCC4A1BA6, 0xCC1A0548, Shader.TileMode.CLAMP));
        c.drawRoundRect(rf, r - g, r - g, p);
        p.setShader(new LinearGradient(0, g, 0, h * 0.5f, 0x33FFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        rf.set(g + 2 * d, g + 1.5f * d, w - g - 2 * d, h * 0.5f);
        c.drawRoundRect(rf, r * 0.8f, r * 0.8f, p);

        // bordure claire
        p.setShader(new LinearGradient(0, 0, w, 0,
                new int[]{0xFFE9D3FF, 0xFFB98CFF, 0xFFE9D3FF}, null, Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(2.2f * d);
        rf.set(g, g, w - g, h - g);
        c.drawRoundRect(rf, r - g, r - g, p);
        p.setShader(null);

        // séparateurs
        float x1 = w * 0.34f, x2 = w * 0.82f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.4f * d);
        p.setColor(0x99D9B8FF);
        c.drawLine(x1, h * 0.2f, x1, h * 0.8f, p);
        c.drawLine(x2, h * 0.2f, x2, h * 0.8f, p);

        float cy = h / 2f;

        // --- zone gauche : météo + température
        float ico = h * 0.62f;
        drawWeather(c, w * 0.12f, cy, ico);
        p.setStyle(Paint.Style.FILL);
        p.setShader(null);
        p.setColor(0xFFFFFFFF);
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(h * 0.38f);
        p.setTextAlign(Paint.Align.LEFT);
        p.setShadowLayer(6f * d, 0, 0, 0xAA9B5CFF);
        c.drawText(temp, w * 0.12f + ico * 0.72f, cy + h * 0.135f, p);

        // --- zone centrale : loupe  Rechercher  ✦
        float mx = x1 + (x2 - x1) * 0.5f;
        p.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.NORMAL));
        p.setTextSize(h * 0.30f);
        p.setColor(0xFFF1E6FF);
        p.setShadowLayer(0, 0, 0, 0);
        String s = "Rechercher";
        float tw = p.measureText(s);
        float tx = mx - tw / 2f + h * 0.04f;
        c.drawText(s, tx, cy + h * 0.105f, p);
        drawLens(c, tx - h * 0.34f, cy - h * 0.01f, h * 0.17f);
        drawSpark(c, (x1 + x2) / 2f + (x2 - x1) * 0.35f, cy, h * 0.22f);

        // --- zone droite : numéro du jour
        p.setTypeface(Typeface.DEFAULT_BOLD);
        p.setTextSize(h * 0.38f);
        p.setColor(0xFFFFFFFF);
        p.setTextAlign(Paint.Align.CENTER);
        p.setShadowLayer(6f * d, 0, 0, 0xAA9B5CFF);
        c.drawText(day, x2 + (w - x2) / 2f, cy + h * 0.135f, p);
        p.setShadowLayer(0, 0, 0, 0);
        p.setTextAlign(Paint.Align.LEFT);
    }

    /** loupe */
    private void drawLens(Canvas c, float cx, float cy, float r) {
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(r * 0.30f);
        p.setColor(0xFFF1E6FF);
        c.drawCircle(cx, cy, r, p);
        c.drawLine(cx + r * 0.72f, cy + r * 0.72f, cx + r * 1.55f, cy + r * 1.55f, p);
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    /** étincelle à 4 branches */
    private void drawSpark(Canvas c, float x, float y, float r) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFF1E6FF);
        path.reset();
        path.moveTo(x, y - r);
        path.quadTo(x + r * 0.12f, y - r * 0.12f, x + r, y);
        path.quadTo(x + r * 0.12f, y + r * 0.12f, x, y + r);
        path.quadTo(x - r * 0.12f, y + r * 0.12f, x - r, y);
        path.quadTo(x - r * 0.12f, y - r * 0.12f, x, y - r);
        path.close();
        c.drawPath(path, p);
    }

    private void drawWeather(Canvas c, float cx, float cy, float s) {
        boolean clear = code == 0 || code == 1;
        boolean rain = (code >= 51 && code <= 67) || (code >= 80 && code <= 82) || code >= 95;
        boolean snow = (code >= 71 && code <= 77) || code == 85 || code == 86;
        boolean cloud = code != 0;       // inconnu (-1) => nuage + lune, comme l'image 2

        // astre : lune (nuit) ou soleil (jour)
        float ax = cx + (cloud && !clear ? s * 0.18f : 0f), ay = cy - (cloud && !clear ? s * 0.16f : 0f);
        float ar = s * (cloud && !clear ? 0.30f : 0.36f);
        if (!(rain || snow) || clear) {
            if (night) {
                p.setStyle(Paint.Style.FILL);
                p.setShader(new LinearGradient(ax - ar, ay - ar, ax + ar, ay + ar, 0xFFFFE9A8, 0xFFFFB63D, Shader.TileMode.CLAMP));
                path.reset();
                path.addCircle(ax, ay, ar, Path.Direction.CW);
                Path cut = new Path();
                cut.addCircle(ax + ar * 0.55f, ay - ar * 0.30f, ar * 0.85f, Path.Direction.CW);
                path.op(cut, Path.Op.DIFFERENCE);
                c.drawPath(path, p);
            } else {
                p.setStyle(Paint.Style.FILL);
                p.setShader(new RadialGradient(ax, ay, ar, 0xFFFFF2B0, 0xFFFFA928, Shader.TileMode.CLAMP));
                c.drawCircle(ax, ay, ar * 0.72f, p);
                p.setShader(null);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(ar * 0.16f);
                p.setColor(0xFFFFC857);
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4;
                    c.drawLine((float) (ax + Math.cos(a) * ar * 0.95f), (float) (ay + Math.sin(a) * ar * 0.95f),
                            (float) (ax + Math.cos(a) * ar * 1.22f), (float) (ay + Math.sin(a) * ar * 1.22f), p);
                }
                p.setStrokeCap(Paint.Cap.BUTT);
            }
        }
        p.setShader(null);

        if (cloud && !clear || code == 1) {
            if (code == 1) return;       // peu nuageux : l'astre seul suffit
            float bx = cx - s * 0.05f, by = cy + s * 0.14f;
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, by - s * 0.3f, 0, by + s * 0.24f, 0xFFFFFFFF, 0xFFC9B4F2, Shader.TileMode.CLAMP));
            path.reset();
            path.addCircle(bx - s * 0.20f, by + s * 0.02f, s * 0.20f, Path.Direction.CW);
            path.addCircle(bx + s * 0.02f, by - s * 0.10f, s * 0.27f, Path.Direction.CW);
            path.addCircle(bx + s * 0.26f, by + s * 0.03f, s * 0.19f, Path.Direction.CW);
            rf.set(bx - s * 0.40f, by - s * 0.02f, bx + s * 0.45f, by + s * 0.22f);
            path.addRoundRect(rf, s * 0.11f, s * 0.11f, Path.Direction.CW);
            c.drawPath(path, p);
            p.setShader(null);
            if (rain || snow) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(s * 0.07f);
                p.setColor(snow ? 0xFFFFFFFF : 0xFF8FD0FF);
                for (int i = -1; i <= 1; i++) {
                    float x = bx + i * s * 0.2f;
                    c.drawLine(x, by + s * 0.30f, x - s * 0.05f, by + s * 0.45f, p);
                }
                p.setStrokeCap(Paint.Cap.BUTT);
            }
        }
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX() / Math.max(1f, getWidth());
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                return x > 0.34f && x < 0.82f;
            case MotionEvent.ACTION_UP:
                if (x > 0.34f && x < 0.82f && cb != null) cb.go();
                return true;
            default:
                return true;
        }
    }
}
