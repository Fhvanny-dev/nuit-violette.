package com.nuitviolette.launcher;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.provider.Settings;
import android.util.DisplayMetrics;

/**
 * Fenêtres : ouvre la VRAIE application du téléphone dans une fenêtre flottante (aucun navigateur,
 * aucune recherche Google). Le lanceur choisit la position et la taille ; Android affiche la fenêtre.
 */
final class FloatWin {
    private static int cascade = 0;

    /** Le téléphone sait-il afficher des applications en fenêtres libres ? */
    static boolean supported(Context c) {
        try {
            if (c.getPackageManager().hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)) return true;
        } catch (Throwable ignored) { }
        try {
            if (Settings.Global.getInt(c.getContentResolver(), "enable_freeform_support", 0) != 0) return true;
            if (Settings.Global.getInt(c.getContentResolver(), "force_resizable_activities", 0) != 0
                    && Settings.Global.getInt(c.getContentResolver(), "enable_freeform_support", 0) != 0) return true;
        } catch (Throwable ignored) { }
        return false;
    }

    /** La permission spéciale a-t-elle été donnée une fois par ADB ? (voir le guide dans l'application) */
    static boolean canSelfEnable(Context c) {
        return c.checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS") == PackageManager.PERMISSION_GRANTED;
    }

    /** Active les fenêtres libres d'Android (équivalent des options développeur). Un redémarrage est ensuite nécessaire. */
    static boolean selfEnable(Context c) {
        try {
            android.content.ContentResolver r = c.getContentResolver();
            Settings.Global.putInt(r, "enable_freeform_support", 1);
            Settings.Global.putInt(r, "force_resizable_activities", 1);
            Settings.Global.putInt(r, "freeform_window_management", 1);
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    /** Ouvre l'application a dans une fenêtre flottante (cascade de positions). Retourne false en cas d'échec. */
    static boolean open(Activity act, Apps.App a) {
        DisplayMetrics dm = act.getResources().getDisplayMetrics();
        int sw = dm.widthPixels, sh = dm.heightPixels;
        int n = cascade++ % 5;
        int dx = Ui.dp(act, 22) * n, dy = Ui.dp(act, 30) * n;
        int l = Math.round(sw * .06f) + dx, t = Math.round(sh * .10f) + dy;
        Rect r = new Rect(l, t, l + Math.round(sw * .88f), t + Math.round(sh * .55f));
        try {
            Intent i = new Intent(a.launch);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            ActivityOptions o = ActivityOptions.makeBasic().setLaunchBounds(r);
            // mode « fenêtre libre » demandé explicitement quand le système l'autorise (API cachée, sans danger si absente)
            try {
                ActivityOptions.class.getMethod("setLaunchWindowingMode", int.class).invoke(o, 5);
            } catch (Throwable ignored) { }
            act.startActivity(i, o.toBundle());
            return true;
        } catch (Throwable e) {
            return false;
        }
    }

    /**
     * Téléphones sans fenêtres flottantes : l'application lance elle-même la vraie appli puis met l'écran en
     * mode partagé (fenêtre du haut = l'appli choisie, fenêtre du bas = le launcher pour en choisir une autre).
     */
    static boolean openSplit(final Activity act, Apps.App a) {
        try {
            Intent i = new Intent(a.launch);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_LAUNCH_ADJACENT);
            act.startActivity(i);
            new android.os.Handler(android.os.Looper.getMainLooper()).postDelayed(new Runnable() {
                @Override public void run() { PullService.splitScreen(); }
            }, 900);
            return true;
        } catch (Throwable e) {
            return false;
        }
    }
}
