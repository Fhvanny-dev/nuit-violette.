package com.nuitviolette.launcher;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.location.LocationManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.VpnService;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.net.TrafficStats;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.DecelerateInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.BooleanSupplier;

public class MainActivity extends Activity {
    // couches
    private FrameLayout root;
    private SwipeLayout home, drawer, panel;
    // accueil
    private LinearLayout favRow, dockRow;
    private TextView clock, dateTv, greetTv;
    // tiroir
    private GridView grid;
    private ShownAdapter adapter;
    private EditText search;
    private LinearLayout chipRow;
    // panneau
    private ScrollView panelScroll;
    private TextView panelClock, panelDate, dataPill, wifiSub, dataSub;
    private LinearLayout bigWifi, bigData;
    private VSlider bright, vol;

    private final List<Apps.App> all = new ArrayList<Apps.App>();
    private final List<Apps.App> shown = new ArrayList<Apps.App>();
    private final List<String> dockPk = new ArrayList<String>();
    private final List<String> favPk = new ArrayList<String>();
    private final List<Tile> tiles = new ArrayList<Tile>();

    private int tab = 0;
    private boolean unlocked, drawerOpen, panelOpen, warnedBright;
    private int topIn, navIn, imeIn;
    private final Handler h = new Handler(Looper.getMainLooper());

    private CameraManager camMgr;
    private String torchId;
    private boolean torchOn;
    private AudioManager audio;

    private BroadcastReceiver pkgRx;

    private static final class Tile {
        ImageView bg;
        BooleanSupplier on;
    }

    private final Runnable tickR = new Runnable() {
        @Override public void run() { tick(); h.postDelayed(this, 15000); }
    };
    private final Runnable reloadR = new Runnable() {
        @Override public void run() { loadApps(); }
    };

    private int dp(float v) { return Ui.dp(this, v); }

    // ====================== cycle de vie ======================
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        initTorch();

        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF0B0220);
        ImageView bg = new ImageView(this);
        bg.setImageResource(R.drawable.bg_home);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        root.addView(bg, new FrameLayout.LayoutParams(-1, -1));

        buildHome();
        buildDrawer();
        buildPanel();
        root.addView(home, new FrameLayout.LayoutParams(-1, -1));
        root.addView(drawer, new FrameLayout.LayoutParams(-1, -1));
        root.addView(panel, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets ins) {
                topIn = ins.getSystemWindowInsetTop();
                navIn = ins.getStableInsetBottom();
                imeIn = ins.getSystemWindowInsetBottom();
                home.setPadding(0, topIn, 0, navIn);
                panel.setPadding(0, topIn, 0, navIn);
                drawer.setPadding(0, topIn, 0, imeIn);
                return ins;
            }
        });
        root.addOnLayoutChangeListener(new View.OnLayoutChangeListener() {
            @Override public void onLayoutChange(View v, int l, int t, int r, int bt, int ol, int ot, int orr, int ob) {
                if ((bt - t) == (ob - ot)) return;
                int H = bt - t;
                if (!drawerOpen) drawer.setTranslationY(H);
                if (!panelOpen) panel.setTranslationY(-H);
            }
        });

        pkgRx = new BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                h.removeCallbacks(reloadR);
                h.postDelayed(reloadR, 700);
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgRx, f);

        loadApps();
    }

    @Override
    protected void onResume() {
        super.onResume();
        h.removeCallbacks(tickR);
        h.post(tickR);
        refreshTiles();
        if (!all.isEmpty()) { refreshHome(); refreshGrid(); }
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tickR);
    }

    @Override
    protected void onDestroy() {
        try { unregisterReceiver(pkgRx); } catch (Exception ignored) { }
        super.onDestroy();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        if (panelOpen) closePanel();
        if (drawerOpen) closeDrawer();
    }

    @Override
    public void onBackPressed() {
        if (panelOpen) closePanel();
        else if (drawerOpen) closeDrawer();
        // launcher : rien d'autre
    }

    // ====================== données ======================
    private void loadApps() {
        new Thread(new Runnable() {
            @Override public void run() {
                final List<Apps.App> l = Apps.load(MainActivity.this);
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        all.clear();
                        all.addAll(l);
                        refreshHome();
                        refreshGrid();
                    }
                });
            }
        }).start();
    }

    private void launch(Apps.App a) {
        try {
            startActivity(a.launch);
            if (drawerOpen) closeDrawer();
            if (panelOpen) closePanel();
        } catch (Exception e) {
            Toast.makeText(this, "Impossible d'ouvrir " + a.label, Toast.LENGTH_SHORT).show();
        }
    }

    // ====================== ACCUEIL ======================
    private void buildHome() {
        home = new SwipeLayout(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        home.addView(col, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout head = new FrameLayout(this);
        LinearLayout tcol = new LinearLayout(this);
        tcol.setOrientation(LinearLayout.VERTICAL);
        clock = Ui.text(this, "", 56, Color.WHITE, true);
        Ui.glow(clock, Ui.GLOW, 10);
        dateTv = Ui.text(this, "", 16, Ui.LIGHT, false);
        Ui.glow(dateTv, Ui.GLOW, 6);
        greetTv = Ui.text(this, "", 30, Color.WHITE, false);
        greetTv.setTypeface(Typeface.create("cursive", Typeface.ITALIC));
        Ui.glow(greetTv, Ui.GLOW, 9);
        tcol.addView(clock);
        tcol.addView(dateTv);
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(-2, -2);
        gp.setMargins(0, dp(10), 0, 0);
        tcol.addView(greetTv, gp);
        head.addView(tcol, new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.TOP));

        final ImageView cat = new ImageView(this);
        cat.setImageResource(R.drawable.cat);
        cat.setAdjustViewBounds(true);
        cat.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                ObjectAnimator.ofFloat(cat, "rotation", 0f, -10f, 10f, -6f, 0f).setDuration(650).start();
            }
        });
        head.addView(cat, new FrameLayout.LayoutParams(dp(150), dp(89), Gravity.END | Gravity.TOP));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(-1, -2);
        hp.setMargins(dp(24), dp(16), dp(14), 0);
        col.addView(head, hp);

        col.addView(new View(this), new LinearLayout.LayoutParams(-1, 0, 1f));

        favRow = new LinearLayout(this);
        favRow.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, -2);
        fp.setMargins(dp(14), 0, dp(14), dp(14));
        col.addView(favRow, fp);

        LinearLayout srow = new LinearLayout(this);
        srow.setOrientation(LinearLayout.HORIZONTAL);
        srow.setGravity(Gravity.CENTER_VERTICAL);
        TextView pill = Ui.text(this, "🔍   Rechercher", 16, Ui.LIGHT, false);
        pill.setGravity(Gravity.CENTER_VERTICAL);
        pill.setPadding(dp(20), 0, dp(20), 0);
        pill.setBackground(Ui.glass(this, 26, 0x55200A4A, 0x889B5CFF));
        pill.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openDrawer(true); }
        });
        srow.addView(pill, new LinearLayout.LayoutParams(0, dp(50), 1f));
        TextView gear = Ui.text(this, "⚙", 22, Ui.LIGHT, false);
        gear.setGravity(Gravity.CENTER);
        gear.setBackground(Ui.glass(this, 25, 0x55200A4A, 0x889B5CFF));
        gear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startActivity(new Intent(MainActivity.this, HubActivity.class)); }
        });
        LinearLayout.LayoutParams grp = new LinearLayout.LayoutParams(dp(50), dp(50));
        grp.setMargins(dp(10), 0, 0, 0);
        srow.addView(gear, grp);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(dp(16), 0, dp(16), dp(14));
        col.addView(srow, sp);

        dockRow = new LinearLayout(this);
        dockRow.setOrientation(LinearLayout.HORIZONTAL);
        dockRow.setPadding(dp(8), dp(8), dp(8), dp(8));
        dockRow.setBackground(Ui.glass(this, 34, 0x44120430, 0x669B5CFF));
        LinearLayout.LayoutParams dpp = new LinearLayout.LayoutParams(-1, -2);
        dpp.setMargins(dp(16), 0, dp(16), dp(10));
        col.addView(dockRow, dpp);

        home.setListener(new SwipeLayout.L() {
            @Override public boolean canUp() { return !drawerOpen && !panelOpen; }
            @Override public boolean canDown() { return !drawerOpen && !panelOpen; }
            @Override public void onUp() { openDrawer(false); }
            @Override public void onDown() { openPanel(); }
        });
    }

    private void tick() {
        Date now = new Date();
        int hr = Integer.parseInt(new SimpleDateFormat("H", Locale.getDefault()).format(now));
        String time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(now);
        String d = new SimpleDateFormat("EEEE d MMMM", Locale.getDefault()).format(now);
        if (!d.isEmpty()) d = Character.toUpperCase(d.charAt(0)) + d.substring(1);
        clock.setText(time);
        dateTv.setText(d);
        panelClock.setText(time);
        panelDate.setText(d);
        String g = hr >= 6 && hr < 12 ? "Bonjour ♡" : hr >= 12 && hr < 18 ? "Bon après-midi" : hr >= 18 && hr < 22 ? "Bonne soirée" : "Bonne nuit ♡";
        greetTv.setText(g);
        refreshDataPill();
    }

    private List<String> dockDefaults() {
        List<String> l = new ArrayList<String>();
        addRes(l, new Intent(Intent.ACTION_DIAL));
        try {
            String sms = android.provider.Telephony.Sms.getDefaultSmsPackage(this);
            if (sms != null) l.add(sms);
        } catch (Exception ignored) { }
        addRes(l, new Intent(Intent.ACTION_VIEW, Uri.parse("https://example.com")).addCategory(Intent.CATEGORY_BROWSABLE));
        addRes(l, new Intent(MediaStore.ACTION_IMAGE_CAPTURE));
        return l;
    }

    private void addRes(List<String> l, Intent i) {
        ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        if (ri != null && ri.activityInfo != null && !"android".equals(ri.activityInfo.packageName)) {
            l.add(ri.activityInfo.packageName);
        }
    }

    private List<Apps.App> resolve(String key, int n, List<String> defaults, Set<String> hid, Set<String> exclude) {
        List<String> pk = Prefs.getList(this, key);
        if (pk.isEmpty()) pk = defaults;
        List<Apps.App> out = new ArrayList<Apps.App>();
        Set<String> used = new HashSet<String>(exclude);
        for (String p : pk) {
            if (out.size() >= n) break;
            if (hid.contains(p) || used.contains(p)) continue;
            for (Apps.App a : all) {
                if (a.pkg.equals(p)) { out.add(a); used.add(p); break; }
            }
        }
        for (Apps.App a : all) {
            if (out.size() >= n) break;
            if (hid.contains(a.pkg) || used.contains(a.pkg)) continue;
            out.add(a);
            used.add(a.pkg);
        }
        return out;
    }

    private void refreshHome() {
        favRow.removeAllViews();
        dockRow.removeAllViews();
        Set<String> hid = Prefs.getSet(this, Prefs.HIDDEN);
        List<Apps.App> dock = resolve(Prefs.DOCK, 4, dockDefaults(), hid, new HashSet<String>());
        Set<String> ex = new HashSet<String>();
        for (Apps.App a : dock) ex.add(a.pkg);
        List<String> favDef = new ArrayList<String>();
        favDef.add("com.android.vending");
        favDef.add("com.google.android.apps.maps");
        favDef.add("com.google.android.gm");
        favDef.add("com.google.android.youtube");
        List<Apps.App> fav = resolve(Prefs.FAV, 4, favDef, hid, ex);
        dockPk.clear();
        favPk.clear();
        for (Apps.App a : fav) { favPk.add(a.pkg); favRow.addView(cell(a, true, 60), new LinearLayout.LayoutParams(0, -2, 1f)); }
        for (Apps.App a : dock) { dockPk.add(a.pkg); dockRow.addView(cell(a, false, 58), new LinearLayout.LayoutParams(0, -2, 1f)); }
    }

    private View cell(final Apps.App a, boolean label, int size) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView iv = new ImageView(this);
        iv.setImageBitmap(a.bmp);
        c.addView(iv, new LinearLayout.LayoutParams(dp(size), dp(size)));
        if (label) {
            TextView t = Ui.text(this, a.label, 11, Color.WHITE, false);
            t.setSingleLine(true);
            t.setEllipsize(TextUtils.TruncateAt.END);
            t.setGravity(Gravity.CENTER);
            Ui.glow(t, 0xFF000000, 3);
            c.addView(t, new LinearLayout.LayoutParams(-1, -2));
        }
        c.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { launch(a); }
        });
        c.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) { appMenu(a); return true; }
        });
        return c;
    }

    // ====================== TIROIR ======================
    private void buildDrawer() {
        drawer = new SwipeLayout(this);
        drawer.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xF4140536, 0xFA090118}));
        LinearLayout dc = new LinearLayout(this);
        dc.setOrientation(LinearLayout.VERTICAL);
        drawer.addView(dc, new FrameLayout.LayoutParams(-1, -1));

        FrameLayout hw = new FrameLayout(this);
        View bar = new View(this);
        bar.setBackground(Ui.glass(this, 3, 0x88FFFFFF, 0x00000000));
        hw.addView(bar, new FrameLayout.LayoutParams(dp(44), dp(5), Gravity.CENTER));
        hw.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closeDrawer(); }
        });
        dc.addView(hw, new LinearLayout.LayoutParams(-1, dp(32)));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        chipRow = new LinearLayout(this);
        chipRow.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(chipRow);
        String[] names = {"Tout ♡", "Social", "Médias", "Productivité", "Jeux", "🔒 Masquées"};
        for (int i = 0; i < names.length; i++) {
            final int idx = i;
            TextView chip = Ui.text(this, names[i], 14, Color.WHITE, true);
            chip.setPadding(dp(16), dp(8), dp(16), dp(8));
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { selectTab(idx); }
            });
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-2, -2);
            cp.setMargins(0, 0, dp(8), 0);
            chipRow.addView(chip, cp);
        }
        updateChips();
        LinearLayout.LayoutParams hsp = new LinearLayout.LayoutParams(-1, -2);
        hsp.setMargins(dp(16), 0, dp(16), dp(8));
        dc.addView(hs, hsp);

        grid = new GridView(this);
        grid.setNumColumns(4);
        grid.setVerticalSpacing(dp(14));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(new ColorDrawable(0));
        grid.setPadding(dp(8), dp(8), dp(8), dp(8));
        grid.setClipToPadding(false);
        grid.setVerticalScrollBarEnabled(false);
        grid.setOverScrollMode(View.OVER_SCROLL_NEVER);
        adapter = new ShownAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new android.widget.AdapterView.OnItemClickListener() {
            @Override public void onItemClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                if (pos >= 0 && pos < shown.size()) launch(shown.get(pos));
            }
        });
        grid.setOnItemLongClickListener(new android.widget.AdapterView.OnItemLongClickListener() {
            @Override public boolean onItemLongClick(android.widget.AdapterView<?> p, View v, int pos, long id) {
                if (pos >= 0 && pos < shown.size()) appMenu(shown.get(pos));
                return true;
            }
        });
        dc.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1f));

        search = new EditText(this);
        search.setHint("Rechercher");
        search.setHintTextColor(0x99E9D5FF);
        search.setTextColor(Color.WHITE);
        search.setTextSize(16);
        search.setSingleLine(true);
        search.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        search.setPadding(dp(20), 0, dp(20), 0);
        search.setBackground(Ui.glass(this, 26, 0x33FFFFFF, 0x889B5CFF));
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { refreshGrid(); }
        });
        search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int a, android.view.KeyEvent e) {
                if (!shown.isEmpty()) launch(shown.get(0));
                return true;
            }
        });
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, dp(50));
        sp.setMargins(dp(16), dp(8), dp(16), dp(12));
        dc.addView(search, sp);

        drawer.setListener(new SwipeLayout.L() {
            @Override public boolean canUp() { return false; }
            @Override public boolean canDown() { return drawerOpen && gridAtTop(); }
            @Override public void onUp() { }
            @Override public void onDown() { closeDrawer(); }
        });
    }

    private boolean gridAtTop() {
        return grid.getFirstVisiblePosition() == 0
                && (grid.getChildCount() == 0 || grid.getChildAt(0).getTop() >= grid.getPaddingTop());
    }

    private void selectTab(final int i) {
        if (i == 5 && !unlocked) {
            Pin.ask(this, new Runnable() {
                @Override public void run() {
                    unlocked = true;
                    tab = 5;
                    updateChips();
                    refreshGrid();
                }
            });
            return;
        }
        tab = i;
        updateChips();
        refreshGrid();
    }

    private void updateChips() {
        for (int i = 0; i < chipRow.getChildCount(); i++) {
            TextView t = (TextView) chipRow.getChildAt(i);
            t.setBackground(i == tab
                    ? Ui.grad(this, 20, 0xFFA45CFF, 0xFF5A1FE0, 0xAAF3E6FF)
                    : Ui.glass(this, 20, 0x33200A4A, 0x889B5CFF));
        }
    }

    private void refreshGrid() {
        if (search == null || adapter == null) return;
        String q = search.getText().toString().trim().toLowerCase();
        Set<String> hid = Prefs.getSet(this, Prefs.HIDDEN);
        shown.clear();
        for (Apps.App a : all) {
            boolean isH = hid.contains(a.pkg);
            if (tab == 5) {
                if (!isH || !unlocked) continue;
            } else {
                if (isH) continue;
                if (!Apps.inTab(a, tab)) continue;
            }
            if (!q.isEmpty() && !a.label.toLowerCase().contains(q)) continue;
            shown.add(a);
        }
        adapter.notifyDataSetChanged();
    }

    private final class ShownAdapter extends BaseAdapter {
        @Override public int getCount() { return shown.size(); }
        @Override public Object getItem(int i) { return shown.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View cv, ViewGroup parent) {
            LinearLayout c;
            if (cv == null) {
                c = new LinearLayout(MainActivity.this);
                c.setOrientation(LinearLayout.VERTICAL);
                c.setGravity(Gravity.CENTER_HORIZONTAL);
                ImageView iv = new ImageView(MainActivity.this);
                c.addView(iv, new LinearLayout.LayoutParams(dp(58), dp(58)));
                TextView t = Ui.text(MainActivity.this, "", 11, Color.WHITE, false);
                t.setSingleLine(true);
                t.setEllipsize(TextUtils.TruncateAt.END);
                t.setGravity(Gravity.CENTER);
                Ui.glow(t, 0xFF000000, 3);
                c.addView(t, new LinearLayout.LayoutParams(-1, -2));
            } else {
                c = (LinearLayout) cv;
            }
            Apps.App a = shown.get(i);
            ((ImageView) c.getChildAt(0)).setImageBitmap(a.bmp);
            ((TextView) c.getChildAt(1)).setText(a.label);
            return c;
        }
    }

    private void openDrawer(boolean focusSearch) {
        if (drawerOpen) return;
        drawerOpen = true;
        refreshGrid();
        drawer.animate().translationY(0).setDuration(300).setInterpolator(new DecelerateInterpolator()).start();
        home.animate().alpha(0.25f).setDuration(300).start();
        if (focusSearch) {
            h.postDelayed(new Runnable() {
                @Override public void run() {
                    search.requestFocus();
                    InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (im != null) im.showSoftInput(search, 0);
                }
            }, 320);
        }
    }

    private void closeDrawer() {
        if (!drawerOpen) return;
        drawerOpen = false;
        InputMethodManager im = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        if (im != null) im.hideSoftInputFromWindow(search.getWindowToken(), 0);
        drawer.animate().translationY(root.getHeight()).setDuration(260)
                .setInterpolator(new AccelerateInterpolator()).start();
        home.animate().alpha(1f).setDuration(260).start();
        search.setText("");
        search.clearFocus();
        tab = 0;
        unlocked = false;
        updateChips();
        refreshGrid();
    }

    // ---------- menu appui long ----------
    private void appMenu(final Apps.App a) {
        final boolean isH = Prefs.getSet(this, Prefs.HIDDEN).contains(a.pkg);
        String[] items = {
                isH ? "Ne plus masquer" : "Masquer l'application",
                "Mettre dans le dock",
                "Épingler à l'accueil",
                "Contrôle des données…",
                "Infos de l'application",
                "Désinstaller"};
        new AlertDialog.Builder(this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(a.label)
                .setItems(items, new android.content.DialogInterface.OnClickListener() {
                    @Override public void onClick(android.content.DialogInterface d, int which) {
                        switch (which) {
                            case 0:
                                Pin.ask(MainActivity.this, new Runnable() {
                                    @Override public void run() {
                                        Prefs.toggle(MainActivity.this, Prefs.HIDDEN, a.pkg);
                                        refreshHome();
                                        refreshGrid();
                                    }
                                });
                                break;
                            case 1: pinTo(Prefs.DOCK, a.pkg); break;
                            case 2: pinTo(Prefs.FAV, a.pkg); break;
                            case 3: startActivity(new Intent(MainActivity.this, DataActivity.class)); break;
                            case 4:
                                try {
                                    startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                            Uri.parse("package:" + a.pkg)));
                                } catch (Exception ignored) { }
                                break;
                            default:
                                try {
                                    startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.pkg)));
                                } catch (Exception ignored) { }
                                break;
                        }
                    }
                }).show();
    }

    private void pinTo(String key, String pkg) {
        List<String> cur = new ArrayList<String>(Prefs.getList(this, key));
        if (cur.isEmpty()) cur.addAll(key.equals(Prefs.DOCK) ? dockPk : favPk);
        String other = key.equals(Prefs.DOCK) ? Prefs.FAV : Prefs.DOCK;
        List<String> o = new ArrayList<String>(Prefs.getList(this, other));
        if (o.isEmpty()) o.addAll(key.equals(Prefs.DOCK) ? favPk : dockPk);
        o.remove(pkg);
        cur.remove(pkg);
        cur.add(0, pkg);
        while (cur.size() > 4) cur.remove(cur.size() - 1);
        Prefs.putList(this, key, cur);
        Prefs.putList(this, other, o);
        refreshHome();
        Toast.makeText(this, "C'est fait ♡", Toast.LENGTH_SHORT).show();
    }

    // ====================== PANNEAU RAPIDE ======================
    private void buildPanel() {
        panel = new SwipeLayout(this);
        panel.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xF8180646, 0xFC0A0120}));

        panelScroll = new ScrollView(this);
        panelScroll.setVerticalScrollBarEnabled(false);
        panelScroll.setFillViewport(true);
        LinearLayout pc = new LinearLayout(this);
        pc.setOrientation(LinearLayout.VERTICAL);
        pc.setPadding(dp(16), dp(14), dp(16), dp(14));
        panelScroll.addView(pc, new ScrollView.LayoutParams(-1, -2));
        panel.addView(panelScroll, new FrameLayout.LayoutParams(-1, -1));

        // en-tête
        FrameLayout head = new FrameLayout(this);
        LinearLayout tc = new LinearLayout(this);
        tc.setOrientation(LinearLayout.VERTICAL);
        panelClock = Ui.text(this, "", 46, Color.WHITE, true);
        Ui.glow(panelClock, Ui.GLOW, 9);
        panelDate = Ui.text(this, "", 15, Ui.LIGHT, false);
        tc.addView(panelClock);
        tc.addView(panelDate);
        head.addView(tc, new FrameLayout.LayoutParams(-2, -2, Gravity.START | Gravity.CENTER_VERTICAL));
        ImageView cat = new ImageView(this);
        cat.setImageResource(R.drawable.cat);
        cat.setAdjustViewBounds(true);
        head.addView(cat, new FrameLayout.LayoutParams(dp(120), dp(71), Gravity.END | Gravity.CENTER_VERTICAL));
        pc.addView(head, new LinearLayout.LayoutParams(-1, -2));

        // pastille données
        dataPill = Ui.text(this, "", 14, Ui.LIGHT, false);
        dataPill.setGravity(Gravity.CENTER);
        dataPill.setPadding(dp(16), dp(12), dp(16), dp(12));
        dataPill.setBackground(Ui.glass(this, 26, 0x44200A4A, 0x889B5CFF));
        dataPill.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, DataActivity.class));
                closePanel();
            }
        });
        LinearLayout.LayoutParams dpl = new LinearLayout.LayoutParams(-1, -2);
        dpl.setMargins(0, dp(12), 0, dp(12));
        pc.addView(dataPill, dpl);

        // ligne du milieu : grandes tuiles + curseurs
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);

        wifiSub = Ui.text(this, "", 12, Ui.SOFT, false);
        bigWifi = bigTile(new WifiGlyph(this), "Wi-Fi", wifiSub, new Runnable() {
            @Override public void run() {
                Intent i = Build.VERSION.SDK_INT >= 29
                        ? new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY)
                        : new Intent(Settings.ACTION_WIFI_SETTINGS);
                openSettings(i);
            }
        });
        left.addView(bigWifi, new LinearLayout.LayoutParams(-1, 0, 1f));

        dataSub = Ui.text(this, "", 12, Ui.SOFT, false);
        TextView arrows = Ui.text(this, "⇅", 26, Color.WHITE, true);
        arrows.setGravity(Gravity.CENTER);
        bigData = bigTile(arrows, "Données par appli", dataSub, new Runnable() {
            @Override public void run() {
                startActivity(new Intent(MainActivity.this, DataActivity.class));
                closePanel();
            }
        });
        LinearLayout.LayoutParams bdp = new LinearLayout.LayoutParams(-1, 0, 1f);
        bdp.setMargins(0, dp(10), 0, 0);
        left.addView(bigData, bdp);
        mid.addView(left, new LinearLayout.LayoutParams(0, -1, 1f));

        bright = new VSlider(this, 0);
        bright.setOnChange(new VSlider.OnChange() {
            @Override public void on(float v) { setBrightness(v); }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(dp(70), -1);
        bp.setMargins(dp(10), 0, 0, 0);
        mid.addView(bright, bp);
        vol = new VSlider(this, 1);
        vol.setOnChange(new VSlider.OnChange() {
            @Override public void on(float v) {
                int max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                audio.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(v * max), 0);
            }
        });
        LinearLayout.LayoutParams vp = new LinearLayout.LayoutParams(dp(70), -1);
        vp.setMargins(dp(10), 0, 0, 0);
        mid.addView(vol, vp);
        pc.addView(mid, new LinearLayout.LayoutParams(-1, dp(190)));

        // tuiles
        LinearLayout r1 = tileRow(), r2 = tileRow(), r3 = tileRow();
        r1.addView(tile(R.drawable.ic_bt, "Bluetooth", new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return false; }
        }, new Runnable() { @Override public void run() { openSettings(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); } }));
        r1.addView(tile(R.drawable.ic_torch, "Lampe", new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return torchOn; }
        }, new Runnable() { @Override public void run() { toggleTorch(); } }));
        r1.addView(tile(R.drawable.ic_plane, "Avion", new BooleanSupplier() {
            @Override public boolean getAsBoolean() {
                return Settings.Global.getInt(getContentResolver(), Settings.Global.AIRPLANE_MODE_ON, 0) == 1;
            }
        }, new Runnable() { @Override public void run() { openSettings(new Intent(Settings.ACTION_AIRPLANE_MODE_SETTINGS)); } }));
        r1.addView(tile(R.drawable.ic_vib, "Vibreur", new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return audio.getRingerMode() == AudioManager.RINGER_MODE_VIBRATE; }
        }, new Runnable() { @Override public void run() { toggleVibrate(); } }));

        r2.addView(tile(R.drawable.ic_rot, "Rotation", new BooleanSupplier() {
            @Override public boolean getAsBoolean() {
                return Settings.System.getInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 0) == 1;
            }
        }, new Runnable() { @Override public void run() { toggleRotation(); } }));
        r2.addView(tile(R.drawable.ic_loc, "Position", new BooleanSupplier() {
            @Override public boolean getAsBoolean() {
                try {
                    LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
                    return Build.VERSION.SDK_INT >= 28 && lm.isLocationEnabled();
                } catch (Exception e) { return false; }
            }
        }, new Runnable() { @Override public void run() { openSettings(new Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)); } }));
        r2.addView(tile(R.drawable.ic_dnd, "Ne pas déranger", new BooleanSupplier() {
            @Override public boolean getAsBoolean() {
                NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                return nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL
                        && nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_UNKNOWN;
            }
        }, new Runnable() { @Override public void run() { toggleDnd(); } }));
        r2.addView(tile(R.drawable.ic_hot, "Partage", new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return false; }
        }, new Runnable() { @Override public void run() { openTether(); } }));

        r3.addView(tile(R.drawable.ic_moon, "Mode nuit", new BooleanSupplier() {
            @Override public boolean getAsBoolean() {
                return (getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK)
                        == Configuration.UI_MODE_NIGHT_YES;
            }
        }, new Runnable() { @Override public void run() { openSettings(new Intent(Settings.ACTION_DISPLAY_SETTINGS)); } }));
        r3.addView(tile(R.drawable.ic_eye, "Pare-feu", new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return Prefs.bool(MainActivity.this, Prefs.FW_ON, false); }
        }, new Runnable() { @Override public void run() { toggleFirewall(); } }));
        r3.addView(tile(R.drawable.ic_sync, "Pop-ups", new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return Prefs.bool(MainActivity.this, Prefs.POP, true); }
        }, new Runnable() {
            @Override public void run() {
                Prefs.sp(MainActivity.this).edit().putBoolean(Prefs.POP, !Prefs.bool(MainActivity.this, Prefs.POP, true)).apply();
                refreshTiles();
            }
        }));
        r3.addView(tile(R.drawable.ic_device, "Réglages", new BooleanSupplier() {
            @Override public boolean getAsBoolean() { return false; }
        }, new Runnable() {
            @Override public void run() {
                startActivity(new Intent(MainActivity.this, HubActivity.class));
                closePanel();
            }
        }));
        pc.addView(r1);
        pc.addView(r2);
        pc.addView(r3);

        // poignée de fermeture
        TextView close = Ui.text(this, "⌃", 26, Ui.LIGHT, true);
        close.setGravity(Gravity.CENTER);
        close.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { closePanel(); }
        });
        pc.addView(close, new LinearLayout.LayoutParams(-1, dp(48)));

        panel.setListener(new SwipeLayout.L() {
            @Override public boolean canUp() { return panelOpen && !panelScroll.canScrollVertically(1); }
            @Override public boolean canDown() { return false; }
            @Override public void onUp() { closePanel(); }
            @Override public void onDown() { }
        });
    }

    private LinearLayout tileRow() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(12), 0, 0);
        r.setLayoutParams(lp);
        return r;
    }

    private LinearLayout bigTile(View glyph, String title, TextView sub, final Runnable click) {
        LinearLayout t = new LinearLayout(this);
        t.setOrientation(LinearLayout.HORIZONTAL);
        t.setGravity(Gravity.CENTER_VERTICAL);
        t.setPadding(dp(14), dp(8), dp(10), dp(8));
        t.setBackground(Ui.glass(this, 26, 0x55200A4A, 0x889B5CFF));
        t.addView(glyph, new LinearLayout.LayoutParams(dp(34), dp(34)));
        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        TextView tt = Ui.text(this, title, 14.5f, Color.WHITE, true);
        tt.setSingleLine(true);
        tt.setEllipsize(TextUtils.TruncateAt.END);
        tx.addView(tt);
        sub.setSingleLine(true);
        sub.setEllipsize(TextUtils.TruncateAt.END);
        tx.addView(sub);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(10), 0, 0, 0);
        t.addView(tx, lp);
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { click.run(); }
        });
        return t;
    }

    private View tile(int icon, String label, BooleanSupplier on, final Runnable click) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER_HORIZONTAL);
        c.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));

        FrameLayout f = new FrameLayout(this);
        ImageView bg = new ImageView(this);
        bg.setScaleType(ImageView.ScaleType.FIT_XY);
        bg.setImageResource(R.drawable.tile_off);
        f.addView(bg, new FrameLayout.LayoutParams(-1, -1));
        ImageView ic = new ImageView(this);
        ic.setImageResource(icon);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER);
        f.addView(ic, ip);
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, dp(58));
        fp.setMargins(dp(5), 0, dp(5), 0);
        c.addView(f, fp);

        TextView t = Ui.text(this, label, 10.5f, Ui.LIGHT, false);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        c.addView(t, new LinearLayout.LayoutParams(-1, -2));

        f.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { click.run(); h.postDelayed(new Runnable() {
                @Override public void run() { refreshTiles(); }
            }, 250); }
        });
        Tile tl = new Tile();
        tl.bg = bg;
        tl.on = on;
        tiles.add(tl);
        return c;
    }

    private void refreshTiles() {
        if (tiles.isEmpty()) return;
        for (Tile t : tiles) {
            boolean on;
            try { on = t.on.getAsBoolean(); } catch (Exception e) { on = false; }
            t.bg.setImageResource(on ? R.drawable.tile_on : R.drawable.tile_off);
        }
        // grandes tuiles
        boolean wifi = false;
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
            wifi = nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
        } catch (Exception ignored) { }
        bigWifi.setBackground(wifi ? Ui.grad(this, 26, 0xFFA45CFF, 0xFF5A1FE0, 0xAAF3E6FF)
                : Ui.glass(this, 26, 0x55200A4A, 0x889B5CFF));
        wifiSub.setText(wifi ? "Connecté" : "Non connecté");

        boolean fw = Prefs.bool(this, Prefs.FW_ON, false);
        Set<String> u = Prefs.getSet(this, Prefs.BLOCK_WIFI);
        u.addAll(Prefs.getSet(this, Prefs.BLOCK_MOB));
        bigData.setBackground(fw ? Ui.grad(this, 26, 0xFFA45CFF, 0xFF5A1FE0, 0xAAF3E6FF)
                : Ui.glass(this, 26, 0x55200A4A, 0x889B5CFF));
        dataSub.setText(fw ? u.size() + " appli(s) limitée(s)" : "Choisir par appli");
        refreshDataPill();
    }

    private void refreshDataPill() {
        if (dataPill == null) return;
        long rx = TrafficStats.getMobileRxBytes(), tx = TrafficStats.getMobileTxBytes();
        String s;
        if (rx == TrafficStats.UNSUPPORTED || tx == TrafficStats.UNSUPPORTED) {
            s = "Données mobiles  ›";
        } else {
            long mb = (rx + tx) / (1024 * 1024);
            s = "💧 " + mb + " Mo en données mobiles depuis le démarrage  ›";
        }
        dataPill.setText(s);
    }

    private void openPanel() {
        if (panelOpen) return;
        panelOpen = true;
        refreshTiles();
        syncSliders();
        panel.animate().translationY(0).setDuration(300).setInterpolator(new DecelerateInterpolator()).start();
    }

    private void closePanel() {
        if (!panelOpen) return;
        panelOpen = false;
        panel.animate().translationY(-root.getHeight()).setDuration(260)
                .setInterpolator(new AccelerateInterpolator()).start();
    }

    private void syncSliders() {
        try {
            float v = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, 128) / 255f;
            bright.setValue(v);
        } catch (Exception ignored) { }
        int max = Math.max(1, audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        vol.setValue(audio.getStreamVolume(AudioManager.STREAM_MUSIC) / (float) max);
    }

    // ---------- actions des tuiles ----------
    private void openSettings(Intent i) {
        try {
            startActivity(i);
            closePanel();
        } catch (Exception e) {
            Toast.makeText(this, "Réglage indisponible sur ce téléphone", Toast.LENGTH_SHORT).show();
        }
    }

    private void openTether() {
        try {
            startActivity(new Intent().setClassName("com.android.settings", "com.android.settings.TetherSettings"));
            closePanel();
        } catch (Exception e) {
            openSettings(new Intent(Settings.ACTION_WIRELESS_SETTINGS));
        }
    }

    private void initTorch() {
        try {
            camMgr = (CameraManager) getSystemService(Context.CAMERA_SERVICE);
            for (String id : camMgr.getCameraIdList()) {
                CameraCharacteristics cc = camMgr.getCameraCharacteristics(id);
                Boolean fl = cc.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer lf = cc.get(CameraCharacteristics.LENS_FACING);
                if (Boolean.TRUE.equals(fl) && lf != null && lf == CameraCharacteristics.LENS_FACING_BACK) {
                    torchId = id;
                    break;
                }
            }
            camMgr.registerTorchCallback(new CameraManager.TorchCallback() {
                @Override public void onTorchModeChanged(String id, boolean enabled) {
                    if (id.equals(torchId)) { torchOn = enabled; refreshTiles(); }
                }
            }, h);
        } catch (Exception ignored) { }
    }

    private void toggleTorch() {
        try {
            camMgr.setTorchMode(torchId, !torchOn);
        } catch (Exception e) {
            Toast.makeText(this, "Lampe indisponible", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleVibrate() {
        try {
            boolean vib = audio.getRingerMode() == AudioManager.RINGER_MODE_VIBRATE;
            audio.setRingerMode(vib ? AudioManager.RINGER_MODE_NORMAL : AudioManager.RINGER_MODE_VIBRATE);
        } catch (Exception e) {
            Toast.makeText(this, "Active d'abord l'accès « Ne pas déranger » (étape Réglages)", Toast.LENGTH_LONG).show();
        }
    }

    private void toggleRotation() {
        if (!Settings.System.canWrite(this)) {
            askWriteSettings();
            return;
        }
        int cur = Settings.System.getInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, 0);
        Settings.System.putInt(getContentResolver(), Settings.System.ACCELEROMETER_ROTATION, cur == 1 ? 0 : 1);
    }

    private void askWriteSettings() {
        Toast.makeText(this, "Autorise la modification des réglages système", Toast.LENGTH_LONG).show();
        try {
            startActivity(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
        } catch (Exception ignored) { }
    }

    private void toggleDnd() {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm.isNotificationPolicyAccessGranted()) {
            boolean on = nm.getCurrentInterruptionFilter() != NotificationManager.INTERRUPTION_FILTER_ALL;
            nm.setInterruptionFilter(on ? NotificationManager.INTERRUPTION_FILTER_ALL
                    : NotificationManager.INTERRUPTION_FILTER_PRIORITY);
        } else {
            openSettings(new Intent(Settings.ACTION_NOTIFICATION_POLICY_ACCESS_SETTINGS));
        }
    }

    private void toggleFirewall() {
        if (Prefs.bool(this, Prefs.FW_ON, false)) {
            FirewallService.stop(this);
        } else if (VpnService.prepare(this) == null) {
            Prefs.sp(this).edit().putBoolean(Prefs.FW_ON, true).apply();
            FirewallService.start(this);
        } else {
            startActivity(new Intent(this, DataActivity.class).putExtra("enable", true));
            closePanel();
        }
    }

    private void setBrightness(float v) {
        v = Math.max(0.02f, Math.min(1f, v));
        if (Settings.System.canWrite(this)) {
            try {
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS_MODE,
                        Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL);
                Settings.System.putInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS, Math.round(v * 255));
            } catch (Exception ignored) { }
        } else {
            WindowManager.LayoutParams lp = getWindow().getAttributes();
            lp.screenBrightness = v;
            getWindow().setAttributes(lp);
            if (!warnedBright) {
                warnedBright = true;
                Toast.makeText(this, "Pour régler toute la luminosité : Réglages Nuit > étape 6", Toast.LENGTH_LONG).show();
            }
        }
    }
}
