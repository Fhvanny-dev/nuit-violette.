package com.nuitviolette.launcher;

import android.content.Intent;
import android.net.VpnService;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

/** Tuile des réglages rapides Android : active / coupe le contrôle des données. */
public class DataTile extends TileService {
    @Override
    public void onStartListening() { refresh(); }

    @Override
    public void onClick() {
        boolean on = Prefs.bool(this, Prefs.FW_ON, false);
        if (on) {
            FirewallService.stop(this);
        } else if (VpnService.prepare(this) == null) {
            Prefs.sp(this).edit().putBoolean(Prefs.FW_ON, true).apply();
            FirewallService.start(this);
        } else {
            Intent i = new Intent(this, DataActivity.class)
                    .putExtra("enable", true)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivityAndCollapse(i);
        }
        refresh();
    }

    private void refresh() {
        Tile t = getQsTile();
        if (t == null) return;
        t.setState(Prefs.bool(this, Prefs.FW_ON, false) ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        t.updateTile();
    }
}
