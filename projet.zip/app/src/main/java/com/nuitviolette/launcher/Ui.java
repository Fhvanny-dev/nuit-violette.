package com.nuitviolette.launcher;

import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.widget.TextView;

final class Ui {
    static final int LIGHT = 0xFFF3E6FF;
    static final int SOFT = 0xFFD8C2FF;
    static final int VIOLET = 0xFF9B5CFF;
    static final int GLOW = 0xFFC58BFF;

    static int dp(Context c, float v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    static GradientDrawable glass(Context c, float radiusDp, int fill, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(c, radiusDp));
        g.setStroke(Math.max(1, dp(c, 1.2f)), stroke);
        return g;
    }

    static GradientDrawable grad(Context c, float radiusDp, int top, int bottom, int stroke) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{top, bottom});
        g.setCornerRadius(dp(c, radiusDp));
        g.setStroke(Math.max(1, dp(c, 1.2f)), stroke);
        return g;
    }

    static TextView text(Context c, CharSequence s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static void glow(TextView t, int color, float radiusDp) {
        t.setShadowLayer(dp(t.getContext(), radiusDp), 0, 0, color);
    }
}
