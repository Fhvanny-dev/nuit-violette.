package com.nuitviolette.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

/**
 * Barre de l'accueil, identique à la maquette (image 4) : le décor (verre violet, loupe, « Rechercher », ✦,
 * séparateurs) vient de l'image de la maquette ; seuls la météo, la température et le jour sont dessinés en direct.
 */
final class SearchPill extends View {
    interface OnSearch { void go(); }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG | Paint.DITHER_FLAG);
    private final RectF rf = new RectF();
    private final Bitmap bg, wxMoonCloud;
    private String temp = "--°";
    private String day = "";
    private int code = -1;      // code météo Open-Meteo, -1 = inconnu
    private boolean night = true;
    private OnSearch cb;

    SearchPill(Context c) {
        super(c);
        bg = BitmapFactory.decodeResource(c.getResources(), R.drawable.pill_bg);
        wxMoonCloud = BitmapFactory.decodeResource(c.getResources(), R.drawable.wx_cloud_moon);
    }

    void setOnSearch(OnSearch c) { cb = c; }

    void setDay(String d) {
        if (!d.equals(day)) { day = d; invalidate(); }
    }

    void setWeather(String t, int wmoCode, boolean isNight) {
        temp = t; code = wmoCode; night = isNight;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        if (bg != null) {
            rf.set(0, 0, w, h);
            c.drawBitmap(bg, null, rf, p);
        }

        // texte : même police sans empattement, blanc, léger halo violet comme sur la maquette
        float base = h * 0.648f;
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        p.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        p.setTextSize(h * 0.42f);
        p.setShadowLayer(h * 0.08f, 0, 0, 0x889B5CFF);
        p.setTextAlign(Paint.Align.LEFT);
        c.drawText(temp, w * 0.1997f, base, p);
        p.setTextAlign(Paint.Align.CENTER);
        c.drawText(day, w * 0.8872f, base, p);
        p.setShadowLayer(0, 0, 0, 0);
        p.setTextAlign(Paint.Align.LEFT);

        // pictogramme météo, dans le même cadre que sur la maquette
        float ix0 = w * 0.0661f, ix1 = w * 0.181f, iy0 = h * 0.148f, iy1 = h * 0.852f;
        boolean rain = (code >= 51 && code <= 67) || (code >= 80 && code <= 82) || code >= 95;
        boolean snow = (code >= 71 && code <= 77) || code == 85 || code == 86;
        boolean clear = code == 0 || code == 1;
        if (night && !rain && !snow && !clear && wxMoonCloud != null) {
            rf.set(ix0, iy0, ix1, iy1);
            c.drawBitmap(wxMoonCloud, null, rf, p);
        } else {
            drawVector(c, (ix0 + ix1) / 2f, (iy0 + iy1) / 2f, (iy1 - iy0), rain, snow, clear);
        }
    }

    /** Autres météos : soleil / lune seuls, ou nuage avec pluie ou neige. */
    private void drawVector(Canvas c, float cx, float cy, float s, boolean rain, boolean snow, boolean clear) {
        boolean cloud = !clear;
        float ax = cx + (cloud && !(rain || snow) ? s * 0.16f : 0f), ay = cy - (cloud ? s * 0.18f : 0f);
        float ar = s * (cloud ? 0.30f : 0.38f);
        p.setShader(null);
        if (!(rain || snow)) {
            if (night) {
                p.setStyle(Paint.Style.FILL);
                p.setShader(new LinearGradient(ax - ar, ay - ar, ax + ar, ay + ar, 0xFFFFE9A8, 0xFFFFB63D, Shader.TileMode.CLAMP));
                c.drawCircle(ax, ay, ar, p);
                p.setShader(null);
                p.setColor(0xFF1B0650);               // croissant : on découpe avec la couleur du fond de la barre
                c.drawCircle(ax + ar * 0.5f, ay - ar * 0.3f, ar * 0.82f, p);
            } else {
                p.setStyle(Paint.Style.FILL);
                p.setShader(new RadialGradient(ax, ay, ar, 0xFFFFF2B0, 0xFFFFA928, Shader.TileMode.CLAMP));
                c.drawCircle(ax, ay, ar * 0.72f, p);
                p.setShader(null);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(ar * 0.16f);
                p.setColor(0xFFFFC857);
                for (int i = 0; i < 8; i++) {
                    double a = i * Math.PI / 4;
                    c.drawLine((float) (ax + Math.cos(a) * ar * 0.95f), (float) (ay + Math.sin(a) * ar * 0.95f),
                            (float) (ax + Math.cos(a) * ar * 1.22f), (float) (ay + Math.sin(a) * ar * 1.22f), p);
                }
                p.setStrokeCap(Paint.Cap.BUTT);
            }
        }
        if (cloud) {
            float bx = cx, by = cy + s * 0.12f;
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, by - s * 0.3f, 0, by + s * 0.24f, 0xFFFFFFFF, 0xFFC9B4F2, Shader.TileMode.CLAMP));
            c.drawCircle(bx - s * 0.20f, by + s * 0.02f, s * 0.20f, p);
            c.drawCircle(bx + s * 0.02f, by - s * 0.10f, s * 0.27f, p);
            c.drawCircle(bx + s * 0.26f, by + s * 0.03f, s * 0.19f, p);
            rf.set(bx - s * 0.40f, by - s * 0.02f, bx + s * 0.45f, by + s * 0.22f);
            c.drawRoundRect(rf, s * 0.11f, s * 0.11f, p);
            p.setShader(null);
            if (rain || snow) {
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(s * 0.07f);
                p.setColor(snow ? 0xFFFFFFFF : 0xFF8FD0FF);
                for (int i = -1; i <= 1; i++) {
                    float x = bx + i * s * 0.2f;
                    c.drawLine(x, by + s * 0.30f, x - s * 0.05f, by + s * 0.45f, p);
                }
                p.setStrokeCap(Paint.Cap.BUTT);
            }
        }
        p.setStyle(Paint.Style.FILL);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        float x = e.getX() / Math.max(1f, getWidth());
        boolean mid = x > 0.34f && x < 0.81f;
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                return mid;
            case MotionEvent.ACTION_UP:
                if (mid && cb != null) cb.go();
                return true;
            default:
                return true;
        }
    }
}
