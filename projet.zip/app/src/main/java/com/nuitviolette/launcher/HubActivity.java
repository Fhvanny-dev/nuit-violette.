package com.nuitviolette.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.WallpaperManager;
import android.app.role.RoleManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowInsets;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Centre de réglages : installation guidée + options du thème. */
public class HubActivity extends Activity {
    private LinearLayout box;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);
        ScrollView sv = new ScrollView(this);
        sv.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF1A0845, 0xFF080116}));
        box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        sv.addView(box, new ScrollView.LayoutParams(-1, -2));
        sv.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets ins) {
                v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
                return ins;
            }
        });
        setContentView(sv);
    }

    @Override
    protected void onResume() {
        super.onResume();
        build();
    }

    // ---------- états ----------
    private boolean isHome() {
        Intent i = new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME);
        android.content.pm.ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        return ri != null && ri.activityInfo != null && getPackageName().equals(ri.activityInfo.packageName);
    }

    private boolean listenerOn() {
        String s = Settings.Secure.getString(getContentResolver(), "enabled_notification_listeners");
        return s != null && s.contains(getPackageName());
    }

    private boolean postOk() {
        return Build.VERSION.SDK_INT < 33
                || checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED;
    }

    // ---------- interface ----------
    private void build() {
        box.removeAllViews();
        int m = Ui.dp(this, 18);

        TextView t = Ui.text(this, "Nuit violette ♡", 28, Color.WHITE, true);
        Ui.glow(t, Ui.GLOW, 10);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.setMargins(m, Ui.dp(this, 22), m, 0);
        box.addView(t, tp);
        TextView s = Ui.text(this, "Réglages du thème. Fais les étapes de haut en bas ; chaque pastille passe au vert quand c'est fait.",
                13.5f, Ui.SOFT, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(m, Ui.dp(this, 6), m, Ui.dp(this, 12));
        box.addView(s, sp);

        card("1. Launcher par défaut",
                "Choisis « Nuit violette » comme écran d'accueil : le thème s'applique à l'accueil, au tiroir d'applications, aux icônes et au panneau rapide.",
                isHome(), "Choisir comme launcher", new Runnable() { @Override public void run() { askHome(); } });

        card("2. Pop-ups de notification (style iPhone)",
                "Autorise l'accès aux notifications. Si le bouton est grisé : Paramètres > Applications > Nuit violette > ⋮ > « Autoriser les paramètres restreints », puis reviens ici.",
                listenerOn(), "Autoriser les notifications", new Runnable() {
                    @Override public void run() { open(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")); }
                });

        card("3. Affichage par-dessus les applications",
                "Nécessaire pour faire apparaître les bannières par-dessus les autres applis.",
                Settings.canDrawOverlays(this), "Autoriser l'affichage", new Runnable() {
                    @Override public void run() {
                        open(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
                    }
                });

        card("4. Notifications de l'application",
                "Nécessaire à partir d'Android 13 pour la notification du pare-feu et pour le test.",
                postOk(), "Autoriser", new Runnable() {
                    @Override public void run() {
                        if (Build.VERSION.SDK_INT >= 33) requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 3);
                    }
                });

        card("5. Contrôle des données par application",
                "Choisis quelles applications peuvent utiliser le Wi-Fi ou ton forfait mobile. Une tuile « Données par appli » est aussi ajoutée aux réglages rapides d'Android.",
                Prefs.bool(this, Prefs.FW_ON, false), "Ouvrir le contrôle des données", new Runnable() {
                    @Override public void run() { startActivity(new Intent(HubActivity.this, DataActivity.class)); }
                });

        card("6. Modifier les réglages système",
                "Permet au curseur de luminosité et à la tuile « rotation » du panneau de fonctionner partout.",
                Settings.System.canWrite(this), "Autoriser", new Runnable() {
                    @Override public void run() {
                        open(new Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:" + getPackageName())));
                    }
                });

        card("7. Fond d'écran Nuit violette",
                "Applique l'aurore violette comme fond d'écran de tout le téléphone (accueil et écran verrouillé).",
                null, "Appliquer le fond d'écran", new Runnable() { @Override public void run() { applyWallpaper(); } });

        card("Pop-ups de notification",
                Prefs.bool(this, Prefs.POP, true) ? "Activés. Appuie pour les couper." : "Coupés. Appuie pour les réactiver.",
                null, Prefs.bool(this, Prefs.POP, true) ? "Couper les pop-ups" : "Activer les pop-ups", new Runnable() {
                    @Override public void run() {
                        Prefs.sp(HubActivity.this).edit().putBoolean(Prefs.POP, !Prefs.bool(HubActivity.this, Prefs.POP, true)).apply();
                        build();
                    }
                });

        card("Tester un pop-up",
                "Envoie une notification d'essai pour voir la bannière.",
                null, "Envoyer un test", new Runnable() { @Override public void run() { testNotif(); } });

        card("Applications masquées",
                "Les applis masquées disparaissent du tiroir, de l'accueil et de la recherche, et leurs notifications ne s'affichent plus en pop-up. Elles restent dans l'onglet « Masquées » du tiroir, protégé par un code à 4 chiffres.",
                null, "Choisir les applis à masquer", new Runnable() {
                    @Override public void run() { Pin.ask(HubActivity.this, new Runnable() { @Override public void run() { pickHidden(); } }); }
                });

        card("Code des applis masquées",
                "Change le code à 4 chiffres.",
                null, "Changer le code", new Runnable() {
                    @Override public void run() {
                        if (Prefs.sp(HubActivity.this).getString(Prefs.PIN, null) == null) {
                            Pin.ask(HubActivity.this, null);
                        } else {
                            Pin.ask(HubActivity.this, new Runnable() {
                                @Override public void run() {
                                    Prefs.sp(HubActivity.this).edit().remove(Prefs.PIN).apply();
                                    Pin.ask(HubActivity.this, null);
                                }
                            });
                        }
                    }
                });

        TextView note = Ui.text(this,
                "À savoir : Android ne laisse pas une application recolorer la barre d'état ni les autres applications. "
                        + "Le thème couvre l'écran d'accueil, le tiroir, les icônes, le panneau rapide, les pop-ups et le fond d'écran.",
                12, 0xFFB79BE8, false);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(-1, -2);
        np.setMargins(m, Ui.dp(this, 8), m, Ui.dp(this, 30));
        box.addView(note, np);
    }

    /** ok = null pour une action sans état. */
    private void card(String title, String desc, Boolean ok, String btn, final Runnable action) {
        int m = Ui.dp(this, 16);
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setPadding(Ui.dp(this, 16), Ui.dp(this, 14), Ui.dp(this, 16), Ui.dp(this, 14));
        c.setBackground(Ui.glass(this, 22, 0x33FFFFFF, 0x669B5CFF));

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView tt = Ui.text(this, title, 16.5f, Color.WHITE, true);
        top.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
        if (ok != null) {
            TextView dot = Ui.text(this, ok ? "✓ fait" : "à faire", 12, ok ? 0xFF8DF2B0 : 0xFFFFB4C8, true);
            top.addView(dot);
        }
        c.addView(top);
        TextView d = Ui.text(this, desc, 13, Ui.SOFT, false);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(-1, -2);
        dp.setMargins(0, Ui.dp(this, 4), 0, Ui.dp(this, 10));
        c.addView(d, dp);
        TextView b = Ui.text(this, btn, 14.5f, Color.WHITE, true);
        b.setGravity(Gravity.CENTER);
        b.setPadding(0, Ui.dp(this, 11), 0, Ui.dp(this, 11));
        b.setBackground(Ui.grad(this, 20, 0xFFA45CFF, 0xFF5A1FE0, 0xAAF3E6FF));
        b.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { action.run(); }
        });
        c.addView(b, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(m, 0, m, Ui.dp(this, 12));
        box.addView(c, lp);
    }

    private void open(Intent i) {
        try {
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Impossible d'ouvrir ce réglage sur ce téléphone", Toast.LENGTH_LONG).show();
        }
    }

    private void askHome() {
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                RoleManager rm = (RoleManager) getSystemService(Context.ROLE_SERVICE);
                if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                    startActivityForResult(rm.createRequestRoleIntent(RoleManager.ROLE_HOME), 5);
                    return;
                }
            }
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Exception e) {
            startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME));
        }
    }

    private void applyWallpaper() {
        Toast.makeText(this, "Application du fond d'écran…", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override public void run() {
                boolean ok;
                try {
                    Bitmap bm = BitmapFactory.decodeResource(getResources(), R.drawable.bg_home);
                    WallpaperManager wm = WallpaperManager.getInstance(HubActivity.this);
                    wm.setBitmap(bm, null, true, WallpaperManager.FLAG_SYSTEM | WallpaperManager.FLAG_LOCK);
                    ok = true;
                } catch (Exception e) {
                    ok = false;
                }
                final boolean fin = ok;
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        Toast.makeText(HubActivity.this,
                                fin ? "Fond d'écran appliqué ♡" : "Impossible d'appliquer le fond d'écran",
                                Toast.LENGTH_LONG).show();
                    }
                });
            }
        }).start();
    }

    private void testNotif() {
        if (!postOk()) {
            Toast.makeText(this, "Autorise d'abord les notifications (étape 4)", Toast.LENGTH_LONG).show();
            return;
        }
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel("nv_test", "Test", NotificationManager.IMPORTANCE_HIGH));
        }
        Bundle ex = new Bundle();
        ex.putBoolean("nv_test", true);
        Notification n = new Notification.Builder(this, "nv_test")
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle("Nuit violette ♡")
                .setContentText("Voilà à quoi ressembleront tes notifications.")
                .addExtras(ex)
                .setAutoCancel(true)
                .build();
        nm.notify(42, n);
        if (!listenerOn() || !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Termine les étapes 2 et 3 pour voir le pop-up", Toast.LENGTH_LONG).show();
        }
    }

    private void pickHidden() {
        Toast.makeText(this, "Chargement des applications…", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override public void run() {
                final List<Apps.App> l = Apps.load(HubActivity.this);
                final List<String> pk = new ArrayList<String>();
                final List<String> names = new ArrayList<String>();
                for (Apps.App a : l) {
                    if (pk.contains(a.pkg)) continue;
                    pk.add(a.pkg);
                    names.add(a.label);
                }
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        final Set<String> hid = Prefs.getSet(HubActivity.this, Prefs.HIDDEN);
                        final boolean[] chk = new boolean[pk.size()];
                        for (int i = 0; i < chk.length; i++) chk[i] = hid.contains(pk.get(i));
                        new AlertDialog.Builder(HubActivity.this, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                                .setTitle("Applications à masquer")
                                .setMultiChoiceItems(names.toArray(new String[0]), chk,
                                        new android.content.DialogInterface.OnMultiChoiceClickListener() {
                                            @Override public void onClick(android.content.DialogInterface d, int which, boolean on) {
                                                chk[which] = on;
                                            }
                                        })
                                .setNegativeButton("Annuler", null)
                                .setPositiveButton("OK", new android.content.DialogInterface.OnClickListener() {
                                    @Override public void onClick(android.content.DialogInterface d, int w) {
                                        Set<String> s = new HashSet<String>();
                                        for (int i = 0; i < chk.length; i++) if (chk[i]) s.add(pk.get(i));
                                        Prefs.putSet(HubActivity.this, Prefs.HIDDEN, s);
                                        Toast.makeText(HubActivity.this, s.size() + " appli(s) masquée(s)", Toast.LENGTH_SHORT).show();
                                    }
                                })
                                .show();
                    }
                });
            }
        }).start();
    }
}
