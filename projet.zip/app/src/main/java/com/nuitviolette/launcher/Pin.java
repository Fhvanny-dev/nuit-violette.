package com.nuitviolette.launcher;

import android.app.Activity;
import android.app.AlertDialog;
import android.text.InputFilter;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.Toast;

import java.security.MessageDigest;

/** Code à 4 chiffres qui protège l'espace des applications masquées. */
final class Pin {
    static String hash(String s) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] d = md.digest(("nv:" + s).getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte x : d) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return s;
        }
    }

    /** Demande le code (ou le crée la première fois), puis exécute ok. */
    static void ask(final Activity a, final Runnable ok) {
        final String stored = Prefs.sp(a).getString(Prefs.PIN, null);
        final EditText e = new EditText(a);
        e.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD);
        e.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});
        e.setGravity(Gravity.CENTER);
        e.setTextSize(26);
        new AlertDialog.Builder(a, AlertDialog.THEME_DEVICE_DEFAULT_DARK)
                .setTitle(stored == null ? "Crée un code à 4 chiffres" : "Code des applis masquées")
                .setView(e)
                .setNegativeButton("Annuler", null)
                .setPositiveButton("OK", (d, w) -> {
                    String v = e.getText().toString();
                    if (v.length() != 4) {
                        Toast.makeText(a, "4 chiffres, s'il te plaît", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (stored == null) {
                        Prefs.sp(a).edit().putString(Prefs.PIN, hash(v)).apply();
                        if (ok != null) ok.run();
                    } else if (hash(v).equals(stored)) {
                        if (ok != null) ok.run();
                    } else {
                        Toast.makeText(a, "Code incorrect", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }
}
