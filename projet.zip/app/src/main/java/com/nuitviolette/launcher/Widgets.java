package com.nuitviolette.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

/** Curseur vertical (luminosité / volume) dessiné à la main. */
final class VSlider extends View {
    interface OnChange { void on(float v); }

    private final int kind; // 0 = soleil, 1 = haut-parleur
    private float value = 0.5f;
    private OnChange cb;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final RectF rf = new RectF();

    VSlider(Context c, int kind) { super(c); this.kind = kind; }

    void setOnChange(OnChange c) { cb = c; }

    void setValue(float v) { value = Math.max(0f, Math.min(1f, v)); invalidate(); }

    @Override
    protected void onDraw(Canvas cv) {
        int w = getWidth(), h = getHeight();
        float r = w * 0.36f;
        rf.set(0, 0, w, h);
        path.reset();
        path.addRoundRect(rf, r, r, Path.Direction.CW);
        cv.save();
        cv.clipPath(path);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, h, 0xFF2C0D58, 0xFF0B0220, Shader.TileMode.CLAMP));
        cv.drawRect(0, 0, w, h, p);
        float top = h * (1f - value);
        p.setShader(new LinearGradient(0, top, 0, h, 0xFFF4ECFF, 0xFFA98AF0, Shader.TileMode.CLAMP));
        cv.drawRect(0, top, w, h, p);
        p.setShader(null);
        cv.restore();

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(Math.max(2f, w * 0.025f));
        p.setColor(0xAAC9A0FF);
        RectF in = new RectF(1, 1, w - 1, h - 1);
        cv.drawRoundRect(in, r, r, p);

        // pictogramme en bas
        float cx = w / 2f, cy = h - w * 0.52f, s = w * 0.2f;
        int col = (value > 0.12f) ? 0xFF3A0C78 : 0xFFF4EAFF;
        p.setColor(col);
        if (kind == 0) {
            p.setStyle(Paint.Style.FILL);
            cv.drawCircle(cx, cy, s * 0.8f, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(s * 0.3f);
            p.setStrokeCap(Paint.Cap.ROUND);
            for (int i = 0; i < 8; i++) {
                double a = i * Math.PI / 4;
                float x1 = (float) (cx + Math.cos(a) * s * 1.25f), y1 = (float) (cy + Math.sin(a) * s * 1.25f);
                float x2 = (float) (cx + Math.cos(a) * s * 1.7f), y2 = (float) (cy + Math.sin(a) * s * 1.7f);
                cv.drawLine(x1, y1, x2, y2, p);
            }
        } else {
            p.setStyle(Paint.Style.FILL);
            Path sp = new Path();
            sp.moveTo(cx - s * 1.5f, cy - s * 0.6f);
            sp.lineTo(cx - s * 0.6f, cy - s * 0.6f);
            sp.lineTo(cx + s * 0.4f, cy - s * 1.5f);
            sp.lineTo(cx + s * 0.4f, cy + s * 1.5f);
            sp.lineTo(cx - s * 0.6f, cy + s * 0.6f);
            sp.lineTo(cx - s * 1.5f, cy + s * 0.6f);
            sp.close();
            cv.drawPath(sp, p);
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(s * 0.3f);
            p.setStrokeCap(Paint.Cap.ROUND);
            RectF a1 = new RectF(cx - s * 0.2f, cy - s * 0.9f, cx + s * 1.4f, cy + s * 0.9f);
            cv.drawArc(a1, -50, 100, false, p);
            RectF a2 = new RectF(cx - s * 0.5f, cy - s * 1.5f, cx + s * 2.0f, cy + s * 1.5f);
            cv.drawArc(a2, -50, 100, false, p);
        }
        p.setStrokeCap(Paint.Cap.BUTT);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                set(e.getY());
                return true;
            case MotionEvent.ACTION_MOVE:
                set(e.getY());
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(false);
                return true;
            default:
                return true;
        }
    }

    private void set(float y) {
        float h = Math.max(1, getHeight());
        setValue(1f - y / h);
        if (cb != null) cb.on(value);
    }
}

/** Petit pictogramme Wi-Fi. */
final class WifiGlyph extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);

    WifiGlyph(Context c) { super(c); }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h * 0.82f;
        p.setColor(0xFFFFFFFF);
        p.setStyle(Paint.Style.FILL);
        cv.drawCircle(cx, cy, w * 0.07f, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(w * 0.09f);
        for (int i = 1; i <= 3; i++) {
            float r = w * 0.2f * i;
            RectF rf = new RectF(cx - r, cy - r, cx + r, cy + r);
            cv.drawArc(rf, 225, 90, false, p);
        }
    }
}
