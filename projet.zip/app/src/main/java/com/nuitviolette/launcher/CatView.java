package com.nuitviolette.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.view.View;

import java.util.Calendar;

/** Le chat sur son nuage, comme dans la version HTML : respire, cligne, s'endort, ZZ. */
class CatView extends View {
    static long wakeUntil = 0;
    private final Bitmap cat, zz;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Path clip = new Path();
    private final RectF r = new RectF();
    private final long t0 = System.currentTimeMillis();

    CatView(Context c) {
        super(c);
        cat = BitmapFactory.decodeResource(getResources(), R.drawable.cat);
        zz = BitmapFactory.decodeResource(getResources(), R.drawable.zz);
        setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { wakeUntil = System.currentTimeMillis() + 120000; invalidate(); }
        });
    }

    /** 0 = réveillé, 1 = somnolent, 2 = endormi (mêmes horaires que le HTML) */
    static int mood() {
        if (System.currentTimeMillis() < wakeUntil) return 0;
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        return h >= 6 && h < 18 ? 0 : (h >= 18 && h < 20 ? 1 : 2);
    }

    @Override
    protected void onMeasure(int w, int hh) {
        int width = MeasureSpec.getSize(w);
        setMeasuredDimension(width, Math.round(width * 173f / 219f));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float s = getWidth() / 219f;
        long t = System.currentTimeMillis() - t0;
        int m = mood();
        boolean look = System.currentTimeMillis() < wakeUntil;
        float oy = 43 * s;
        cv.save();
        if (m == 0) {
            float ph = (t % 6800) / 3400f;
            float f = ph <= 1 ? ph : 2 - ph;
            f = f * f * (3 - 2 * f);
            cv.translate(-0.005f * 219 * s * f, -0.05f * 130 * s * f);
        }
        r.set(0, oy, 219 * s, oy + 130 * s);
        cv.drawBitmap(cat, null, r, p);
        if (m < 2) {
            float ph = (t % 4600) / 4600f;
            float sy = ph < .92f ? 1f : (ph < .95f ? 1f - (ph - .92f) / .03f * .92f : .08f + (ph - .95f) / .05f * .92f);
            if (m == 1) sy = 1f;
            float[][] eyes = {{66, 68}, {99, 63}};
            for (float[] e : eyes) {
                float cx = e[0] * s, cy = oy + e[1] * s;
                cv.save();
                cv.scale(1f, sy, cx, cy);
                p.setColor(0xFF13072B);
                r.set(cx - 6.6f * s, cy - 8 * s, cx + 6.6f * s, cy + 8 * s);
                cv.drawOval(r, p);
                cv.restore();
                if (m == 1) {
                    clip.reset();
                    clip.addOval(r, Path.Direction.CW);
                    cv.save();
                    cv.clipPath(clip);
                    p.setColor(0xFFEFE7F9);
                    cv.drawRect(cx - 8 * s, cy - 9 * s, cx + 8 * s, cy, p);
                    cv.restore();
                }
                float hx = cx + (2f - (look ? 0f : 1.6f)) * s, hy = cy - 3 * s;
                p.setColor(0xFFFFFFFF);
                if (m == 0) cv.drawCircle(hx, hy, 2.2f * s, p);
            }
        }
        cv.restore();
        if (m == 2) {
            float ph = (t % 3200) / 3200f;
            float f = (float) Math.sin(ph * Math.PI);
            p.setAlpha(Math.round(255 * (1f - .35f * f)));
            float zx = 98 * s + .03f * 80 * s * f, zy = -.08f * 60 * s * f;
            r.set(zx, zy, zx + 80 * s, zy + 60 * s);
            cv.drawBitmap(zz, null, r, p);
            p.setAlpha(255);
        }
        postInvalidateDelayed(33);
    }
}
