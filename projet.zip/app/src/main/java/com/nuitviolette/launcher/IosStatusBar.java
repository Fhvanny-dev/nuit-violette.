package com.nuitviolette.launcher;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiManager;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.view.View;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * Barre d'état à la iPhone, dessinée par le launcher : heure à gauche ; à droite les barres du réseau,
 * le Wi-Fi (ou 4G/5G) et la batterie avec son pourcentage à l'intérieur.
 */
final class IosStatusBar extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rf = new RectF();
    private final float d;

    private String time = "";
    private int batt = 100;
    private boolean charging;
    private int cell = 4;            // 0..4 barres
    private boolean wifi;
    private int wifiLvl = 3;         // 0..3
    private String net = "";         // 4G / 5G / 3G / ""
    private boolean noSim;

    IosStatusBar(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
    }

    /** Relit l'heure, la batterie et le réseau. */
    void refresh() {
        Context c = getContext();
        time = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date());
        try {
            Intent b = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (b != null) {
                int lv = b.getIntExtra("level", -1), sc = b.getIntExtra("scale", 100);
                if (lv >= 0 && sc > 0) batt = Math.round(lv * 100f / sc);
                int st = b.getIntExtra("status", -1);
                charging = st == 2 || st == 5;
            }
        } catch (Throwable ignored) { }
        try {
            ConnectivityManager cm = (ConnectivityManager) c.getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkCapabilities nc = cm.getNetworkCapabilities(cm.getActiveNetwork());
            wifi = nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI);
            if (wifi) {
                WifiManager wm = (WifiManager) c.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                int rssi = wm.getConnectionInfo().getRssi();
                wifiLvl = rssi > -55 ? 3 : rssi > -67 ? 2 : rssi > -80 ? 1 : 0;
            }
        } catch (Throwable ignored) { }
        try {
            TelephonyManager tm = (TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            noSim = tm.getSimState() != TelephonyManager.SIM_STATE_READY;
            cell = noSim ? 0 : 4;
            net = "";
            try {
                SignalStrength ss = tm.getSignalStrength();
                if (ss != null && !noSim) cell = Math.max(1, Math.min(4, ss.getLevel()));
            } catch (Throwable ignored) { }
            try {
                int t = tm.getDataNetworkType();
                net = t == 20 ? "5G" : (t == 13 || t == 19) ? "4G" : (t == 3 || t == 8 || t == 9 || t == 10 || t == 15 || t == 17) ? "3G"
                        : (t == 1 || t == 2 || t == 4 || t == 7 || t == 11) ? "E" : "";
            } catch (Throwable ignored) { net = "4G"; }
        } catch (Throwable ignored) { }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float cy = h / 2f + 1f * d;

        // heure
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        p.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        p.setTextSize(16.5f * d);
        p.setTextAlign(Paint.Align.LEFT);
        c.drawText(time, 26f * d, cy + 5.8f * d, p);

        // batterie (à droite)
        float bw = 29f * d, bh = 13.5f * d;
        float bx = w - 20f * d - bw - 2.5f * d, by = cy - bh / 2f;
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.1f * d);
        p.setColor(0x80FFFFFF);
        rf.set(bx, by, bx + bw, by + bh);
        c.drawRoundRect(rf, 4.2f * d, 4.2f * d, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x66FFFFFF);
        rf.set(bx + bw + 1.2f * d, cy - 2.2f * d, bx + bw + 2.6f * d, cy + 2.2f * d);
        c.drawRoundRect(rf, 1f * d, 1f * d, p);
        int fillCol = charging ? 0xFF32D74B : batt <= 20 ? 0xFFFF453A : 0xFFFFFFFF;
        float pad = 1.6f * d;
        float fw = Math.max(3f * d, (bw - 2 * pad) * Math.max(0, Math.min(100, batt)) / 100f);
        p.setColor(fillCol);
        rf.set(bx + pad, by + pad, bx + pad + fw, by + bh - pad);
        c.drawRoundRect(rf, 2.8f * d, 2.8f * d, p);
        // pourcentage à l'intérieur
        p.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        p.setTextSize(9.5f * d);
        p.setTextAlign(Paint.Align.CENTER);
        p.setColor(batt >= 45 || charging ? 0xFF14062E : 0xFFFFFFFF);
        c.drawText(String.valueOf(batt), bx + bw / 2f, cy + 3.4f * d, p);

        // Wi-Fi ou 4G/5G
        float x = bx - 9f * d;
        if (wifi) {
            float wx = x - 16f * d;
            drawWifi(c, wx + 8f * d, cy + 5f * d, 9.5f * d);
            x = wx - 7f * d;
        } else if (!net.isEmpty() && !noSim) {
            p.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            p.setTextSize(13f * d);
            p.setTextAlign(Paint.Align.RIGHT);
            p.setColor(0xFFFFFFFF);
            c.drawText(net, x, cy + 4.6f * d, p);
            x -= p.measureText(net) + 7f * d;
        }
        p.setTextAlign(Paint.Align.LEFT);

        // barres du réseau
        float barW = 3.2f * d, gap = 1.7f * d;
        float[] hs = {4.5f * d, 7f * d, 9.5f * d, 12.5f * d};
        float total = 4 * barW + 3 * gap;
        float sx = x - total;
        p.setStyle(Paint.Style.FILL);
        for (int i = 0; i < 4; i++) {
            p.setColor(i < cell ? 0xFFFFFFFF : 0x59FFFFFF);
            float l = sx + i * (barW + gap);
            rf.set(l, cy + 6.2f * d - hs[i], l + barW, cy + 6.2f * d);
            c.drawRoundRect(rf, 1.1f * d, 1.1f * d, p);
        }
    }

    /** éventail Wi-Fi : point + 2 arcs (+ un 3e) */
    private void drawWifi(Canvas c, float cx, float by, float r) {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(1.9f * d);
        for (int i = 1; i <= 3; i++) {
            float rr = r * i / 3f * 1.25f;
            p.setColor(i <= Math.max(1, wifiLvl) ? 0xFFFFFFFF : 0x59FFFFFF);
            rf.set(cx - rr, by - rr, cx + rr, by + rr);
            c.drawArc(rf, 232, 76, false, p);
        }
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(cx, by - 0.4f * d, 1.6f * d, p);
        p.setStrokeCap(Paint.Cap.BUTT);
    }
}
