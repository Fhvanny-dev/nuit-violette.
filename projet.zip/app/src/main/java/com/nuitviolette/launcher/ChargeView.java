package com.nuitviolette.launcher;

import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.BatteryManager;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.text.style.StyleSpan;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.TextView;

/**
 * Écran d'animation de charge : s'affiche quand on branche le chargeur, compte jusqu'au VRAI pourcentage
 * (mis à jour en direct), puis disparaît tout seul pour laisser l'accueil.
 */
final class ChargeView extends FrameLayout {
    private static final long HOLD_MS = 5200;

    private final Handler h = new Handler(Looper.getMainLooper());
    private final ImageView bg;
    private final TextView pct, sub, pill;
    private final Runnable onGone;
    private ValueAnimator count, breathe, glow;
    private boolean closing;
    private int shown = 0;

    private final Runnable live = new Runnable() {
        @Override public void run() {
            if (closing) return;
            if (count == null || !count.isRunning()) paint(readLevel(getContext()));
            h.postDelayed(this, 1000);
        }
    };
    private final Runnable auto = new Runnable() {
        @Override public void run() { dismiss(); }
    };

    ChargeView(Context c, Runnable onGone) {
        super(c);
        this.onGone = onGone;
        setBackgroundColor(0xFF0B0220);
        setClickable(true);

        bg = new ImageView(c);
        bg.setImageResource(R.drawable.bg_charge);
        bg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        addView(bg, new LayoutParams(-1, -1));

        pct = Ui.text(c, "", 12, Color.WHITE, true);
        pct.setGravity(Gravity.CENTER);
        pct.setSingleLine(true);
        pct.setIncludeFontPadding(false);
        pct.setLetterSpacing(0.04f);
        Ui.glow(pct, 0xFFB47CFF, 14);
        addView(pct, new LayoutParams(-1, -2));

        sub = Ui.text(c, "En charge…", 12, 0xFFF3E6FF, false);
        sub.setGravity(Gravity.CENTER);
        sub.setSingleLine(true);
        Ui.glow(sub, 0xFFB47CFF, 8);
        addView(sub, new LayoutParams(-1, -2));

        pill = Ui.text(c, "", 12, Color.WHITE, false);
        pill.setGravity(Gravity.CENTER);
        pill.setSingleLine(true);
        addView(pill, new LayoutParams(-1, -2));
    }

    static int readLevel(Context c) {
        Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (i == null) return 0;
        int lv = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int sc = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        if (lv < 0 || sc <= 0) return 0;
        return Math.round(lv * 100f / sc);
    }

    private static boolean full(Context c) {
        Intent i = c.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        return i != null && i.getIntExtra(BatteryManager.EXTRA_STATUS, -1) == BatteryManager.BATTERY_STATUS_FULL;
    }

    private void paint(int level) {
        shown = level;
        SpannableString s = new SpannableString(level + "%");
        s.setSpan(new RelativeSizeSpan(0.5f), String.valueOf(level).length(), s.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        pct.setText(s);
        boolean done = level >= 100 || full(getContext());
        sub.setText(done ? "Chargé" : "En charge…");
        String t = level + "% · " + (done ? "Batterie pleine" : "Chargement en cours…");
        SpannableString ps = new SpannableString(t);
        ps.setSpan(new StyleSpan(Typeface.BOLD), 0, String.valueOf(level).length() + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        pill.setText(ps);
    }

    @Override
    protected void onSizeChanged(int w, int hh, int ow, int oh) {
        super.onSizeChanged(w, hh, ow, oh);
        pct.setTextSize(TypedValue.COMPLEX_UNIT_PX, w * 0.17f);
        sub.setTextSize(TypedValue.COMPLEX_UNIT_PX, w * 0.045f);
        pill.setTextSize(TypedValue.COMPLEX_UNIT_PX, w * 0.042f);
        place(pct, hh * 0.219f, hh * 0.10f);
        place(sub, hh * 0.267f, hh * 0.035f);
        place(pill, hh * 0.897f, hh * 0.04f);
    }

    /** Centre verticalement une zone de texte sur la position de l'image d'origine. */
    private void place(TextView t, float centerY, float height) {
        LayoutParams lp = (LayoutParams) t.getLayoutParams();
        lp.width = Math.round(getWidth() * (t == pill ? 0.5f : 1f));
        lp.height = Math.round(height);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.topMargin = Math.round(centerY - height / 2f);
        t.setLayoutParams(lp);
    }

    void start() {
        int target = readLevel(getContext());
        paint(0);
        setAlpha(0f);
        animate().alpha(1f).setDuration(350).start();

        count = ValueAnimator.ofInt(0, target);
        count.setDuration(1400);
        count.setStartDelay(250);
        count.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) { paint((Integer) a.getAnimatedValue()); }
        });
        count.start();

        breathe = ValueAnimator.ofFloat(1f, 1.07f);
        breathe.setDuration(6500);
        breathe.setInterpolator(new android.view.animation.DecelerateInterpolator());
        breathe.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) {
                float v = (Float) a.getAnimatedValue();
                bg.setScaleX(v); bg.setScaleY(v);
            }
        });
        breathe.start();

        glow = ValueAnimator.ofFloat(0.82f, 1f);
        glow.setDuration(900);
        glow.setRepeatCount(ValueAnimator.INFINITE);
        glow.setRepeatMode(ValueAnimator.REVERSE);
        glow.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override public void onAnimationUpdate(ValueAnimator a) { pct.setAlpha((Float) a.getAnimatedValue()); }
        });
        glow.start();

        h.postDelayed(live, 1800);
        h.postDelayed(auto, HOLD_MS);
    }

    void dismiss() {
        if (closing) return;
        closing = true;
        h.removeCallbacks(live);
        h.removeCallbacks(auto);
        animate().alpha(0f).setDuration(450).withEndAction(new Runnable() {
            @Override public void run() {
                if (count != null) count.cancel();
                if (breathe != null) breathe.cancel();
                if (glow != null) glow.cancel();
                if (getParent() instanceof android.view.ViewGroup) ((android.view.ViewGroup) getParent()).removeView(ChargeView.this);
                if (onGone != null) onGone.run();
            }
        }).start();
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getActionMasked() == MotionEvent.ACTION_UP) dismiss();
        return true;
    }
}
