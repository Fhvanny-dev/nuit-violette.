package com.nuitviolette.launcher;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

final class Prefs {
    static final String HIDDEN = "hidden";      // applis masquées
    static final String BLOCK_WIFI = "bw";      // applis bloquées sur Wi-Fi
    static final String BLOCK_MOB = "bm";       // applis bloquées sur données mobiles
    static final String FW_ON = "fw_on";        // pare-feu actif
    static final String POP = "pop";            // pop-ups de notification
    static final String FAV = "fav";            // ligne de favoris (accueil)
    static final String DOCK = "dock";          // dock
    static final String PIN = "pin";

    static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("nv", Context.MODE_PRIVATE);
    }

    static Set<String> getSet(Context c, String k) {
        return new HashSet<String>(sp(c).getStringSet(k, new HashSet<String>()));
    }

    static void putSet(Context c, String k, Set<String> s) {
        sp(c).edit().putStringSet(k, new HashSet<String>(s)).apply();
    }

    /** Ajoute ou retire v ; renvoie le nouvel état (true = présent). */
    static boolean toggle(Context c, String k, String v) {
        Set<String> s = getSet(c, k);
        boolean now;
        if (s.contains(v)) { s.remove(v); now = false; } else { s.add(v); now = true; }
        putSet(c, k, s);
        return now;
    }

    static boolean bool(Context c, String k, boolean def) {
        return sp(c).getBoolean(k, def);
    }

    static List<String> getList(Context c, String k) {
        List<String> out = new ArrayList<String>();
        String s = sp(c).getString(k, "");
        if (s == null || s.isEmpty()) return out;
        for (String p : s.split(",")) if (!p.isEmpty()) out.add(p);
        return out;
    }

    static void putList(Context c, String k, List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String p : l) { if (sb.length() > 0) sb.append(','); sb.append(p); }
        sp(c).edit().putString(k, sb.toString()).apply();
    }
}
