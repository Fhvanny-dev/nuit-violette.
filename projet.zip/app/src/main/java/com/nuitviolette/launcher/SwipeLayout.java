package com.nuitviolette.launcher;

import android.content.Context;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.widget.FrameLayout;

/** FrameLayout qui détecte les glissements verticaux, même au-dessus de boutons. */
class SwipeLayout extends FrameLayout {
    interface L {
        boolean canUp();
        boolean canDown();
        void onUp();
        void onDown();
    }

    private L l;
    private float x0, y0;
    private boolean fired;
    private final int slop;
    private final int trigger;

    SwipeLayout(Context c) {
        super(c);
        slop = ViewConfiguration.get(c).getScaledTouchSlop();
        trigger = Math.round(60 * c.getResources().getDisplayMetrics().density);
    }

    void setListener(L l) { this.l = l; }

    private boolean wants(float dx, float dy) {
        if (l == null) return false;
        if (Math.abs(dy) < slop * 2 || Math.abs(dy) < Math.abs(dx) * 1.5f) return false;
        return dy < 0 ? l.canUp() : l.canDown();
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                x0 = e.getX(); y0 = e.getY(); fired = false;
                break;
            case MotionEvent.ACTION_MOVE:
                if (wants(e.getX() - x0, e.getY() - y0)) return true;
                break;
            default:
                break;
        }
        return false;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                x0 = e.getX(); y0 = e.getY(); fired = false;
                return true;
            case MotionEvent.ACTION_MOVE:
            case MotionEvent.ACTION_UP: {
                float dx = e.getX() - x0, dy = e.getY() - y0;
                if (!fired && Math.abs(dy) > trigger && wants(dx, dy)) {
                    fired = true;
                    if (dy < 0) l.onUp(); else l.onDown();
                }
                return true;
            }
            default:
                return true;
        }
    }
}
