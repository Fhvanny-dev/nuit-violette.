package com.nuitviolette.launcher;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.VpnService;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.os.ParcelFileDescriptor;
import android.system.ErrnoException;
import android.system.Os;
import android.system.OsConstants;
import android.system.StructPollfd;

import java.io.FileDescriptor;
import java.util.Set;

/**
 * Contrôle des données par application.
 * Les applications bloquées sont placées dans un VPN local qui ne transmet rien :
 * elles n'ont donc plus accès au réseau (Wi-Fi et/ou données mobiles selon les règles).
 */
public class FirewallService extends VpnService {
    static final String CH = "nv_fw";

    private ParcelFileDescriptor tun;
    private Drain drain;
    private ConnectivityManager cm;
    private ConnectivityManager.NetworkCallback cb;
    private boolean lastWifi;
    private final Handler h = new Handler(Looper.getMainLooper());

    static void start(Context c) {
        Intent i = new Intent(c, FirewallService.class);
        try {
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i); else c.startService(i);
        } catch (Exception ignored) { }
    }

    static void stop(Context c) {
        Prefs.sp(c).edit().putBoolean(Prefs.FW_ON, false).apply();
        c.stopService(new Intent(c, FirewallService.class));
    }

    /** Lit et jette tous les paquets des applications bloquées. */
    private static final class Drain implements Runnable {
        final ParcelFileDescriptor pfd;
        volatile boolean stop;
        Drain(ParcelFileDescriptor p) { pfd = p; }

        @Override public void run() {
            FileDescriptor fd = pfd.getFileDescriptor();
            byte[] buf = new byte[32767];
            StructPollfd[] pf = new StructPollfd[]{new StructPollfd()};
            pf[0].fd = fd;
            pf[0].events = (short) OsConstants.POLLIN;
            try {
                while (!stop) {
                    pf[0].revents = 0;
                    int n = Os.poll(pf, 500);
                    if (n > 0) {
                        if ((pf[0].revents & (OsConstants.POLLERR | OsConstants.POLLHUP | OsConstants.POLLNVAL)) != 0) break;
                        if ((pf[0].revents & OsConstants.POLLIN) != 0) Os.read(fd, buf, 0, buf.length);
                    }
                }
            } catch (Exception ignored) {
            } finally {
                try { pfd.close(); } catch (Exception ignored) { }
            }
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        goForeground(0, false);
        if (!Prefs.bool(this, Prefs.FW_ON, false)) {
            teardown();
            stopSelf();
            return START_NOT_STICKY;
        }
        if (cm == null) {
            cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            lastWifi = isWifi();
            cb = new ConnectivityManager.NetworkCallback() {
                @Override public void onCapabilitiesChanged(Network n, NetworkCapabilities nc) { recheck(0); }
                @Override public void onLost(Network n) { recheck(900); }
            };
            try { cm.registerDefaultNetworkCallback(cb); } catch (Exception ignored) { }
        }
        apply();
        return START_STICKY;
    }

    private void recheck(long delay) {
        h.postDelayed(new Runnable() {
            @Override public void run() {
                if (cm == null) return;
                if (isWifi() != lastWifi) apply();
            }
        }, delay);
    }

    private boolean isWifi() {
        try {
            Network n = cm.getActiveNetwork();
            if (n == null) return lastWifi;
            NetworkCapabilities nc = cm.getNetworkCapabilities(n);
            if (nc == null) return lastWifi;
            return nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                    || nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET);
        } catch (Exception e) {
            return lastWifi;
        }
    }

    private synchronized void apply() {
        boolean wifi = isWifi();
        lastWifi = wifi;
        Set<String> blocked = Prefs.getSet(this, wifi ? Prefs.BLOCK_WIFI : Prefs.BLOCK_MOB);
        blocked.remove(getPackageName());

        Builder b = new Builder()
                .setSession("Nuit violette")
                .setMtu(1500)
                .addAddress("10.77.0.2", 32)
                .addRoute("0.0.0.0", 0)
                .addAddress("fd77:7700::2", 128)
                .addRoute("::", 0);
        int n = 0;
        PackageManager pm = getPackageManager();
        for (String p : blocked) {
            try {
                pm.getApplicationInfo(p, 0);
                b.addAllowedApplication(p);
                n++;
            } catch (Exception ignored) { }
        }

        Drain old = drain;
        drain = null;
        tun = null;
        if (n > 0) {
            try {
                tun = b.establish();
            } catch (Exception e) {
                tun = null;
            }
        }
        if (old != null) old.stop = true;
        if (tun != null) {
            drain = new Drain(tun);
            new Thread(drain, "nv-drain").start();
        }
        goForeground(n, wifi);
    }

    private void teardown() {
        if (cm != null && cb != null) {
            try { cm.unregisterNetworkCallback(cb); } catch (Exception ignored) { }
        }
        cm = null;
        cb = null;
        if (drain != null) drain.stop = true;
        drain = null;
        tun = null;
    }

    private void goForeground(int n, boolean wifi) {
        NotificationManager nm = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(CH, "Contrôle des données", NotificationManager.IMPORTANCE_MIN));
        }
        PendingIntent pi = PendingIntent.getActivity(this, 0, new Intent(this, DataActivity.class),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        String txt = n == 0
                ? "Aucune appli bloquée sur ce réseau"
                : n + " appli(s) bloquée(s) sur " + (wifi ? "le Wi-Fi" : "les données mobiles");
        Notification nt = new Notification.Builder(this, CH)
                .setSmallIcon(android.R.drawable.ic_lock_lock)
                .setContentTitle("Contrôle des données actif")
                .setContentText(txt)
                .setContentIntent(pi)
                .setOngoing(true)
                .build();
        startForeground(1, nt);
    }

    @Override
    public void onRevoke() {
        Prefs.sp(this).edit().putBoolean(Prefs.FW_ON, false).apply();
        teardown();
        stopSelf();
        super.onRevoke();
    }

    @Override
    public void onDestroy() {
        teardown();
        super.onDestroy();
    }
}
