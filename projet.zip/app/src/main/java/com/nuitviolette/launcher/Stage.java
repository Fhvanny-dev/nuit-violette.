package com.nuitviolette.launcher;

import android.content.Context;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

/** Scène 841x1870 comme dans le HTML : tout est placé en pourcentages de l'image du thème. */
class Stage extends ViewGroup {
    static final class SP extends ViewGroup.LayoutParams {
        float l, t, w, h, sz;
        SP(float l, float t, float w, float h, float sz) {
            super(-2, -2);
            this.l = l; this.t = t; this.w = w; this.h = h; this.sz = sz;
        }
    }

    private float sw, sh;

    Stage(Context c) { super(c); setClipChildren(false); }

    @Override protected boolean checkLayoutParams(ViewGroup.LayoutParams p) { return p instanceof SP; }
    @Override protected ViewGroup.LayoutParams generateDefaultLayoutParams() { return new SP(0, 0, 0, 0, 0); }
    @Override protected ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams p) { return new SP(0, 0, 0, 0, 0); }

    <T extends View> T add(T v, float l, float t, float w, float h) {
        addView(v, new SP(l, t, w, h, 0));
        return v;
    }

    /** texte libre (taille en cqw = % de la largeur de la scène) */
    TextView text(TextView v, float l, float t, float cq) {
        v.setIncludeFontPadding(false);
        addView(v, new SP(l, t, 0, 0, cq));
        return v;
    }

    /** texte centré dans un rectangle */
    TextView box(TextView v, float l, float t, float w, float h, float cq) {
        v.setIncludeFontPadding(false);
        addView(v, new SP(l, t, w, h, cq));
        return v;
    }

    void setCq(TextView v, float cq) {
        SP p = (SP) v.getLayoutParams();
        if (p.sz != cq) { p.sz = cq; requestLayout(); }
    }

    @Override
    protected void onMeasure(int ws, int hs) {
        int vw = MeasureSpec.getSize(ws), vh = MeasureSpec.getSize(hs);
        sw = Math.max(vw, vh * .44973f);
        sh = sw * 1870f / 841f;
        setMeasuredDimension(vw, vh);
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            SP p = (SP) v.getLayoutParams();
            if (v instanceof TextView && p.sz > 0) {
                float px = p.sz * sw / 100f;
                if (((TextView) v).getTextSize() != px) ((TextView) v).setTextSize(TypedValue.COMPLEX_UNIT_PX, px);
            }
            int cw = Math.round(p.w * sw / 100f), ch = Math.round(p.h * sh / 100f);
            if (cw > 0 && ch > 0) v.measure(MeasureSpec.makeMeasureSpec(cw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(ch, MeasureSpec.EXACTLY));
            else v.measure(MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED), MeasureSpec.makeMeasureSpec(0, MeasureSpec.UNSPECIFIED));
        }
    }

    @Override
    protected void onLayout(boolean c, int l, int t, int r, int b) {
        float ox = (getWidth() - sw) / 2f, oy = (getHeight() - sh) / 2f;
        for (int i = 0; i < getChildCount(); i++) {
            View v = getChildAt(i);
            SP p = (SP) v.getLayoutParams();
            int x = Math.round(ox + p.l * sw / 100f), y = Math.round(oy + p.t * sh / 100f);
            v.layout(x, y, x + v.getMeasuredWidth(), y + v.getMeasuredHeight());
        }
    }
}
