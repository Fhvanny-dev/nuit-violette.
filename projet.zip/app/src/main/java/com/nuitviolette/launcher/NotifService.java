package com.nuitviolette.launcher;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Affiche chaque notification en bannière flottante, style iPhone. */
public class NotifService extends NotificationListenerService {
    private final Handler h = new Handler(Looper.getMainLooper());
    private FrameLayout current;
    private Runnable autoHide;
    private boolean bottomMode = true;
    private String lastKey = "";
    private long lastAt = 0;

    // ---------- liste des notifications pour l'accueil (style Samsung) ----------
    static NotifService inst;
    static Runnable onChange;

    static final class Item {
        String key, pkg, app;
        CharSequence title, text;
        long time;
        PendingIntent pi;
        android.graphics.Bitmap icon;
    }

    private void fire() {
        final Runnable r = onChange;
        if (r != null) h.postDelayed(r, 250);
    }

    @Override public void onListenerConnected() { inst = this; fire(); }
    @Override public void onListenerDisconnected() { if (inst == this) inst = null; }

    /** Les n dernières notifications « normales » (ni musique, ni service en cours, ni applis masquées). */
    static java.util.List<Item> snapshot(Context c, int n) {
        java.util.ArrayList<Item> out = new java.util.ArrayList<Item>();
        NotifService s = inst;
        if (s == null) return out;
        try {
            StatusBarNotification[] all = s.getActiveNotifications();
            if (all == null) return out;
            java.util.Arrays.sort(all, new java.util.Comparator<StatusBarNotification>() {
                @Override public int compare(StatusBarNotification a, StatusBarNotification b) { return Long.compare(b.getPostTime(), a.getPostTime()); }
            });
            java.util.Set<String> hidden = Prefs.getSet(c, Prefs.HIDDEN);
            PackageManager pm = c.getPackageManager();
            for (StatusBarNotification sbn : all) {
                if (out.size() >= n) break;
                Notification nt = sbn.getNotification();
                if (nt == null || sbn.getPackageName().equals(c.getPackageName())) continue;
                int bad = Notification.FLAG_ONGOING_EVENT | Notification.FLAG_FOREGROUND_SERVICE | Notification.FLAG_GROUP_SUMMARY;
                if ((nt.flags & bad) != 0 || hidden.contains(sbn.getPackageName())) continue;
                Bundle ex = nt.extras;
                if (ex == null || ex.getParcelable(Notification.EXTRA_MEDIA_SESSION) != null) continue;
                CharSequence title = ex.getCharSequence(Notification.EXTRA_TITLE);
                CharSequence text = ex.getCharSequence(Notification.EXTRA_BIG_TEXT);
                if (TextUtils.isEmpty(text)) text = ex.getCharSequence(Notification.EXTRA_TEXT);
                if (TextUtils.isEmpty(title) && TextUtils.isEmpty(text)) continue;
                Item it = new Item();
                it.key = sbn.getKey(); it.pkg = sbn.getPackageName(); it.title = title; it.text = text;
                it.time = sbn.getPostTime(); it.pi = nt.contentIntent;
                try {
                    it.app = pm.getApplicationLabel(pm.getApplicationInfo(it.pkg, 0)).toString();
                    it.icon = Apps.icon(c, it.pkg, it.app, pm.getApplicationIcon(it.pkg));
                } catch (Exception e) { it.app = it.pkg; }
                out.add(it);
            }
        } catch (Throwable ignored) { }
        return out;
    }

    static void dismiss(String key) {
        try { if (inst != null) inst.cancelNotification(key); } catch (Throwable ignored) { }
    }

    @Override
    public void onNotificationPosted(final StatusBarNotification sbn) {
        fire();
        try {
            if (!Prefs.bool(this, Prefs.POP, true)) return;
            if (!Settings.canDrawOverlays(this)) return;
            Notification n = sbn.getNotification();
            if (n == null) return;
            Bundle ex = n.extras;
            Object tok = ex == null ? null : ex.getParcelable(Notification.EXTRA_MEDIA_SESSION);
            if (tok instanceof android.media.session.MediaSession.Token) {
                if (Prefs.bool(this, Prefs.POP, true) && Settings.canDrawOverlays(this)) {
                    final android.media.session.MediaSession.Token ft0 = (android.media.session.MediaSession.Token) tok;
                    h.post(new Runnable() { @Override public void run() { showMusic(sbn, ft0); } });
                }
                return;
            }
            boolean test = ex != null && ex.getBoolean("nv_test", false);
            if (sbn.getPackageName().equals(getPackageName()) && !test) return;
            int bad = Notification.FLAG_ONGOING_EVENT | Notification.FLAG_FOREGROUND_SERVICE
                    | Notification.FLAG_GROUP_SUMMARY;
            if (!test && (n.flags & bad) != 0) return;
            if (Prefs.getSet(this, Prefs.HIDDEN).contains(sbn.getPackageName())) return;

            try {
                Ranking r = new Ranking();
                if (getCurrentRanking().getRanking(sbn.getKey(), r)
                        && r.getImportance() < NotificationManager.IMPORTANCE_DEFAULT) return;
            } catch (Exception ignored) { }

            CharSequence title = ex == null ? null : ex.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence text = ex == null ? null : ex.getCharSequence(Notification.EXTRA_BIG_TEXT);
            if (TextUtils.isEmpty(text) && ex != null) text = ex.getCharSequence(Notification.EXTRA_TEXT);
            if (TextUtils.isEmpty(title) && TextUtils.isEmpty(text)) return;

            String sig = sbn.getKey() + "|" + title + "|" + text;
            long now = System.currentTimeMillis();
            if (sig.equals(lastKey) && now - lastAt < 3000) return;
            lastKey = sig;
            lastAt = now;

            final CharSequence ft = title, fx = text;
            h.post(new Runnable() {
                @Override public void run() { show(sbn, ft, fx); }
            });
        } catch (Throwable ignored) { }
    }

    private int dp(float v) { return Ui.dp(this, v); }

    private void removeNow() {
        if (autoHide != null) { h.removeCallbacks(autoHide); autoHide = null; }
        if (current != null) {
            try {
                ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).removeView(current);
            } catch (Exception ignored) { }
            current = null;
        }
    }

    private void hideAnimated() {
        final FrameLayout c = current;
        if (c == null) return;
        if (autoHide != null) { h.removeCallbacks(autoHide); autoHide = null; }
        c.animate().translationY((bottomMode ? 1 : -1) * dp(150)).alpha(0f).setDuration(260)
                .withEndAction(new Runnable() {
                    @Override public void run() { if (current == c) removeNow(); }
                }).start();
    }

    private void show(StatusBarNotification sbn, CharSequence title, CharSequence text) {
        removeNow();
        final boolean bottom = Prefs.bool(this, Prefs.NOTIF_BOTTOM, false);
        bottomMode = bottom;
        final float dir = bottom ? 1f : -1f;      // sens pour faire disparaître la bannière (bas ou haut)
        final WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        final PackageManager pm = getPackageManager();
        String pkg = sbn.getPackageName();
        String app;
        Drawable ic;
        try {
            app = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
            ic = pm.getApplicationIcon(pkg);
        } catch (Exception e) {
            app = pkg;
            ic = pm.getDefaultActivityIcon();
        }

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(18), dp(14), dp(22), dp(14));
        card.setBackground(glassPill());
        card.setElevation(dp(10));

        ImageView iv = new ImageView(this);
        iv.setImageBitmap(Apps.icon(this, pkg, app, ic));
        card.addView(iv, new LinearLayout.LayoutParams(dp(60), dp(60)));

        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tlp.setMargins(dp(12), 0, 0, 0);
        card.addView(tx, tlp);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView an = Ui.text(this, app.toUpperCase() + " \u2661", 15.5f, 0xFFFFFFFF, true);
        an.setSingleLine(true);
        an.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(an, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(Ui.text(this, "maintenant", 13, 0xFFB79BE8, false));
        tx.addView(top);

        if (!TextUtils.isEmpty(title)) {
            TextView t = Ui.text(this, title, 14.5f, 0xFFF3E6FF, true);
            t.setSingleLine(true);
            t.setEllipsize(TextUtils.TruncateAt.END);
            tx.addView(t);
        }
        if (!TextUtils.isEmpty(text)) {
            TextView b = Ui.text(this, text, 15, 0xFFC9B2F2, false);
            b.setMaxLines(2);
            b.setEllipsize(TextUtils.TruncateAt.END);
            tx.addView(b);
        }

        final FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(10), 0, dp(10), 0);
        box.addView(card, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));

        final PendingIntent pi = sbn.getNotification().contentIntent;
        card.setOnTouchListener(new View.OnTouchListener() {
            float y0;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        y0 = e.getRawY();
                        if (autoHide != null) h.removeCallbacks(autoHide);
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dy = e.getRawY() - y0;
                        if (dy * dir > 0) box.setTranslationY(dy);
                        return true;
                    }
                    case MotionEvent.ACTION_UP: {
                        float dy = e.getRawY() - y0;
                        if (dy * dir > dp(28)) { hideAnimated(); }
                        else if (Math.abs(dy) < dp(10)) {
                            if (pi != null) { try { pi.send(); } catch (Exception ignored) { } }
                            hideAnimated();
                        } else {
                            box.animate().translationY(0).setDuration(150).start();
                            schedule(2500);
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_CANCEL:
                        box.animate().translationY(0).setDuration(150).start();
                        schedule(2500);
                        return true;
                    default:
                        return true;
                }
            }
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = (bottom ? Gravity.BOTTOM : Gravity.TOP) | Gravity.CENTER_HORIZONTAL;
        // en haut : sous la carte musique si elle est affichée
        lp.y = bottom ? dp(44) : dp(10) + (music != null ? music.getHeight() + dp(8) : 0);
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                lp.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
                lp.setBlurBehindRadius(dp(24));
            } catch (Throwable ignored) { }
        }

        box.setAlpha(0f);
        box.setTranslationY(dir * dp(140));
        try {
            wm.addView(box, lp);
        } catch (Exception e) {
            return;
        }
        current = box;
        box.animate().translationY(0).alpha(1f).setDuration(480)
                .setInterpolator(new OvershootInterpolator(0.9f)).start();
        schedule(4800);
    }

    // ---------- décor verre violet commun (bordure lumineuse, fond translucide) ----------
    private android.graphics.drawable.Drawable glassPill() {
        GradientDrawable fill = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                new int[]{0xE6341478, 0xE61C0746, 0xE62E0E66});
        fill.setCornerRadius(dp(40));
        fill.setStroke(dp(2), 0xEEDCC8FF);
        GradientDrawable glow = new GradientDrawable();
        glow.setCornerRadius(dp(42));
        glow.setStroke(dp(5), 0x449B5CFF);
        android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(
                new android.graphics.drawable.Drawable[]{glow, fill});
        ld.setLayerInset(1, dp(3), dp(3), dp(3), dp(3));
        return ld;
    }

    // ---------- carte musique (style image 2, transparente), déplaçable ----------
    private FrameLayout music;
    private String musicKey;
    private android.media.session.MediaController mc;
    private android.media.session.MediaController.Callback mcb;
    private Runnable seekTick;

    // ---- après fermeture de la carte, on surveille la session : la carte revient dès que la lecture reprend ----
    private android.media.session.MediaController wmc;
    private android.media.session.MediaController.Callback wcb;
    private StatusBarNotification wSbn;
    private android.media.session.MediaSession.Token wTok;
    private String wKey;
    private boolean wPlaying;
    private CharSequence wTitle;

    private void stopWatch() {
        try { if (wmc != null && wcb != null) wmc.unregisterCallback(wcb); } catch (Exception ignored) { }
        wmc = null; wcb = null; wSbn = null; wTok = null; wKey = null;
    }

    private void startWatch(StatusBarNotification sbn, android.media.session.MediaSession.Token tok) {
        stopWatch();
        if (sbn == null || tok == null) return;
        try {
            wSbn = sbn; wTok = tok; wKey = sbn.getKey();
            wmc = new android.media.session.MediaController(this, tok);
            android.media.session.PlaybackState ps0 = wmc.getPlaybackState();
            wPlaying = ps0 != null && ps0.getState() == android.media.session.PlaybackState.STATE_PLAYING;
            android.media.MediaMetadata m0 = wmc.getMetadata();
            wTitle = m0 == null ? null : m0.getText(android.media.MediaMetadata.METADATA_KEY_TITLE);
            wcb = new android.media.session.MediaController.Callback() {
                private void again() {
                    if (wSbn == null || wTok == null || music != null) return;
                    if (!Prefs.bool(NotifService.this, Prefs.POP, true) || !Settings.canDrawOverlays(NotifService.this)) return;
                    final StatusBarNotification sb = wSbn;
                    final android.media.session.MediaSession.Token tk = wTok;
                    stopWatch();
                    h.post(new Runnable() { @Override public void run() { showMusic(sb, tk); } });
                }
                @Override public void onPlaybackStateChanged(android.media.session.PlaybackState s) {
                    boolean pl = s != null && s.getState() == android.media.session.PlaybackState.STATE_PLAYING;
                    boolean was = wPlaying;
                    wPlaying = pl;
                    if (pl && !was) again();            // pause -> lecture : la carte revient
                }
                @Override public void onMetadataChanged(android.media.MediaMetadata m) {
                    CharSequence t = m == null ? null : m.getText(android.media.MediaMetadata.METADATA_KEY_TITLE);
                    if (t != null && !t.equals(wTitle)) { wTitle = t; if (wPlaying) again(); }   // nouveau morceau
                }
                @Override public void onSessionDestroyed() { stopWatch(); }
            };
            wmc.registerCallback(wcb, h);
        } catch (Throwable t) { stopWatch(); }
    }

    /** Fermeture par l'utilisateur (croix ou glissé) : on retire la carte mais on garde la surveillance. */
    private void closeMusic() {
        android.media.session.MediaSession.Token tk = null;
        StatusBarNotification sb = musicSbn;
        try { if (mc != null) tk = mc.getSessionToken(); } catch (Exception ignored) { }
        removeMusic();
        startWatch(sb, tk);
    }

    private StatusBarNotification musicSbn;

    private void removeMusic() {
        try { if (mc != null && mcb != null) mc.unregisterCallback(mcb); } catch (Exception ignored) { }
        if (seekTick != null) { h.removeCallbacks(seekTick); seekTick = null; }
        mc = null; mcb = null;
        if (music != null) {
            try { ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).removeView(music); } catch (Exception ignored) { }
            music = null;
        }
        musicKey = null;
    }

    private static String mmss(long ms) {
        long s = Math.max(0, ms / 1000);
        return String.format(java.util.Locale.US, "%02d:%02d", s / 60, s % 60);
    }

    private void showMusic(StatusBarNotification sbn, android.media.session.MediaSession.Token tok) {
        removeMusic();
        stopWatch();
        musicSbn = sbn;
        musicKey = sbn.getKey();
        final WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        mc = new android.media.session.MediaController(this, tok);

        final LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(10), dp(14), dp(8));
        card.setBackground(new GlassDrawable(this, 26));
        card.setElevation(dp(8));

        // ligne du haut : pochette | (titre + diffusion / état / boutons)
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        card.addView(row, new LinearLayout.LayoutParams(-1, -2));

        // pochette : l'icône galaxie de la maquette (la vraie pochette seulement si le morceau en fournit une)
        final ImageView art = new ImageView(this);
        art.setScaleType(ImageView.ScaleType.CENTER_CROP);
        art.setImageResource(R.drawable.music_galaxy);
        art.setOutlineProvider(new android.view.ViewOutlineProvider() {
            @Override public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(13)); }
        });
        art.setClipToOutline(true);
        row.addView(art, new LinearLayout.LayoutParams(dp(54), dp(54)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        cl.setMargins(dp(10), 0, 0, 0);
        row.addView(col, cl);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        final TextView title = Ui.text(this, "", 14, 0xFFFFFFFF, true);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        head.addView(title, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        head.addView(new Glyph(this, Glyph.CAST), new LinearLayout.LayoutParams(dp(20), dp(20)));
        col.addView(head);
        final TextView state = Ui.text(this, "Lecture en cours...", 11.5f, 0xFFA58BF0, false);
        state.setSingleLine(true);
        col.addView(state);

        LinearLayout btns = new LinearLayout(this);
        btns.setOrientation(LinearLayout.HORIZONTAL);
        btns.setGravity(Gravity.CENTER_VERTICAL);
        final Glyph prev = new Glyph(this, Glyph.PREV);
        final Glyph play = new Glyph(this, Glyph.PAUSE);
        final Glyph next = new Glyph(this, Glyph.NEXT);
        final Glyph close = new Glyph(this, Glyph.CLOSE);
        View sep = new View(this);
        sep.setBackgroundColor(0x55E2C4FF);
        btns.addView(prev, new LinearLayout.LayoutParams(0, dp(30), 1f));
        btns.addView(play, new LinearLayout.LayoutParams(0, dp(30), 1f));
        btns.addView(next, new LinearLayout.LayoutParams(0, dp(30), 1f));
        LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(dp(1), dp(24));
        sp2.setMargins(dp(2), 0, dp(2), 0);
        btns.addView(sep, sp2);
        btns.addView(close, new LinearLayout.LayoutParams(0, dp(30), 0.7f));
        col.addView(btns);

        // ligne du bas : temps écoulé, barre de lecture, durée
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        final TextView tNow = Ui.text(this, "00:00", 11, 0xFFA58BF0, false);
        final TextView tEnd = Ui.text(this, "00:00", 11, 0xFFA58BF0, false);
        final MusicBar sk = new MusicBar(this);
        bar.addView(tNow);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(0, dp(20), 1f);
        sl.setMargins(dp(4), 0, dp(4), 0);
        bar.addView(sk, sl);
        bar.addView(tEnd);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, -2);
        bl.topMargin = dp(2);
        card.addView(bar, bl);

        prev.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { try { mc.getTransportControls().skipToPrevious(); } catch (Exception ignored) { } } });
        next.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { try { mc.getTransportControls().skipToNext(); } catch (Exception ignored) { } } });
        play.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            try {
                android.media.session.PlaybackState ps = mc.getPlaybackState();
                if (ps != null && ps.getState() == android.media.session.PlaybackState.STATE_PLAYING) mc.getTransportControls().pause();
                else mc.getTransportControls().play();
            } catch (Exception ignored) { }
        } });
        close.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) { closeMusic(); } });
        final long[] dur = {0};
        sk.setOnSeek(new MusicBar.OnSeek() {
            @Override public void to(float f) {
                try { if (dur[0] > 0) mc.getTransportControls().seekTo((long) (dur[0] * f)); } catch (Exception ignored) { }
            }
        });

        final Notification nn = sbn.getNotification();
        final Runnable upd = new Runnable() { @Override public void run() {
            try {
                android.media.MediaMetadata md = mc.getMetadata();
                if (md != null) {
                    CharSequence t = md.getText(android.media.MediaMetadata.METADATA_KEY_TITLE);
                    title.setText(t == null ? "Musique" : t);
                    dur[0] = md.getLong(android.media.MediaMetadata.METADATA_KEY_DURATION);
                    tEnd.setText(mmss(dur[0]));
                    android.graphics.Bitmap bm = md.getBitmap(android.media.MediaMetadata.METADATA_KEY_ALBUM_ART);
                    if (bm == null) bm = md.getBitmap(android.media.MediaMetadata.METADATA_KEY_ART);
                    if (bm != null) art.setImageBitmap(bm); else art.setImageResource(R.drawable.music_galaxy);
                }
                android.media.session.PlaybackState ps = mc.getPlaybackState();
                boolean pl = ps != null && ps.getState() == android.media.session.PlaybackState.STATE_PLAYING;
                play.setKind(pl ? Glyph.PAUSE : Glyph.PLAY);
                state.setText(pl ? "Lecture en cours..." : "En pause");
            } catch (Exception ignored) { }
        } };
        mcb = new android.media.session.MediaController.Callback() {
            @Override public void onMetadataChanged(android.media.MediaMetadata m) { upd.run(); }
            @Override public void onPlaybackStateChanged(android.media.session.PlaybackState s) { upd.run(); }
        };
        mc.registerCallback(mcb, h);
        upd.run();

        seekTick = new Runnable() { @Override public void run() {
            try {
                android.media.session.PlaybackState ps = mc == null ? null : mc.getPlaybackState();
                if (ps != null && !sk.isDragging()) {
                    long pos = ps.getPosition();
                    if (ps.getState() == android.media.session.PlaybackState.STATE_PLAYING) {
                        pos += (long) ((android.os.SystemClock.elapsedRealtime() - ps.getLastPositionUpdateTime()) * ps.getPlaybackSpeed());
                    }
                    if (dur[0] > 0) { pos = Math.min(pos, dur[0]); sk.setFrac(pos / (float) dur[0]); }
                    tNow.setText(mmss(pos));
                }
            } catch (Exception ignored) { }
            if (seekTick != null) h.postDelayed(seekTick, 500);
        } };
        h.post(seekTick);

        // notification pop-up en haut (comme sur iPhone), taille normale d'une notification
        int sw = getResources().getDisplayMetrics().widthPixels;
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                Math.min(sw - dp(20), dp(400)),
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = dp(10);
        final FrameLayout box = new FrameLayout(this);
        box.addView(card, new FrameLayout.LayoutParams(-1, -2));
        final PendingIntent open = nn.contentIntent;
        // glisser vers le haut = fermer ; toucher le fond de la carte = ouvrir le lecteur
        card.setOnTouchListener(new View.OnTouchListener() {
            float y0;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: y0 = e.getRawY(); return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dy = e.getRawY() - y0;
                        if (dy < 0) box.setTranslationY(dy);
                        return true;
                    }
                    case MotionEvent.ACTION_UP: {
                        float dy = e.getRawY() - y0;
                        if (dy < -dp(36)) { closeMusic(); }
                        else {
                            box.animate().translationY(0).setDuration(150).start();
                            if (Math.abs(dy) < dp(8) && open != null) { try { open.send(); } catch (Exception ignored) { } }
                        }
                        return true;
                    }
                    default:
                        box.animate().translationY(0).setDuration(150).start();
                        return true;
                }
            }
        });
        try { wm.addView(box, lp); } catch (Exception e) { return; }
        music = box;
        box.setAlpha(0f);
        box.setTranslationY(-dp(120));
        box.animate().alpha(1f).translationY(0).setDuration(420).setInterpolator(new OvershootInterpolator(0.9f)).start();
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        fire();
        if (musicKey != null && musicKey.equals(sbn.getKey())) removeMusic();
        if (wKey != null && wKey.equals(sbn.getKey())) stopWatch();
    }

    private void schedule(long ms) {
        if (autoHide != null) h.removeCallbacks(autoHide);
        autoHide = new Runnable() {
            @Override public void run() { hideAnimated(); }
        };
        h.postDelayed(autoHide, ms);
    }

    @Override
    public void onDestroy() {
        removeNow();
        removeMusic();
        stopWatch();
        super.onDestroy();
    }
}
