package com.nuitviolette.launcher;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Affiche chaque notification en bannière flottante, style iPhone. */
public class NotifService extends NotificationListenerService {
    private final Handler h = new Handler(Looper.getMainLooper());
    private FrameLayout current;
    private Runnable autoHide;
    private String lastKey = "";
    private long lastAt = 0;

    @Override
    public void onNotificationPosted(final StatusBarNotification sbn) {
        try {
            if (!Prefs.bool(this, Prefs.POP, true)) return;
            if (!Settings.canDrawOverlays(this)) return;
            Notification n = sbn.getNotification();
            if (n == null) return;
            Bundle ex = n.extras;
            boolean test = ex != null && ex.getBoolean("nv_test", false);
            if (sbn.getPackageName().equals(getPackageName()) && !test) return;
            int bad = Notification.FLAG_ONGOING_EVENT | Notification.FLAG_FOREGROUND_SERVICE
                    | Notification.FLAG_GROUP_SUMMARY;
            if (!test && (n.flags & bad) != 0) return;
            if (Prefs.getSet(this, Prefs.HIDDEN).contains(sbn.getPackageName())) return;

            try {
                Ranking r = new Ranking();
                if (getCurrentRanking().getRanking(sbn.getKey(), r)
                        && r.getImportance() < NotificationManager.IMPORTANCE_DEFAULT) return;
            } catch (Exception ignored) { }

            CharSequence title = ex == null ? null : ex.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence text = ex == null ? null : ex.getCharSequence(Notification.EXTRA_BIG_TEXT);
            if (TextUtils.isEmpty(text) && ex != null) text = ex.getCharSequence(Notification.EXTRA_TEXT);
            if (TextUtils.isEmpty(title) && TextUtils.isEmpty(text)) return;

            String sig = sbn.getKey() + "|" + title + "|" + text;
            long now = System.currentTimeMillis();
            if (sig.equals(lastKey) && now - lastAt < 3000) return;
            lastKey = sig;
            lastAt = now;

            final CharSequence ft = title, fx = text;
            h.post(new Runnable() {
                @Override public void run() { show(sbn, ft, fx); }
            });
        } catch (Throwable ignored) { }
    }

    private int dp(float v) { return Ui.dp(this, v); }

    private void removeNow() {
        if (autoHide != null) { h.removeCallbacks(autoHide); autoHide = null; }
        if (current != null) {
            try {
                ((WindowManager) getSystemService(Context.WINDOW_SERVICE)).removeView(current);
            } catch (Exception ignored) { }
            current = null;
        }
    }

    private void hideAnimated() {
        final FrameLayout c = current;
        if (c == null) return;
        if (autoHide != null) { h.removeCallbacks(autoHide); autoHide = null; }
        c.animate().translationY(-dp(150)).alpha(0f).setDuration(260)
                .withEndAction(new Runnable() {
                    @Override public void run() { if (current == c) removeNow(); }
                }).start();
    }

    private void show(StatusBarNotification sbn, CharSequence title, CharSequence text) {
        removeNow();
        final WindowManager wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        final PackageManager pm = getPackageManager();
        String pkg = sbn.getPackageName();
        String app;
        Drawable ic;
        try {
            app = pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString();
            ic = pm.getApplicationIcon(pkg);
        } catch (Exception e) {
            app = pkg;
            ic = pm.getDefaultActivityIcon();
        }

        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.HORIZONTAL);
        card.setGravity(Gravity.CENTER_VERTICAL);
        card.setPadding(dp(14), dp(12), dp(16), dp(12));
        card.setBackground(Ui.grad(this, 28, 0xEE2E1466, 0xEE16062F, 0x77E9D5FF));
        card.setElevation(dp(10));

        ImageView iv = new ImageView(this);
        iv.setImageBitmap(Apps.bubble(this, ic));
        card.addView(iv, new LinearLayout.LayoutParams(dp(44), dp(44)));

        LinearLayout tx = new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams tlp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        tlp.setMargins(dp(12), 0, 0, 0);
        card.addView(tx, tlp);

        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        TextView an = Ui.text(this, app.toUpperCase(), 11.5f, Ui.SOFT, true);
        an.setSingleLine(true);
        an.setEllipsize(TextUtils.TruncateAt.END);
        top.addView(an, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        top.addView(Ui.text(this, "maintenant", 11.5f, 0xFFB79BE8, false));
        tx.addView(top);

        if (!TextUtils.isEmpty(title)) {
            TextView t = Ui.text(this, title, 15, 0xFFFFFFFF, true);
            t.setSingleLine(true);
            t.setEllipsize(TextUtils.TruncateAt.END);
            tx.addView(t);
        }
        if (!TextUtils.isEmpty(text)) {
            TextView b = Ui.text(this, text, 14, 0xFFEADCFF, false);
            b.setMaxLines(2);
            b.setEllipsize(TextUtils.TruncateAt.END);
            tx.addView(b);
        }

        final FrameLayout box = new FrameLayout(this);
        box.setPadding(dp(10), 0, dp(10), 0);
        box.addView(card, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.WRAP_CONTENT));

        final PendingIntent pi = sbn.getNotification().contentIntent;
        card.setOnTouchListener(new View.OnTouchListener() {
            float y0;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        y0 = e.getRawY();
                        if (autoHide != null) h.removeCallbacks(autoHide);
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float dy = e.getRawY() - y0;
                        if (dy < 0) box.setTranslationY(dy);
                        return true;
                    }
                    case MotionEvent.ACTION_UP: {
                        float dy = e.getRawY() - y0;
                        if (dy < -dp(28)) { hideAnimated(); }
                        else if (Math.abs(dy) < dp(10)) {
                            if (pi != null) { try { pi.send(); } catch (Exception ignored) { } }
                            hideAnimated();
                        } else {
                            box.animate().translationY(0).setDuration(150).start();
                            schedule(2500);
                        }
                        return true;
                    }
                    case MotionEvent.ACTION_CANCEL:
                        box.animate().translationY(0).setDuration(150).start();
                        schedule(2500);
                        return true;
                    default:
                        return true;
                }
            }
        });

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.y = dp(10);
        if (Build.VERSION.SDK_INT >= 31) {
            try {
                lp.flags |= WindowManager.LayoutParams.FLAG_BLUR_BEHIND;
                lp.setBlurBehindRadius(dp(24));
            } catch (Throwable ignored) { }
        }

        box.setAlpha(0f);
        box.setTranslationY(-dp(140));
        try {
            wm.addView(box, lp);
        } catch (Exception e) {
            return;
        }
        current = box;
        box.animate().translationY(0).alpha(1f).setDuration(480)
                .setInterpolator(new OvershootInterpolator(0.9f)).start();
        schedule(4800);
    }

    private void schedule(long ms) {
        if (autoHide != null) h.removeCallbacks(autoHide);
        autoHide = new Runnable() {
            @Override public void run() { hideAnimated(); }
        };
        h.postDelayed(autoHide, ms);
    }

    @Override
    public void onDestroy() {
        removeNow();
        super.onDestroy();
    }
}
