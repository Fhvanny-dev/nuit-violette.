package com.nuitviolette.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Météo de la barre d'accueil. Sans permission de position : on déduit la ville de l'adresse IP
 * (ipwho.is), puis on lit la température sur open-meteo.com (gratuit, sans clé). Résultat gardé 20 min.
 */
final class Weather {
    interface Cb { void on(String temp, int code, boolean night); }

    private static boolean busy;

    static void refresh(final Context ctx, final Cb cb) {
        final Context app = ctx.getApplicationContext();
        final SharedPreferences sp = Prefs.sp(app);
        final Handler ui = new Handler(Looper.getMainLooper());
        // valeur en cache d'abord
        if (sp.contains("w_t")) {
            final String t = sp.getString("w_t", "--°");
            final int c = sp.getInt("w_c", -1);
            final boolean n = sp.getBoolean("w_n", true);
            ui.post(new Runnable() { @Override public void run() { cb.on(t, c, n); } });
        }
        if (busy || System.currentTimeMillis() - sp.getLong("w_at", 0) < 20 * 60 * 1000L) return;
        busy = true;
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    double lat = Double.longBitsToDouble(sp.getLong("w_lat", Double.doubleToLongBits(Double.NaN)));
                    double lon = Double.longBitsToDouble(sp.getLong("w_lon", Double.doubleToLongBits(Double.NaN)));
                    if (Double.isNaN(lat) || Double.isNaN(lon)) {
                        JSONObject g = new JSONObject(get("https://ipwho.is/"));
                        lat = g.getDouble("latitude");
                        lon = g.getDouble("longitude");
                        sp.edit().putLong("w_lat", Double.doubleToLongBits(lat))
                                .putLong("w_lon", Double.doubleToLongBits(lon)).apply();
                    }
                    JSONObject j = new JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=" + lat
                            + "&longitude=" + lon + "&current=temperature_2m,weather_code,is_day"));
                    JSONObject cur = j.getJSONObject("current");
                    final String t = Math.round(cur.getDouble("temperature_2m")) + "°";
                    final int code = cur.getInt("weather_code");
                    final boolean night = cur.getInt("is_day") == 0;
                    sp.edit().putString("w_t", t).putInt("w_c", code).putBoolean("w_n", night)
                            .putLong("w_at", System.currentTimeMillis()).apply();
                    ui.post(new Runnable() { @Override public void run() { cb.on(t, code, night); } });
                } catch (Throwable ignored) {
                } finally {
                    busy = false;
                }
            }
        }).start();
    }

    private static String get(String u) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String l;
        while ((l = r.readLine()) != null) sb.append(l);
        r.close();
        return sb.toString();
    }
}
