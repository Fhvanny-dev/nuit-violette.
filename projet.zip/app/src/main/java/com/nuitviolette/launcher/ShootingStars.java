package com.nuitviolette.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

import java.util.Random;

/**
 * Ciel de l'accueil : vraies petites étoiles scintillantes (éclats à 4 branches blanc-lilas)
 * et étoiles filantes à longue traîne violette qui passent de temps en temps.
 */
final class ShootingStars extends View {
    private static final class Star { float x, y, r, ph, sp; boolean sparkle; }

    private final Random rnd = new Random(11);
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private Star[] stars = new Star[0];
    private Bitmap halo;

    private boolean active;
    private float sx, sy, dirX, dirY, travel, tailMax;
    private long t0, dur;
    private long nextAt;

    ShootingStars(Context c) {
        super(c);
        setClickable(false);
        setFocusable(false);
        int H = 64;
        halo = Bitmap.createBitmap(H, H, Bitmap.Config.ARGB_8888);
        Paint hp = new Paint(Paint.ANTI_ALIAS_FLAG);
        hp.setShader(new RadialGradient(H / 2f, H / 2f, H / 2f,
                new int[]{0xFFFFFFFF, 0x66D2A8FF, 0x00B47CFF}, new float[]{0f, 0.25f, 1f}, Shader.TileMode.CLAMP));
        new Canvas(halo).drawCircle(H / 2f, H / 2f, H / 2f, hp);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        float d = getResources().getDisplayMetrics().density;
        stars = new Star[20];
        for (int i = 0; i < stars.length; i++) {
            Star s = new Star();
            s.x = rnd.nextFloat() * w;
            s.y = rnd.nextFloat() * h * 0.55f;      // dans le ciel, au-dessus des montagnes
            s.sparkle = i % 3 == 0;
            s.r = (s.sparkle ? 3.2f + rnd.nextFloat() * 2.4f : 1f + rnd.nextFloat() * 1.3f) * d;
            s.ph = rnd.nextFloat() * 6.28f;
            s.sp = 0.0010f + rnd.nextFloat() * 0.0018f;
            stars[i] = s;
        }
        nextAt = System.currentTimeMillis() + 1500;
    }

    private void spawn(int w, int h) {
        float d = getResources().getDisplayMetrics().density;
        double ang = Math.toRadians(24 + rnd.nextFloat() * 14);
        dirX = (float) -Math.cos(ang);
        dirY = (float) Math.sin(ang);
        sx = w * (0.5f + rnd.nextFloat() * 0.6f);
        sy = h * (0.02f + rnd.nextFloat() * 0.22f);
        travel = w * (0.65f + rnd.nextFloat() * 0.3f);
        tailMax = w * (0.20f + rnd.nextFloat() * 0.10f);
        dur = 900 + (long) (rnd.nextFloat() * 500);
        t0 = System.currentTimeMillis();
        active = true;
    }

    private void drawSparkle(Canvas c, float x, float y, float r, int a) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor((a << 24) | 0xFFF2FF);
        path.reset();
        path.moveTo(x, y - r);
        path.quadTo(x, y, x + r * 0.28f, y);
        path.quadTo(x, y, x, y + r);
        path.quadTo(x, y, x - r * 0.28f, y);
        path.quadTo(x, y, x, y - r);
        c.drawPath(path, p);
        path.reset();
        path.moveTo(x - r * 0.7f, y);
        path.quadTo(x, y, x, y - r * 0.2f);
        path.quadTo(x, y, x + r * 0.7f, y);
        path.quadTo(x, y, x, y + r * 0.2f);
        path.quadTo(x, y, x - r * 0.7f, y);
        c.drawPath(path, p);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        long now = System.currentTimeMillis();
        float d = getResources().getDisplayMetrics().density;

        for (Star s : stars) {
            float tw = 0.5f + 0.5f * (float) Math.sin(now * s.sp + s.ph);
            float al = 0.25f + 0.75f * tw;
            p.setShader(null);
            p.setAlpha(Math.round(120 * al));
            float hr = s.r * 4f;
            c.drawBitmap(halo, null, new android.graphics.RectF(s.x - hr, s.y - hr, s.x + hr, s.y + hr), p);
            if (s.sparkle) {
                drawSparkle(c, s.x, s.y, s.r * (1.2f + 0.5f * tw), Math.round(255 * al));
            } else {
                p.setStyle(Paint.Style.FILL);
                p.setColor(((Math.round(255 * al)) << 24) | 0xF4EAFF);
                c.drawCircle(s.x, s.y, s.r * 0.55f, p);
            }
        }

        if (!active && now >= nextAt) spawn(w, h);
        if (active) {
            float t = (now - t0) / (float) dur;
            if (t >= 1f) {
                active = false;
                nextAt = now + 3500 + (long) (rnd.nextFloat() * 5500);
            } else {
                float env = (float) Math.sin(Math.PI * t);
                float hx = sx + dirX * travel * t, hy = sy + dirY * travel * t;
                float tail = tailMax * Math.min(1f, t / 0.2f) * (t > 0.8f ? (1f - t) / 0.2f : 1f);
                float ex = hx - dirX * tail, ey = hy - dirY * tail;
                float nx = -dirY, ny = dirX;
                // traîne lumineuse large puis cœur fin
                for (int k = 0; k < 2; k++) {
                    float wd = (k == 0 ? 4.5f : 1.7f) * d;
                    path.reset();
                    path.moveTo(hx + nx * wd, hy + ny * wd);
                    path.lineTo(ex, ey);
                    path.lineTo(hx - nx * wd, hy - ny * wd);
                    path.close();
                    int head = k == 0 ? (Math.round(120 * env) << 24) | 0xB47CFF : (Math.round(255 * env) << 24) | 0xFFFFFF;
                    int end = k == 0 ? 0x009B5CFF : 0x00C9A8FF;
                    p.setStyle(Paint.Style.FILL);
                    p.setShader(new LinearGradient(hx, hy, ex, ey, head, end, Shader.TileMode.CLAMP));
                    c.drawPath(path, p);
                }
                p.setShader(null);
                p.setAlpha(Math.round(255 * env));
                float hr = 11f * d;
                c.drawBitmap(halo, null, new android.graphics.RectF(hx - hr, hy - hr, hx + hr, hy + hr), p);
                drawSparkle(c, hx, hy, 6f * d, Math.round(255 * env));
            }
        }
        if (isShown()) postInvalidateOnAnimation();
    }

    @Override
    protected void onWindowVisibilityChanged(int v) {
        super.onWindowVisibilityChanged(v);
        if (v == View.VISIBLE) postInvalidateOnAnimation();
    }
}
