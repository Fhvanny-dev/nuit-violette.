package com.nuitviolette.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

import java.util.Random;

/**
 * Ciel de l'accueil : vraies petites étoiles scintillantes (éclats à 4 branches blanc-lilas)
 * et étoiles filantes à longue traîne violette qui passent de temps en temps.
 */
final class ShootingStars extends View {
    private static final class Star { float x, y, r, ph, sp; boolean sparkle; }

    private final Random rnd = new Random(11);
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private Star[] stars = new Star[0];
    private Bitmap halo;

    /** Un météore. kind : 0 = côté, 1 = lointain (derrière, petit et lent), 2 = proche (devant, gros et rapide), 3 = vers la caméra. */
    private static final class Meteor {
        int kind;
        float sx, sy, dirX, dirY, travel, tailMax, size;
        long t0, dur;
    }
    private final java.util.ArrayList<Meteor> meteors = new java.util.ArrayList<Meteor>();
    private long nextAt;

    ShootingStars(Context c) {
        super(c);
        setClickable(false);
        setFocusable(false);
        int H = 64;
        halo = Bitmap.createBitmap(H, H, Bitmap.Config.ARGB_8888);
        Paint hp = new Paint(Paint.ANTI_ALIAS_FLAG);
        hp.setShader(new RadialGradient(H / 2f, H / 2f, H / 2f,
                new int[]{0xFFFFFFFF, 0x66D2A8FF, 0x00B47CFF}, new float[]{0f, 0.25f, 1f}, Shader.TileMode.CLAMP));
        new Canvas(halo).drawCircle(H / 2f, H / 2f, H / 2f, hp);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        float d = getResources().getDisplayMetrics().density;
        stars = new Star[20];
        for (int i = 0; i < stars.length; i++) {
            Star s = new Star();
            s.x = rnd.nextFloat() * w;
            s.y = rnd.nextFloat() * h * 0.55f;      // dans le ciel, au-dessus des montagnes
            s.sparkle = i % 3 == 0;
            s.r = (s.sparkle ? 3.2f + rnd.nextFloat() * 2.4f : 1f + rnd.nextFloat() * 1.3f) * d;
            s.ph = rnd.nextFloat() * 6.28f;
            s.sp = 0.0010f + rnd.nextFloat() * 0.0018f;
            stars[i] = s;
        }
        nextAt = System.currentTimeMillis() + 1500;
    }

    private void spawn(int w, int h) {
        Meteor m = new Meteor();
        float r = rnd.nextFloat();
        m.kind = r < 0.30f ? 0 : r < 0.50f ? 1 : r < 0.75f ? 2 : 3;
        m.t0 = System.currentTimeMillis();
        float skyH = h * 0.56f;                       // ils restent dans le ciel, au-dessus des montagnes
        boolean fromRight = rnd.nextBoolean();
        switch (m.kind) {
            case 1: {   // derrière : petit, pâle, lent, direction quelconque
                double a = Math.toRadians(rnd.nextFloat() * 360f);
                m.dirX = (float) Math.cos(a); m.dirY = (float) Math.sin(a) * 0.6f;
                m.sx = w * (0.1f + rnd.nextFloat() * 0.8f); m.sy = skyH * (0.1f + rnd.nextFloat() * 0.7f);
                m.travel = w * (0.25f + rnd.nextFloat() * 0.20f);
                m.tailMax = w * 0.09f; m.size = 0.55f;
                m.dur = 1500 + (long) (rnd.nextFloat() * 700);
                break;
            }
            case 2: {   // devant : gros, très lumineux, long, rapide
                double a = Math.toRadians(14 + rnd.nextFloat() * 40);
                m.dirX = (float) Math.cos(a) * (fromRight ? -1f : 1f); m.dirY = (float) Math.sin(a);
                m.sx = fromRight ? w * (0.8f + rnd.nextFloat() * 0.3f) : -w * (0.1f + rnd.nextFloat() * 0.2f);
                m.sy = skyH * (0.02f + rnd.nextFloat() * 0.40f);
                m.travel = w * (0.9f + rnd.nextFloat() * 0.3f);
                m.tailMax = w * (0.34f + rnd.nextFloat() * 0.12f); m.size = 1.5f;
                m.dur = 700 + (long) (rnd.nextFloat() * 350);
                break;
            }
            case 3: {   // vers la caméra : part d'un point lointain du ciel et grossit en s'approchant
                double a = Math.toRadians(rnd.nextFloat() * 360f);
                m.dirX = (float) Math.cos(a); m.dirY = (float) Math.sin(a);
                m.sx = w * (0.25f + rnd.nextFloat() * 0.5f); m.sy = skyH * (0.25f + rnd.nextFloat() * 0.4f);
                m.travel = w * (0.45f + rnd.nextFloat() * 0.25f);
                m.tailMax = w * 0.26f; m.size = 1.2f;
                m.dur = 1100 + (long) (rnd.nextFloat() * 400);
                break;
            }
            default: {  // classique : de tous les côtés (gauche→droite, droite→gauche, haut→bas, bas→haut en diagonale)
                double a = Math.toRadians(8 + rnd.nextFloat() * 70);
                float vx = fromRight ? -1f : 1f;
                float vy = rnd.nextFloat() < 0.2f ? -1f : 1f;       // parfois vers le haut
                m.dirX = (float) Math.cos(a) * vx; m.dirY = (float) Math.sin(a) * vy;
                m.sx = fromRight ? w * (0.55f + rnd.nextFloat() * 0.5f) : w * (-0.05f + rnd.nextFloat() * 0.45f);
                m.sy = vy > 0 ? skyH * (0.02f + rnd.nextFloat() * 0.35f) : skyH * (0.55f + rnd.nextFloat() * 0.4f);
                m.travel = w * (0.6f + rnd.nextFloat() * 0.3f);
                m.tailMax = w * (0.18f + rnd.nextFloat() * 0.10f); m.size = 1f;
                m.dur = 900 + (long) (rnd.nextFloat() * 500);
            }
        }
        // ne jamais sortir du ciel vers le bas
        if (m.dirY > 0.01f) {
            float maxT = (skyH - m.sy) / m.dirY;
            if (maxT > 0) m.travel = Math.min(m.travel, maxT); else m.travel = 0;
        }
        meteors.add(m);
    }

    private void drawMeteor(Canvas c, Meteor m, long now, float d) {
        float t = (now - m.t0) / (float) m.dur;
        float env = (float) Math.sin(Math.PI * t);
        float u = m.kind == 3 ? t * t : t;                          // vers la caméra : accélère
        float grow = m.kind == 3 ? 0.35f + 2.4f * t * t : 1f;         // et grossit
        float hx = m.sx + m.dirX * m.travel * u, hy = m.sy + m.dirY * m.travel * u;
        float tail = m.tailMax * grow * Math.min(1f, t / 0.2f) * (t > 0.8f ? (1f - t) / 0.2f : 1f);
        if (m.kind == 3) tail = m.tailMax * (0.15f + 1.1f * t) * (t > 0.85f ? (1f - t) / 0.15f : 1f);
        float ex = hx - m.dirX * tail, ey = hy - m.dirY * tail;
        float nx = -m.dirY, ny = m.dirX;
        float bright = m.kind == 1 ? 0.55f : 1f;
        for (int k = 0; k < 2; k++) {
            float wd = (k == 0 ? 4.5f : 1.7f) * d * m.size * grow;
            path.reset();
            path.moveTo(hx + nx * wd, hy + ny * wd);
            path.lineTo(ex, ey);
            path.lineTo(hx - nx * wd, hy - ny * wd);
            path.close();
            int head = k == 0 ? (Math.round(120 * env * bright) << 24) | 0xB47CFF : (Math.round(255 * env * bright) << 24) | 0xFFFFFF;
            int end = k == 0 ? 0x009B5CFF : 0x00C9A8FF;
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(hx, hy, ex, ey, head, end, Shader.TileMode.CLAMP));
            c.drawPath(path, p);
        }
        p.setShader(null);
        p.setAlpha(Math.round(255 * env * bright));
        float hr = 11f * d * m.size * grow;
        c.drawBitmap(halo, null, new android.graphics.RectF(hx - hr, hy - hr, hx + hr, hy + hr), p);
        drawSparkle(c, hx, hy, 6f * d * m.size * grow, Math.round(255 * env * bright));
    }

    private void drawSparkle(Canvas c, float x, float y, float r, int a) {
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor((a << 24) | 0xFFF2FF);
        path.reset();
        path.moveTo(x, y - r);
        path.quadTo(x, y, x + r * 0.28f, y);
        path.quadTo(x, y, x, y + r);
        path.quadTo(x, y, x - r * 0.28f, y);
        path.quadTo(x, y, x, y - r);
        c.drawPath(path, p);
        path.reset();
        path.moveTo(x - r * 0.7f, y);
        path.quadTo(x, y, x, y - r * 0.2f);
        path.quadTo(x, y, x + r * 0.7f, y);
        path.quadTo(x, y, x, y + r * 0.2f);
        path.quadTo(x, y, x - r * 0.7f, y);
        c.drawPath(path, p);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        long now = System.currentTimeMillis();
        float d = getResources().getDisplayMetrics().density;

        for (Star s : stars) {
            float tw = 0.5f + 0.5f * (float) Math.sin(now * s.sp + s.ph);
            float al = 0.25f + 0.75f * tw;
            p.setShader(null);
            p.setAlpha(Math.round(120 * al));
            float hr = s.r * 4f;
            c.drawBitmap(halo, null, new android.graphics.RectF(s.x - hr, s.y - hr, s.x + hr, s.y + hr), p);
            if (s.sparkle) {
                drawSparkle(c, s.x, s.y, s.r * (1.2f + 0.5f * tw), Math.round(255 * al));
            } else {
                p.setStyle(Paint.Style.FILL);
                p.setColor(((Math.round(255 * al)) << 24) | 0xF4EAFF);
                c.drawCircle(s.x, s.y, s.r * 0.55f, p);
            }
        }

        if (now >= nextAt) {
            spawn(w, h);
            if (rnd.nextFloat() < 0.3f) spawn(w, h);                 // parfois deux en même temps
            nextAt = now + 1600 + (long) (rnd.nextFloat() * 2600);
        }
        for (int i = meteors.size() - 1; i >= 0; i--) {
            Meteor m = meteors.get(i);
            if (now - m.t0 >= m.dur) { meteors.remove(i); continue; }
            drawMeteor(c, m, now, d);
        }
        if (isShown()) postInvalidateOnAnimation();
    }

    @Override
    protected void onWindowVisibilityChanged(int v) {
        super.onWindowVisibilityChanged(v);
        if (v == View.VISIBLE) postInvalidateOnAnimation();
    }
}
