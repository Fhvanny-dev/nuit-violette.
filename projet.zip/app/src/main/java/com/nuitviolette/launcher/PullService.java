package com.nuitviolette.launcher;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/**
 * Bande invisible posée sur la barre d'état : quand on la tire vers le bas, c'est le volet
 * violet qui s'ouvre, jamais celui d'Android (image 1).
 */
public class PullService extends AccessibilityService {
    private WindowManager wm;
    private View strip;
    private static PullService inst;

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        int h = Math.max(id > 0 ? getResources().getDimensionPixelSize(id) : 0, Ui.dp(this, 28));
        strip = new View(this);
        strip.setOnTouchListener(new View.OnTouchListener() {
            float y0;
            boolean fired;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: y0 = e.getRawY(); fired = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (!fired && e.getRawY() - y0 > Ui.dp(PullService.this, 22)) {
                            fired = true;
                            Intent i = new Intent(PullService.this, MainActivity.class)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                    .putExtra("panel", true);
                            try { startActivity(i); } catch (Exception ignored) { }
                        }
                        return true;
                    default: return true;
                }
            }
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, h,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP;
        try { wm.addView(strip, lp); } catch (Exception ignored) { }
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { }

    @Override
    public void onDestroy() {
        if (inst == this) inst = null;
        try { if (strip != null) wm.removeView(strip); } catch (Exception ignored) { }
        super.onDestroy();
    }

    static boolean enabled(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(c.getPackageName() + "/");
    }
}
