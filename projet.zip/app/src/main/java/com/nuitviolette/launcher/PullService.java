package com.nuitviolette.launcher;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/**
 * Barre d'état iPhone posée PAR-DESSUS la barre d'Android, partout (accueil, applis, verrouillage).
 * - Sur l'accueil du launcher : transparente (l'image reste plein écran).
 * - Dans une autre appli : fond noir opaque, elle masque complètement la barre d'Android.
 * Tirer vers le bas dessus ouvre le volet violet, jamais celui d'Android.
 */
public class PullService extends AccessibilityService {
    private WindowManager wm;
    private IosStatusBar bar;
    private static PullService inst;
    private static boolean home = false;
    private static boolean cover = false;
    private final Handler h = new Handler(Looper.getMainLooper());
    private boolean screenOn = true;
    private long lastRefresh = 0;
    private android.content.BroadcastReceiver rx;
    private android.net.ConnectivityManager.NetworkCallback netCb;

    /** Rafraîchit la barre, au plus une fois par seconde, et jamais écran éteint. */
    private void refreshBar() {
        if (bar == null || !screenOn) return;
        long now = android.os.SystemClock.elapsedRealtime();
        if (now - lastRefresh < 1000) return;
        lastRefresh = now;
        bar.refresh();
    }

    /** Le launcher est (ou n'est plus) au premier plan. */
    static void setHome(boolean v) {
        home = v;
        cover = false;
        final PullService s = inst;
        if (s != null) s.h.post(new Runnable() { @Override public void run() { s.applyBg(); } });
    }

    /** Force le fond opaque un instant (la barre d'Android réapparaît dans le launcher). */
    static void setCover(boolean v) {
        cover = v;
        final PullService s = inst;
        if (s != null) s.h.post(new Runnable() { @Override public void run() { s.applyBg(); } });
        if (v && s != null) s.h.postDelayed(new Runnable() {
            @Override public void run() { cover = false; s.applyBg(); }
        }, 2500);
    }

    private void applyBg() {
        if (bar != null) bar.setBg(home && !cover ? 0 : 0xFF000000);
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        int sh = Math.max(id > 0 ? getResources().getDimensionPixelSize(id) : 0, Ui.dp(this, 28));
        bar = new IosStatusBar(this);
        bar.setOnTouchListener(new View.OnTouchListener() {
            float y0;
            boolean fired;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: y0 = e.getRawY(); fired = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (!fired && e.getRawY() - y0 > Ui.dp(PullService.this, 22)) {
                            fired = true;
                            Intent i = new Intent(PullService.this, MainActivity.class)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                    .putExtra("panel", true);
                            try { startActivity(i); } catch (Exception ignored) { }
                        }
                        return true;
                    default: return true;
                }
            }
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, sh,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP;
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30 ? 3 : 1;
        try { wm.addView(bar, lp); } catch (Exception ignored) { }
        applyBg();
        bar.refresh();
        // événements seulement (aucune boucle) : minute qui change, batterie, écran, réseau
        try {
            android.os.PowerManager pm = (android.os.PowerManager) getSystemService(Context.POWER_SERVICE);
            screenOn = pm == null || pm.isInteractive();
        } catch (Throwable ignored) { }
        rx = new android.content.BroadcastReceiver() {
            @Override public void onReceive(Context c, Intent i) {
                String a = i.getAction();
                if (Intent.ACTION_SCREEN_OFF.equals(a)) { screenOn = false; return; }
                if (Intent.ACTION_SCREEN_ON.equals(a)) { screenOn = true; lastRefresh = 0; }
                refreshBar();
            }
        };
        android.content.IntentFilter f = new android.content.IntentFilter();
        f.addAction(Intent.ACTION_TIME_TICK);          // 1x / minute, seulement écran allumé
        f.addAction(Intent.ACTION_BATTERY_CHANGED);    // seulement quand le niveau change
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_TIMEZONE_CHANGED);
        try { registerReceiver(rx, f); } catch (Throwable ignored) { }
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            netCb = new android.net.ConnectivityManager.NetworkCallback() {
                @Override public void onCapabilitiesChanged(android.net.Network n, android.net.NetworkCapabilities nc) { h.post(new Runnable() { @Override public void run() { refreshBar(); } }); }
                @Override public void onLost(android.net.Network n) { h.post(new Runnable() { @Override public void run() { refreshBar(); } }); }
            };
            cm.registerDefaultNetworkCallback(netCb);
        } catch (Throwable ignored) { netCb = null; }
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // changement d'appli : rafraîchissement limité à 1/seconde (voir refreshBar)
        refreshBar();
    }
    @Override public void onInterrupt() { }

    @Override
    public void onDestroy() {
        if (inst == this) inst = null;
        try { if (rx != null) unregisterReceiver(rx); } catch (Exception ignored) { }
        try { if (netCb != null) ((android.net.ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE)).unregisterNetworkCallback(netCb); } catch (Exception ignored) { }
        try { if (bar != null) wm.removeView(bar); } catch (Exception ignored) { }
        super.onDestroy();
    }

    static boolean enabled(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(c.getPackageName() + "/");
    }
}
