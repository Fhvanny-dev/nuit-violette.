package com.nuitviolette.launcher;

import android.accessibilityservice.AccessibilityService;
import android.content.Context;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;

/**
 * Barre d'état iPhone posée PAR-DESSUS la barre d'Android, partout (accueil, applis, verrouillage).
 * - Sur l'accueil du launcher : transparente (l'image reste plein écran).
 * - Dans une autre appli : fond noir opaque, elle masque complètement la barre d'Android.
 * Tirer vers le bas dessus ouvre le volet violet, jamais celui d'Android.
 */
public class PullService extends AccessibilityService {
    private WindowManager wm;
    private IosStatusBar bar;
    private static PullService inst;
    private static boolean home = false;
    private static boolean cover = false;
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (bar != null) bar.refresh();
            h.postDelayed(this, 5000);
        }
    };

    /** Le launcher est (ou n'est plus) au premier plan. */
    static void setHome(boolean v) {
        home = v;
        cover = false;
        final PullService s = inst;
        if (s != null) s.h.post(new Runnable() { @Override public void run() { s.applyBg(); } });
    }

    /** Force le fond opaque un instant (la barre d'Android réapparaît dans le launcher). */
    static void setCover(boolean v) {
        cover = v;
        final PullService s = inst;
        if (s != null) s.h.post(new Runnable() { @Override public void run() { s.applyBg(); } });
        if (v && s != null) s.h.postDelayed(new Runnable() {
            @Override public void run() { cover = false; s.applyBg(); }
        }, 2500);
    }

    private void applyBg() {
        if (bar != null) bar.setBg(home && !cover ? 0 : 0xFF000000);
    }

    @Override
    protected void onServiceConnected() {
        super.onServiceConnected();
        inst = this;
        wm = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        int sh = Math.max(id > 0 ? getResources().getDimensionPixelSize(id) : 0, Ui.dp(this, 28));
        bar = new IosStatusBar(this);
        bar.setOnTouchListener(new View.OnTouchListener() {
            float y0;
            boolean fired;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: y0 = e.getRawY(); fired = false; return true;
                    case MotionEvent.ACTION_MOVE:
                        if (!fired && e.getRawY() - y0 > Ui.dp(PullService.this, 22)) {
                            fired = true;
                            Intent i = new Intent(PullService.this, MainActivity.class)
                                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP)
                                    .putExtra("panel", true);
                            try { startActivity(i); } catch (Exception ignored) { }
                        }
                        return true;
                    default: return true;
                }
            }
        });
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, sh,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP;
        if (Build.VERSION.SDK_INT >= 28) lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30 ? 3 : 1;
        try { wm.addView(bar, lp); } catch (Exception ignored) { }
        applyBg();
        bar.refresh();
        h.removeCallbacks(tick);
        h.postDelayed(tick, 5000);
    }

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        // changement de fenêtre : on rafraîchit l'heure / réseau / batterie tout de suite
        if (bar != null) bar.refresh();
    }
    @Override public void onInterrupt() { }

    @Override
    public void onDestroy() {
        if (inst == this) inst = null;
        h.removeCallbacks(tick);
        try { if (bar != null) wm.removeView(bar); } catch (Exception ignored) { }
        super.onDestroy();
    }

    static boolean enabled(Context c) {
        String s = Settings.Secure.getString(c.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        return s != null && s.contains(c.getPackageName() + "/");
    }
}
