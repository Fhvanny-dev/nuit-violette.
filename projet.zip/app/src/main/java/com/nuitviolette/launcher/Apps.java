package com.nuitviolette.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

final class Apps {
    static final class App {
        String pkg;
        String label;
        int cat;
        Intent launch;
        Bitmap bmp;
    }

    /** Liste des applications lançables, icônes déjà dessinées en bulles. */
    static List<App> load(Context c) {
        PackageManager pm = c.getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN, null);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> ris = pm.queryIntentActivities(q, 0);
        List<App> out = new ArrayList<App>();
        Set<String> seen = new HashSet<String>();
        for (ResolveInfo ri : ris) {
            if (ri.activityInfo == null) continue;
            String p = ri.activityInfo.packageName;
            String key = p + "/" + ri.activityInfo.name;
            if (!seen.add(key)) continue;
            App a = new App();
            a.pkg = p;
            CharSequence lb = ri.loadLabel(pm);
            a.label = lb == null ? p : lb.toString();
            a.cat = ri.activityInfo.applicationInfo != null ? ri.activityInfo.applicationInfo.category : -1;
            a.launch = new Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(new ComponentName(p, ri.activityInfo.name))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            try {
                a.bmp = bubble(c, ri.loadIcon(pm));
            } catch (Throwable t) {
                a.bmp = bubble(c, pm.getDefaultActivityIcon());
            }
            out.add(a);
        }
        Collections.sort(out, new Comparator<App>() {
            @Override public int compare(App x, App y) { return x.label.compareToIgnoreCase(y.label); }
        });
        return out;
    }

    static boolean inTab(App a, int tab) {
        switch (tab) {
            case 1: return a.cat == ApplicationInfo.CATEGORY_SOCIAL;
            case 2: return a.cat == ApplicationInfo.CATEGORY_AUDIO || a.cat == ApplicationInfo.CATEGORY_VIDEO
                    || a.cat == ApplicationInfo.CATEGORY_IMAGE;
            case 3: return a.cat == ApplicationInfo.CATEGORY_PRODUCTIVITY || a.cat == ApplicationInfo.CATEGORY_NEWS;
            case 4: return a.cat == ApplicationInfo.CATEGORY_GAME;
            default: return true;
        }
    }

    /**
     * Extrait un "glyphe" propre d'une icône : on prend la couche monochrome (icônes thématiques Android 13+)
     * si elle existe, sinon l'avant-plan, sinon l'icône entière dont on retire le fond uni.
     * Le résultat est recoloré en blanc-lilas lumineux, comme sur les icônes du thème.
     */
    private static Bitmap glyph(Drawable ic, int D, int box) {
        Drawable src = ic;
        boolean mono = false;
        float scale = 1f;
        if (ic instanceof AdaptiveIconDrawable) {
            AdaptiveIconDrawable ad = (AdaptiveIconDrawable) ic;
            Drawable m = android.os.Build.VERSION.SDK_INT >= 33 ? ad.getMonochrome() : null;
            if (m != null) { src = m; mono = true; }
            else if (ad.getForeground() != null) src = ad.getForeground();
            scale = 1.5f;
        }
        Bitmap sb = Bitmap.createBitmap(D, D, Bitmap.Config.ARGB_8888);
        Canvas sc = new Canvas(sb);
        int side = Math.round(D * scale), off = (D - side) / 2;
        src.setBounds(off, off, off + side, off + side);
        src.draw(sc);
        int[] px = new int[D * D];
        sb.getPixels(px, 0, D, 0, 0, D, D);

        int transp = 0;
        for (int p : px) if ((p >>> 24) < 40) transp++;
        boolean useAlpha = mono || transp > D * D * 0.06f;
        float[] al = new float[D * D];
        float[] lum = new float[D * D];
        float cov = 0;
        float r0 = 0, g0 = 0, b0 = 0;
        if (!useAlpha) {
            int n = 0;
            int[][] corners = {{2, 2}, {D - 8, 2}, {2, D - 8}, {D - 8, D - 8}};
            for (int[] cn : corners) for (int y = 0; y < 6; y++) for (int x = 0; x < 6; x++) {
                int p = px[(cn[1] + y) * D + cn[0] + x];
                r0 += (p >> 16) & 255; g0 += (p >> 8) & 255; b0 += p & 255; n++;
            }
            r0 /= n; g0 /= n; b0 /= n;
        }
        for (int i = 0; i < px.length; i++) {
            int p = px[i];
            float r = (p >> 16) & 255, g = (p >> 8) & 255, b = p & 255;
            lum[i] = (0.299f * r + 0.587f * g + 0.114f * b) / 255f;
            if (useAlpha) al[i] = (p >>> 24) / 255f;
            else {
                float d = (float) Math.sqrt((r - r0) * (r - r0) + (g - g0) * (g - g0) + (b - b0) * (b - b0));
                al[i] = Math.max(0f, Math.min(1f, (d - 35f) / 55f));
            }
            if (al[i] > 0.5f) cov++;
        }
        if (!useAlpha && (cov < D * D * 0.02f || cov > D * D * 0.9f)) {
            for (int i = 0; i < al.length; i++) al[i] = (px[i] >>> 24) / 255f;
        }
        int minX = D, minY = D, maxX = -1, maxY = -1;
        int[] outPx = new int[D * D];
        for (int y = 0; y < D; y++) for (int x = 0; x < D; x++) {
            int i = y * D + x;
            float a = al[i];
            if (a <= 0.02f) continue;
            float shade = mono ? 1f : Math.max(0f, Math.min(1f, 0.38f + 0.95f * lum[i]));
            int r = Math.round(0x8E + (0xF8 - 0x8E) * shade);
            int g = Math.round(0x54 + (0xEE - 0x54) * shade);
            int b = Math.round(0xF0 + (0xFF - 0xF0) * shade);
            outPx[i] = (Math.round(a * 255) << 24) | (r << 16) | (g << 8) | b;
            if (a > 0.25f) {
                if (x < minX) minX = x; if (x > maxX) maxX = x;
                if (y < minY) minY = y; if (y > maxY) maxY = y;
            }
        }
        if (maxX < 0) { minX = 0; minY = 0; maxX = D - 1; maxY = D - 1; }
        Bitmap ob = Bitmap.createBitmap(outPx, D, D, Bitmap.Config.ARGB_8888);
        Bitmap crop = Bitmap.createBitmap(ob, minX, minY, maxX - minX + 1, maxY - minY + 1);
        float k = Math.min(box / (float) crop.getWidth(), box / (float) crop.getHeight());
        return Bitmap.createScaledBitmap(crop, Math.max(1, Math.round(crop.getWidth() * k)),
                Math.max(1, Math.round(crop.getHeight() * k)), true);
    }

    /** Bulle de verre violette (comme le thème) avec le glyphe de l'appli en blanc-lilas lumineux. */
    static Bitmap bubble(Context c, Drawable ic) {
        int S = Ui.dp(c, 76);
        Bitmap b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float pad = S * 0.08f;
        RectF r = new RectF(pad, pad, S - pad, S - pad);
        float rad = S * 0.34f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        // halo extérieur
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(S * 0.07f);
        p.setColor(0xAA9B5CFF);
        p.setMaskFilter(new android.graphics.BlurMaskFilter(S * 0.055f, android.graphics.BlurMaskFilter.Blur.NORMAL));
        cv.drawRoundRect(r, rad, rad, p);
        p.setMaskFilter(null);
        // verre translucide sombre
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, r.top, 0, r.bottom, 0xD0371280, 0xE60F0330, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        // lueur interne en bas (reflet violet)
        p.setShader(new RadialGradient(S * 0.5f, S * 0.95f, S * 0.55f, 0x88B26BFF, 0x00000000, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        // lueur interne en haut à gauche
        p.setShader(new RadialGradient(S * 0.28f, S * 0.18f, S * 0.6f, 0x77E4CCFF, 0x00000000, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // glyphe + halo doux
        try {
            Bitmap g = glyph(ic, 160, Math.round(S * 0.47f));
            float gx = (S - g.getWidth()) / 2f, gy = (S - g.getHeight()) / 2f;
            Paint gl = new Paint(Paint.ANTI_ALIAS_FLAG);
            gl.setMaskFilter(new android.graphics.BlurMaskFilter(S * 0.035f, android.graphics.BlurMaskFilter.Blur.NORMAL));
            gl.setColor(0xFFC58BFF);
            cv.drawBitmap(g.extractAlpha(), gx, gy, gl);
            Paint gp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
            cv.drawBitmap(g, gx, gy, gp);
        } catch (Throwable t) { /* icône illisible : bulle vide */ }

        // bord brillant
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(S * 0.04f);
        p.setShader(new LinearGradient(0, 0, S, S, new int[]{0xFFFBF4FF, 0xFF9B5CFF, 0xFFE2C4FF}, null, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(null);
        // reflet en arc en haut à gauche
        p.setStrokeWidth(S * 0.026f);
        p.setColor(0xB3FFFFFF);
        p.setStrokeCap(Paint.Cap.ROUND);
        float q = pad + S * 0.07f;
        cv.drawArc(new RectF(q, q, q + S * 0.5f, q + S * 0.5f), 190, 70, false, p);
        // petite étincelle
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xCCFFFFFF);
        cv.drawCircle(S * 0.80f, S * 0.20f, S * 0.016f, p);
        return b;
    }
}
