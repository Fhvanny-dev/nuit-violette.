package com.nuitviolette.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

final class Apps {
    static final class App {
        String pkg;
        String label;
        int cat;
        Intent launch;
        Bitmap bmp;
    }

    /** Liste des applications lançables, icônes déjà dessinées en bulles. */
    static List<App> load(Context c) {
        PackageManager pm = c.getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN, null);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> ris = pm.queryIntentActivities(q, 0);
        List<App> out = new ArrayList<App>();
        Set<String> seen = new HashSet<String>();
        for (ResolveInfo ri : ris) {
            if (ri.activityInfo == null) continue;
            String p = ri.activityInfo.packageName;
            String key = p + "/" + ri.activityInfo.name;
            if (!seen.add(key)) continue;
            App a = new App();
            a.pkg = p;
            CharSequence lb = ri.loadLabel(pm);
            a.label = lb == null ? p : lb.toString();
            a.cat = ri.activityInfo.applicationInfo != null ? ri.activityInfo.applicationInfo.category : -1;
            a.launch = new Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(new ComponentName(p, ri.activityInfo.name))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            try {
                a.bmp = bubble(c, ri.loadIcon(pm));
            } catch (Throwable t) {
                a.bmp = bubble(c, pm.getDefaultActivityIcon());
            }
            out.add(a);
        }
        Collections.sort(out, new Comparator<App>() {
            @Override public int compare(App x, App y) { return x.label.compareToIgnoreCase(y.label); }
        });
        return out;
    }

    static boolean inTab(App a, int tab) {
        switch (tab) {
            case 1: return a.cat == ApplicationInfo.CATEGORY_SOCIAL;
            case 2: return a.cat == ApplicationInfo.CATEGORY_AUDIO || a.cat == ApplicationInfo.CATEGORY_VIDEO
                    || a.cat == ApplicationInfo.CATEGORY_IMAGE;
            case 3: return a.cat == ApplicationInfo.CATEGORY_PRODUCTIVITY || a.cat == ApplicationInfo.CATEGORY_NEWS;
            case 4: return a.cat == ApplicationInfo.CATEGORY_GAME;
            default: return true;
        }
    }

    /** Dessine l'icône dans une bulle de verre violette (lueur, bord brillant, glyphe teinté lilas). */
    static Bitmap bubble(Context c, Drawable ic) {
        int S = Ui.dp(c, 76);
        Bitmap b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float pad = S * 0.08f;
        RectF r = new RectF(pad, pad, S - pad, S - pad);
        float rad = S * 0.32f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        // halo lumineux
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(S * 0.06f);
        p.setColor(0xAA9B5CFF);
        p.setMaskFilter(new android.graphics.BlurMaskFilter(S * 0.05f, android.graphics.BlurMaskFilter.Blur.NORMAL));
        cv.drawRoundRect(r, rad, rad, p);
        p.setMaskFilter(null);
        // verre
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, S, 0xFF40168C, 0xFF140436, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(new RadialGradient(S * 0.3f, S * 0.2f, S * 0.7f, 0x88D2A8FF, 0x00000000, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        // glyphe : icône désaturée et teintée lilas
        int ib = Math.round(S * 0.56f);
        Bitmap ibm = Bitmap.createBitmap(ib, ib, Bitmap.Config.ARGB_8888);
        Canvas ic2 = new Canvas(ibm);
        Path clip = new Path();
        clip.addRoundRect(new RectF(0, 0, ib, ib), ib * 0.26f, ib * 0.26f, Path.Direction.CW);
        ic2.clipPath(clip);
        float side = (ic instanceof AdaptiveIconDrawable) ? ib * 1.5f : ib;
        int off = Math.round((ib - side) / 2f);
        ic.setBounds(off, off, off + Math.round(side), off + Math.round(side));
        ic.draw(ic2);
        android.graphics.ColorMatrix cm = new android.graphics.ColorMatrix();
        cm.setSaturation(0.45f);
        cm.postConcat(new android.graphics.ColorMatrix(new float[]{
                1.05f, 0, 0, 0, 30,
                0, 0.93f, 0, 0, 18,
                0, 0, 1.2f, 0, 46,
                0, 0, 0, 1, 0}));
        Paint ip = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        ip.setColorFilter(new android.graphics.ColorMatrixColorFilter(cm));
        cv.drawBitmap(ibm, (S - ib) / 2f, (S - ib) / 2f, ip);

        // bord brillant + reflet
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(S * 0.04f);
        p.setShader(new LinearGradient(0, 0, S, S, new int[]{0xFFF7EEFF, 0xFF9B5CFF, 0xFFE2C4FF}, null, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(null);
        p.setStrokeWidth(S * 0.022f);
        p.setColor(0x99FFFFFF);
        p.setStrokeCap(Paint.Cap.ROUND);
        float q = pad + S * 0.07f;
        cv.drawArc(new RectF(q, q, q + S * 0.5f, q + S * 0.5f), 190, 70, false, p);
        return b;
    }
}
