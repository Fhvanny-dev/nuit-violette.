package com.nuitviolette.launcher;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.drawable.AdaptiveIconDrawable;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

final class Apps {
    static final class App {
        String pkg;
        String label;
        int cat;
        Intent launch;
        Bitmap bmp;
    }

    /** Liste des applications lançables, icônes déjà dessinées en bulles. */
    static List<App> load(Context c) {
        PackageManager pm = c.getPackageManager();
        Intent q = new Intent(Intent.ACTION_MAIN, null);
        q.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> ris = pm.queryIntentActivities(q, 0);
        List<App> out = new ArrayList<App>();
        Set<String> seen = new HashSet<String>();
        for (ResolveInfo ri : ris) {
            if (ri.activityInfo == null) continue;
            String p = ri.activityInfo.packageName;
            String key = p + "/" + ri.activityInfo.name;
            if (!seen.add(key)) continue;
            App a = new App();
            a.pkg = p;
            CharSequence lb = ri.loadLabel(pm);
            a.label = lb == null ? p : lb.toString();
            a.cat = ri.activityInfo.applicationInfo != null ? ri.activityInfo.applicationInfo.category : -1;
            a.launch = new Intent(Intent.ACTION_MAIN)
                    .addCategory(Intent.CATEGORY_LAUNCHER)
                    .setComponent(new ComponentName(p, ri.activityInfo.name))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            try {
                a.bmp = bubble(c, ri.loadIcon(pm));
            } catch (Throwable t) {
                a.bmp = bubble(c, pm.getDefaultActivityIcon());
            }
            out.add(a);
        }
        Collections.sort(out, new Comparator<App>() {
            @Override public int compare(App x, App y) { return x.label.compareToIgnoreCase(y.label); }
        });
        return out;
    }

    static boolean inTab(App a, int tab) {
        switch (tab) {
            case 1: return a.cat == ApplicationInfo.CATEGORY_SOCIAL;
            case 2: return a.cat == ApplicationInfo.CATEGORY_AUDIO || a.cat == ApplicationInfo.CATEGORY_VIDEO
                    || a.cat == ApplicationInfo.CATEGORY_IMAGE;
            case 3: return a.cat == ApplicationInfo.CATEGORY_PRODUCTIVITY || a.cat == ApplicationInfo.CATEGORY_NEWS;
            case 4: return a.cat == ApplicationInfo.CATEGORY_GAME;
            default: return true;
        }
    }

    /** Dessine l'icône dans une bulle de verre violette. */
    static Bitmap bubble(Context c, Drawable ic) {
        int S = Ui.dp(c, 64);
        Bitmap b = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888);
        Canvas cv = new Canvas(b);
        float pad = S * 0.04f;
        RectF r = new RectF(pad, pad, S - pad, S - pad);
        float rad = S * 0.30f;
        Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        p.setShader(new LinearGradient(0, 0, 0, S, 0xFF4A1F9A, 0xFF140636, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(new RadialGradient(S / 2f, S * 0.18f, S * 0.75f, 0x779B5CFF, 0x00000000, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        p.setShader(null);

        float ib = S * 0.60f, cx = S / 2f, cy = S / 2f;
        Path clip = new Path();
        RectF ir = new RectF(cx - ib / 2, cy - ib / 2, cx + ib / 2, cy + ib / 2);
        clip.addRoundRect(ir, ib * 0.26f, ib * 0.26f, Path.Direction.CW);
        cv.save();
        cv.clipPath(clip);
        float side = (ic instanceof AdaptiveIconDrawable) ? ib * 1.5f : ib;
        ic.setBounds((int) (cx - side / 2), (int) (cy - side / 2), (int) (cx + side / 2), (int) (cy + side / 2));
        ic.draw(cv);
        cv.restore();

        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(S * 0.03f);
        p.setShader(new LinearGradient(0, 0, S, S, 0xFFEBD5FF, 0x558A4DF0, Shader.TileMode.CLAMP));
        cv.drawRoundRect(r, rad, rad, p);
        return b;
    }
}
