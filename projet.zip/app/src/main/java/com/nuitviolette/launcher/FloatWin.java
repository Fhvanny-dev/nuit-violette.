package com.nuitviolette.launcher;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Fenêtre flottante autonome (déplaçable, redimensionnable, gauche/droite/plein écran). */
final class FloatWin {
    static void open(final Context c, String title, String url) {
        final WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        final DisplayMetrics dm = c.getResources().getDisplayMetrics();
        final int sw = dm.widthPixels, sh = dm.heightPixels;
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                Math.round(sw * .9f), Math.round(sh * .55f),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = Math.round(sw * .05f);
        lp.y = Math.round(sh * .12f);

        final FrameLayout root = new FrameLayout(c);
        root.setBackground(Ui.grad(c, 18, 0xFF2A0C5E, 0xFF12042B, 0xAAC9A0FF));
        root.setElevation(Ui.dp(c, 16));
        root.setClipToOutline(true);
        final LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(c, 14), 0, Ui.dp(c, 6), 0);
        bar.setBackgroundColor(0xFF3A1C78);
        TextView tt = Ui.text(c, title, 14, Color.WHITE, true);
        tt.setSingleLine(true);
        bar.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView left = btn(c, "◧"), right = btn(c, "◨"), full = btn(c, "⛶"), close = btn(c, "✕");
        bar.addView(left); bar.addView(right); bar.addView(full); bar.addView(close);
        col.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(c, 44)));

        @SuppressLint("SetJavaScriptEnabled")
        final WebView wv = new WebView(c);
        WebSettings ws = wv.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        wv.setWebViewClient(new WebViewClient());
        wv.loadUrl(url);
        col.addView(wv, new LinearLayout.LayoutParams(-1, 0, 1f));

        final TextView grip = Ui.text(c, "◢", 22, 0xFFE9D5FF, false);
        grip.setPadding(Ui.dp(c, 10), Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 6));
        root.addView(grip, new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END));

        // déplacer par la barre
        bar.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: dx = e.getRawX(); dy = e.getRawY(); sx = lp.x; sy = lp.y; return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = sx + Math.round(e.getRawX() - dx);
                        lp.y = Math.max(0, sy + Math.round(e.getRawY() - dy));
                        try { wm.updateViewLayout(root, lp); } catch (Exception ignored) { }
                        return true;
                    default: return true;
                }
            }
        });
        // redimensionner par la poignée
        grip.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int w0, h0;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN: dx = e.getRawX(); dy = e.getRawY(); w0 = lp.width; h0 = lp.height; return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.width = Math.max(Math.round(sw * .4f), w0 + Math.round(e.getRawX() - dx));
                        lp.height = Math.max(Math.round(sh * .25f), h0 + Math.round(e.getRawY() - dy));
                        try { wm.updateViewLayout(root, lp); } catch (Exception ignored) { }
                        return true;
                    default: return true;
                }
            }
        });
        left.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            lp.x = 0; lp.y = 0; lp.width = sw / 2; lp.height = sh; upd(wm, root, lp); } });
        right.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            lp.x = sw / 2; lp.y = 0; lp.width = sw / 2; lp.height = sh; upd(wm, root, lp); } });
        full.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            lp.x = 0; lp.y = 0; lp.width = sw; lp.height = sh; upd(wm, root, lp); } });
        close.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            try { wv.destroy(); wm.removeView(root); } catch (Exception ignored) { } } });
        try { wm.addView(root, lp); } catch (Exception ignored) { }
    }

    private static void upd(WindowManager wm, View v, WindowManager.LayoutParams lp) {
        try { wm.updateViewLayout(v, lp); } catch (Exception ignored) { }
    }

    private static TextView btn(Context c, String s) {
        TextView t = Ui.text(c, s, 18, Color.WHITE, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(c, 10), 0, Ui.dp(c, 10), 0);
        return t;
    }

    static String urlFor(String pkg) {
        if (pkg.equals("com.whatsapp") || pkg.equals("com.whatsapp.w4b")) return "https://web.whatsapp.com";
        if (pkg.contains("youtube")) return "https://m.youtube.com";
        if (pkg.equals("com.google.android.gm")) return "https://mail.google.com";
        if (pkg.contains("maps")) return "https://www.google.com/maps";
        if (pkg.contains("chrome") || pkg.contains("browser")) return "https://www.google.com";
        if (pkg.equals("com.facebook.katana")) return "https://m.facebook.com";
        if (pkg.equals("com.instagram.android")) return "https://www.instagram.com";
        if (pkg.contains("musically") || pkg.contains("tiktok")) return "https://www.tiktok.com";
        if (pkg.equals("com.twitter.android")) return "https://x.com";
        if (pkg.equals("org.telegram.messenger")) return "https://web.telegram.org";
        if (pkg.equals("com.spotify.music")) return "https://open.spotify.com";
        if (pkg.equals("com.android.vending")) return "https://play.google.com";
        if (pkg.contains("apps.photos")) return "https://photos.google.com";
        if (pkg.contains("apps.docs") || pkg.contains("drive")) return "https://drive.google.com";
        if (pkg.contains("calendar")) return "https://calendar.google.com";
        return null;
    }
}
