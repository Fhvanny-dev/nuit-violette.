package com.nuitviolette.launcher;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.CookieManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

/**
 * Fenêtres flottantes gérées par l'application : jusqu'à 10 en même temps, déplaçables,
 * redimensionnables par les bords et les coins, collables à gauche / à droite / plein écran.
 */
final class FloatWin {
    private static final List<View> ALL = new ArrayList<View>();
    private static final String UA = "Mozilla/5.0 (Linux; Android 14; Pixel 8) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Mobile Safari/537.36";

    static boolean open(final Context c, String title, String url) {
        if (ALL.size() >= 10) {
            Toast.makeText(c, "10 fenêtres maximum : ferme-en une", Toast.LENGTH_SHORT).show();
            return false;
        }
        final WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        final DisplayMetrics dm = c.getResources().getDisplayMetrics();
        final int sw = dm.widthPixels, sh = dm.heightPixels;
        final int n = ALL.size();
        final WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                Math.round(sw * .88f), Math.round(sh * .55f),
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = Math.round(sw * .06f) + (n % 5) * Ui.dp(c, 22);
        lp.y = Math.round(sh * .10f) + (n % 5) * Ui.dp(c, 30);
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN;

        final FrameLayout root = new FrameLayout(c);
        root.setBackground(Ui.grad(c, 18, 0xFF2A0C5E, 0xFF12042B, 0xCCC9A0FF));
        root.setElevation(Ui.dp(c, 18));
        root.setClipToOutline(true);
        final LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        // barre de titre
        LinearLayout bar = new LinearLayout(c);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(c, 14), 0, Ui.dp(c, 4), 0);
        bar.setBackground(Ui.grad(c, 0, 0xFF4A1F9A, 0xFF2E1068, 0x00000000));
        TextView tt = Ui.text(c, title, 14, Color.WHITE, true);
        tt.setSingleLine(true);
        bar.addView(tt, new LinearLayout.LayoutParams(0, -2, 1f));
        final TextView left = btn(c, "◧"), right = btn(c, "◨"), full = btn(c, "⛶"), close = btn(c, "✕");
        bar.addView(left); bar.addView(right); bar.addView(full); bar.addView(close);
        col.addView(bar, new LinearLayout.LayoutParams(-1, Ui.dp(c, 42)));

        // barre d'adresse : n'importe quel site
        final EditText addr = new EditText(c);
        addr.setSingleLine(true);
        addr.setText(url);
        addr.setTextColor(0xFFF3E6FF);
        addr.setTextSize(13);
        addr.setPadding(Ui.dp(c, 12), 0, Ui.dp(c, 12), 0);
        addr.setBackground(Ui.glass(c, 14, 0x55200A4A, 0x889B5CFF));
        addr.setImeOptions(EditorInfo.IME_ACTION_GO);
        LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(-1, Ui.dp(c, 36));
        ap.setMargins(Ui.dp(c, 8), Ui.dp(c, 5), Ui.dp(c, 8), Ui.dp(c, 5));
        col.addView(addr, ap);

        @SuppressLint("SetJavaScriptEnabled")
        final WebView wv = new WebView(c);
        WebSettings ws = wv.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setLoadWithOverviewMode(true);
        ws.setUseWideViewPort(true);
        ws.setMediaPlaybackRequiresUserGesture(false);
        ws.setUserAgentString(UA);
        try { CookieManager.getInstance().setAcceptThirdPartyCookies(wv, true); } catch (Exception ignored) { }
        wv.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView v, String u, android.graphics.Bitmap f) { addr.setText(u); }
        });
        wv.loadUrl(url);
        col.addView(wv, new LinearLayout.LayoutParams(-1, 0, 1f));
        addr.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int a, android.view.KeyEvent e) {
                String t = addr.getText().toString().trim();
                if (t.isEmpty()) return true;
                if (!t.contains(" ") && t.contains(".")) wv.loadUrl(t.startsWith("http") ? t : "https://" + t);
                else wv.loadUrl("https://www.google.com/search?q=" + android.net.Uri.encode(t));
                return true;
            }
        });

        // poignées de redimensionnement : gauche, droite, bas, deux coins
        int e = Ui.dp(c, 14), k = Ui.dp(c, 30);
        handle(c, wm, root, lp, sw, sh, -1, 0, new FrameLayout.LayoutParams(e, -1, Gravity.START), null);
        handle(c, wm, root, lp, sw, sh, 1, 0, new FrameLayout.LayoutParams(e, -1, Gravity.END), null);
        handle(c, wm, root, lp, sw, sh, 0, 1, new FrameLayout.LayoutParams(-1, e, Gravity.BOTTOM), null);
        handle(c, wm, root, lp, sw, sh, -1, 1, new FrameLayout.LayoutParams(k, k, Gravity.BOTTOM | Gravity.START), "◣");
        handle(c, wm, root, lp, sw, sh, 1, 1, new FrameLayout.LayoutParams(k, k, Gravity.BOTTOM | Gravity.END), "◢");

        // déplacer par la barre de titre + passer devant
        bar.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int sx, sy;
            @Override public boolean onTouch(View v, MotionEvent ev) {
                switch (ev.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = ev.getRawX(); dy = ev.getRawY(); sx = lp.x; sy = lp.y;
                        front(wm, root, lp);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        lp.x = sx + Math.round(ev.getRawX() - dx);
                        lp.y = Math.max(0, sy + Math.round(ev.getRawY() - dy));
                        upd(wm, root, lp);
                        return true;
                    default: return true;
                }
            }
        });
        left.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            lp.x = 0; lp.y = 0; lp.width = sw / 2; lp.height = sh; upd(wm, root, lp); } });
        right.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            lp.x = sw / 2; lp.y = 0; lp.width = sw / 2; lp.height = sh; upd(wm, root, lp); } });
        full.setOnClickListener(new View.OnClickListener() {
            boolean max;
            int ox, oy, ow, oh;
            @Override public void onClick(View v) {
                if (!max) { ox = lp.x; oy = lp.y; ow = lp.width; oh = lp.height; lp.x = 0; lp.y = 0; lp.width = sw; lp.height = sh; }
                else { lp.x = ox; lp.y = oy; lp.width = ow; lp.height = oh; }
                max = !max;
                upd(wm, root, lp);
            } });
        close.setOnClickListener(new View.OnClickListener() { @Override public void onClick(View v) {
            ALL.remove(root);
            try { wv.destroy(); wm.removeView(root); } catch (Exception ignored) { } } });
        try { wm.addView(root, lp); ALL.add(root); } catch (Exception ex) { return false; }
        return true;
    }

    private static void handle(final Context c, final WindowManager wm, final FrameLayout root, final WindowManager.LayoutParams lp,
                               final int sw, final int sh, final int sx, final int sy, FrameLayout.LayoutParams p, String glyph) {
        TextView hnd = Ui.text(c, glyph == null ? "" : glyph, 18, 0xCCE9D5FF, false);
        hnd.setGravity(Gravity.CENTER);
        hnd.setOnTouchListener(new View.OnTouchListener() {
            float dx, dy; int x0, w0, h0;
            @Override public boolean onTouch(View v, MotionEvent e) {
                int minW = Math.round(sw * .35f), minH = Math.round(sh * .22f);
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dx = e.getRawX(); dy = e.getRawY(); x0 = lp.x; w0 = lp.width; h0 = lp.height;
                        front(wm, root, lp);
                        return true;
                    case MotionEvent.ACTION_MOVE: {
                        float mx = e.getRawX() - dx, my = e.getRawY() - dy;
                        if (sx == 1) lp.width = Math.max(minW, Math.round(w0 + mx));
                        if (sx == -1) { int w = Math.max(minW, Math.round(w0 - mx)); lp.x = x0 + (w0 - w); lp.width = w; }
                        if (sy == 1) lp.height = Math.max(minH, Math.round(h0 + my));
                        upd(wm, root, lp);
                        return true;
                    }
                    default: return true;
                }
            }
        });
        root.addView(hnd, p);
    }

    private static void front(WindowManager wm, FrameLayout root, WindowManager.LayoutParams lp) {
        if (ALL.isEmpty() || ALL.get(ALL.size() - 1) == root) return;
        try {
            wm.removeViewImmediate(root);
            wm.addView(root, lp);
            ALL.remove(root);
            ALL.add(root);
        } catch (Exception ignored) { }
    }

    private static void upd(WindowManager wm, View v, WindowManager.LayoutParams lp) {
        try { wm.updateViewLayout(v, lp); } catch (Exception ignored) { }
    }

    private static TextView btn(Context c, String s) {
        TextView t = Ui.text(c, s, 18, Color.WHITE, false);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(c, 10), 0, Ui.dp(c, 10), 0);
        return t;
    }

    static String urlFor(String pkg) {
        if (pkg.equals("com.whatsapp") || pkg.equals("com.whatsapp.w4b")) return "https://web.whatsapp.com";
        if (pkg.contains("youtube")) return "https://www.youtube.com";
        if (pkg.equals("com.google.android.gm")) return "https://mail.google.com";
        if (pkg.contains("maps")) return "https://www.google.com/maps";
        if (pkg.contains("chrome") || pkg.contains("browser")) return "https://www.google.com";
        if (pkg.equals("com.facebook.katana")) return "https://m.facebook.com";
        if (pkg.equals("com.instagram.android")) return "https://www.instagram.com";
        if (pkg.contains("musically") || pkg.contains("tiktok")) return "https://www.tiktok.com";
        if (pkg.equals("com.twitter.android")) return "https://x.com";
        if (pkg.equals("org.telegram.messenger")) return "https://web.telegram.org";
        if (pkg.equals("com.spotify.music")) return "https://open.spotify.com";
        if (pkg.equals("com.android.vending")) return "https://play.google.com";
        if (pkg.contains("apps.photos")) return "https://photos.google.com";
        if (pkg.contains("apps.docs") || pkg.contains("drive")) return "https://drive.google.com";
        if (pkg.contains("calendar")) return "https://calendar.google.com";
        return null;
    }
}
