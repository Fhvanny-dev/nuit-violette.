package com.nuitviolette.launcher;

import android.app.Activity;
import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Rect;
import android.provider.Settings;
import android.util.DisplayMetrics;

/**
 * Fenêtres : ouvre la VRAIE application du téléphone dans une fenêtre flottante (aucun navigateur,
 * aucune recherche Google). Le lanceur choisit la position et la taille ; Android affiche la fenêtre.
 */
final class FloatWin {
    private static int cascade = 0;

    /** Le téléphone sait-il afficher des applications en fenêtres libres ? */
    static boolean supported(Context c) {
        try {
            if (c.getPackageManager().hasSystemFeature(PackageManager.FEATURE_FREEFORM_WINDOW_MANAGEMENT)) return true;
        } catch (Throwable ignored) { }
        try {
            if (Settings.Global.getInt(c.getContentResolver(), "enable_freeform_support", 0) != 0) return true;
            if (Settings.Global.getInt(c.getContentResolver(), "force_resizable_activities", 0) != 0
                    && Settings.Global.getInt(c.getContentResolver(), "enable_freeform_support", 0) != 0) return true;
        } catch (Throwable ignored) { }
        return false;
    }

    /** Ouvre l'application a dans une fenêtre flottante (cascade de positions). Retourne false en cas d'échec. */
    static boolean open(Activity act, Apps.App a) {
        DisplayMetrics dm = act.getResources().getDisplayMetrics();
        int sw = dm.widthPixels, sh = dm.heightPixels;
        int n = cascade++ % 5;
        int dx = Ui.dp(act, 22) * n, dy = Ui.dp(act, 30) * n;
        int l = Math.round(sw * .06f) + dx, t = Math.round(sh * .10f) + dy;
        Rect r = new Rect(l, t, l + Math.round(sw * .88f), t + Math.round(sh * .55f));
        try {
            Intent i = new Intent(a.launch);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_MULTIPLE_TASK);
            act.startActivity(i, ActivityOptions.makeBasic().setLaunchBounds(r).toBundle());
            return true;
        } catch (Throwable e) {
            return false;
        }
    }
}
