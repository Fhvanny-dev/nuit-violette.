package com.nuitviolette.launcher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowInsets;
import android.widget.BaseAdapter;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Choisir, appli par appli, ce qui peut utiliser le Wi-Fi ou les données mobiles. */
public class DataActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private final List<Apps.App> all = new ArrayList<Apps.App>();
    private final List<Apps.App> shown = new ArrayList<Apps.App>();
    private Switch master;
    private boolean silent;
    private ProgressBar spin;
    private EditText filter;
    private BaseAdapter ad;
    private LinearLayout root;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                | View.SYSTEM_UI_FLAG_LAYOUT_FULL_SCREEN | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION);

        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0xFF1A0845, 0xFF080116});
        root.setBackground(bg);
        root.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public WindowInsets onApplyWindowInsets(View v, WindowInsets ins) {
                v.setPadding(0, ins.getSystemWindowInsetTop(), 0, ins.getSystemWindowInsetBottom());
                return ins;
            }
        });

        TextView title = Ui.text(this, "Contrôle des données", 24, Color.WHITE, true);
        Ui.glow(title, Ui.GLOW, 8);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(-1, -2);
        tp.setMargins(Ui.dp(this, 20), Ui.dp(this, 20), Ui.dp(this, 20), 0);
        root.addView(title, tp);

        TextView sub = Ui.text(this, "Pour chaque application, autorise ou bloque le Wi-Fi et les données mobiles "
                + "(ton forfait). Les réglages s'appliquent vraiment : une appli bloquée n'a plus Internet sur ce réseau.",
                13, Ui.SOFT, false);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(-1, -2);
        sp.setMargins(Ui.dp(this, 20), Ui.dp(this, 6), Ui.dp(this, 20), Ui.dp(this, 10));
        root.addView(sub, sp);

        master = new Switch(this);
        master.setText("Contrôle actif");
        master.setTextColor(Color.WHITE);
        master.setTextSize(17);
        master.setPadding(Ui.dp(this, 16), Ui.dp(this, 12), Ui.dp(this, 16), Ui.dp(this, 12));
        master.setBackground(Ui.glass(this, 20, 0x33FFFFFF, 0x669B5CFF));
        master.setChecked(Prefs.bool(this, Prefs.FW_ON, false));
        master.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton v, boolean on) {
                if (silent) return;
                if (on) {
                    Intent p = VpnService.prepare(DataActivity.this);
                    if (p != null) startActivityForResult(p, 77); else enable();
                } else {
                    FirewallService.stop(DataActivity.this);
                }
            }
        });
        LinearLayout.LayoutParams mp = new LinearLayout.LayoutParams(-1, -2);
        mp.setMargins(Ui.dp(this, 16), 0, Ui.dp(this, 16), Ui.dp(this, 8));
        root.addView(master, mp);

        // actions rapides
        LinearLayout quick = new LinearLayout(this);
        quick.setOrientation(LinearLayout.HORIZONTAL);
        quick.addView(chip("Bloquer le mobile pour tout", new Runnable() {
            @Override public void run() {
                Set<String> s = new HashSet<String>();
                for (Apps.App a : all) s.add(a.pkg);
                s.remove(getPackageName());
                Prefs.putSet(DataActivity.this, Prefs.BLOCK_MOB, s);
                changed();
            }
        }));
        quick.addView(chip("Tout autoriser", new Runnable() {
            @Override public void run() {
                Prefs.putSet(DataActivity.this, Prefs.BLOCK_MOB, new HashSet<String>());
                Prefs.putSet(DataActivity.this, Prefs.BLOCK_WIFI, new HashSet<String>());
                changed();
            }
        }));
        LinearLayout.LayoutParams qp = new LinearLayout.LayoutParams(-1, -2);
        qp.setMargins(Ui.dp(this, 16), 0, Ui.dp(this, 16), Ui.dp(this, 8));
        root.addView(quick, qp);

        filter = new EditText(this);
        filter.setHint("Rechercher une appli");
        filter.setHintTextColor(0x99E9D5FF);
        filter.setTextColor(Color.WHITE);
        filter.setSingleLine(true);
        filter.setPadding(Ui.dp(this, 18), 0, Ui.dp(this, 18), 0);
        filter.setBackground(Ui.glass(this, 24, 0x33FFFFFF, 0x669B5CFF));
        filter.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b2, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b2, int c) { }
            @Override public void afterTextChanged(Editable e) { refilter(); }
        });
        LinearLayout.LayoutParams fp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 46));
        fp.setMargins(Ui.dp(this, 16), 0, Ui.dp(this, 16), Ui.dp(this, 6));
        root.addView(filter, fp);

        spin = new ProgressBar(this);
        root.addView(spin, new LinearLayout.LayoutParams(-1, Ui.dp(this, 60)));

        ListView list = new ListView(this);
        list.setDivider(null);
        list.setSelector(new android.graphics.drawable.ColorDrawable(0));
        ad = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View cv, ViewGroup parent) { return row(shown.get(i)); }
        };
        list.setAdapter(ad);
        root.addView(list, new LinearLayout.LayoutParams(-1, 0, 1f));

        setContentView(root);

        new Thread(new Runnable() {
            @Override public void run() {
                final List<Apps.App> l = Apps.load(DataActivity.this);
                final List<Apps.App> u = new ArrayList<Apps.App>();
                Set<String> seen = new HashSet<String>();
                for (Apps.App a : l) {
                    if (a.pkg.equals(getPackageName())) continue;
                    if (seen.add(a.pkg)) u.add(a);
                }
                runOnUiThread(new Runnable() {
                    @Override public void run() {
                        all.clear();
                        all.addAll(u);
                        spin.setVisibility(View.GONE);
                        refilter();
                    }
                });
            }
        }).start();

        if (getIntent().getBooleanExtra("enable", false) && !master.isChecked()) master.setChecked(true);
    }

    private TextView chip(String s, final Runnable r) {
        TextView t = Ui.text(this, s, 12.5f, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setPadding(Ui.dp(this, 12), Ui.dp(this, 9), Ui.dp(this, 12), Ui.dp(this, 9));
        t.setBackground(Ui.glass(this, 18, 0x44662CC8, 0x889B5CFF));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(0, 0, Ui.dp(this, 8), 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { r.run(); }
        });
        return t;
    }

    private void refilter() {
        String q = filter.getText().toString().trim().toLowerCase();
        shown.clear();
        for (Apps.App a : all) {
            if (q.isEmpty() || a.label.toLowerCase().contains(q)) shown.add(a);
        }
        ad.notifyDataSetChanged();
    }

    private void enable() {
        Prefs.sp(this).edit().putBoolean(Prefs.FW_ON, true).apply();
        FirewallService.start(this);
    }

    private void changed() {
        ad.notifyDataSetChanged();
        if (Prefs.bool(this, Prefs.FW_ON, false)) {
            h.removeCallbacks(applyR);
            h.postDelayed(applyR, 500);
        }
    }

    private final Runnable applyR = new Runnable() {
        @Override public void run() { FirewallService.start(DataActivity.this); }
    };

    @Override
    protected void onActivityResult(int req, int res, Intent d) {
        super.onActivityResult(req, res, d);
        if (req == 77) {
            if (res == RESULT_OK) {
                enable();
            } else {
                silent = true;
                master.setChecked(false);
                silent = false;
                Toast.makeText(this, "Autorisation VPN refusée", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private View row(final Apps.App a) {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 12), Ui.dp(this, 6));
        ImageView iv = new ImageView(this);
        iv.setImageBitmap(a.bmp);
        r.addView(iv, new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 46)));
        TextView t = Ui.text(this, a.label, 15, Color.WHITE, false);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
        tp.setMargins(Ui.dp(this, 12), 0, Ui.dp(this, 8), 0);
        r.addView(t, tp);
        r.addView(netChip(a.pkg, Prefs.BLOCK_WIFI, "Wi-Fi"));
        r.addView(netChip(a.pkg, Prefs.BLOCK_MOB, "Mobile"));
        return r;
    }

    private TextView netChip(final String pkg, final String key, final String label) {
        final TextView t = new TextView(this);
        style(t, pkg, key, label);
        t.setGravity(Gravity.CENTER);
        t.setTextSize(12);
        t.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        t.setPadding(Ui.dp(this, 10), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 74), -2);
        lp.setMargins(Ui.dp(this, 4), 0, 0, 0);
        t.setLayoutParams(lp);
        t.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Prefs.toggle(DataActivity.this, key, pkg);
                style(t, pkg, key, label);
                changed();
            }
        });
        return t;
    }

    private void style(TextView t, String pkg, String key, String label) {
        boolean blocked = Prefs.getSet(this, key).contains(pkg);
        t.setText(label + (blocked ? " ✕" : " ✓"));
        t.setTextColor(blocked ? 0xFFFFB4C8 : Color.WHITE);
        t.setBackground(blocked
                ? Ui.glass(this, 16, 0x33401020, 0x99FF6E96)
                : Ui.grad(this, 16, 0xFFA45CFF, 0xFF5A1FE0, 0xAAF3E6FF));
    }
}
