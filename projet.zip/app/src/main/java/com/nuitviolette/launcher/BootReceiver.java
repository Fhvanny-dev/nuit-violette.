package com.nuitviolette.launcher;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;

public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())
                && Prefs.bool(c, Prefs.FW_ON, false)
                && VpnService.prepare(c) == null) {
            FirewallService.start(c);
        }
    }
}
