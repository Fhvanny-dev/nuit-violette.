package com.nuitviolette.launcher;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.MotionEvent;
import android.view.View;

/** Pictogrammes nets du lecteur de musique (image 3), dessinés à la main : pas d'emoji, pas de police. */
final class Glyph extends View {
    static final int PREV = 0, NEXT = 1, PAUSE = 2, PLAY = 3, CLOSE = 4, CAST = 5;

    private int kind;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();

    Glyph(Context c, int kind) { super(c); this.kind = kind; }

    void setKind(int k) { if (k != kind) { kind = k; invalidate(); } }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float s = Math.min(w, h);
        float cx = w / 2f, cy = h / 2f;
        p.setShader(new LinearGradient(0, 0, 0, h, 0xFFFFFFFF, 0xFFD9C3FF, Shader.TileMode.CLAMP));
        p.setPathEffect(new android.graphics.CornerPathEffect(s * 0.07f));
        p.setStyle(Paint.Style.FILL);
        switch (kind) {
            case PREV:
            case NEXT: {
                float dir = kind == NEXT ? 1f : -1f;
                float tw = s * 0.30f, th = s * 0.30f;
                for (int i = 0; i < 2; i++) {
                    float baseX = cx - dir * tw + dir * i * tw;
                    float tipX = baseX + dir * tw;
                    path.reset();
                    path.moveTo(baseX, cy - th);
                    path.lineTo(tipX, cy);
                    path.lineTo(baseX, cy + th);
                    path.close();
                    c.drawPath(path, p);
                }
                break;
            }
            case PAUSE: {
                float bw = s * 0.16f, bh = s * 0.42f, gap = s * 0.10f;
                RectF r = new RectF();
                r.set(cx - gap - bw, cy - bh, cx - gap, cy + bh);
                c.drawRoundRect(r, bw * 0.3f, bw * 0.3f, p);
                r.set(cx + gap, cy - bh, cx + gap + bw, cy + bh);
                c.drawRoundRect(r, bw * 0.3f, bw * 0.3f, p);
                break;
            }
            case PLAY: {
                float tw = s * 0.34f, th = s * 0.40f;
                path.reset();
                path.moveTo(cx - tw * 0.8f, cy - th);
                path.lineTo(cx + tw * 1.2f, cy);
                path.lineTo(cx - tw * 0.8f, cy + th);
                path.close();
                c.drawPath(path, p);
                break;
            }
            case CLOSE: {
                p.setPathEffect(null);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(s * 0.06f);
                float k = s * 0.24f;
                c.drawLine(cx - k, cy - k, cx + k, cy + k, p);
                c.drawLine(cx + k, cy - k, cx - k, cy + k, p);
                break;
            }
            case CAST: {
                // ondes concentriques + triangle (icône « diffuser »)
                p.setPathEffect(null);
                p.setShader(null);
                p.setStyle(Paint.Style.STROKE);
                p.setStrokeCap(Paint.Cap.ROUND);
                p.setStrokeWidth(s * 0.07f);
                p.setColor(0xFFB48CFF);
                RectF a = new RectF();
                float oy = cy - s * 0.04f;
                float r1 = s * 0.40f, r2 = s * 0.27f, r3 = s * 0.14f;
                a.set(cx - r1, oy - r1, cx + r1, oy + r1); c.drawArc(a, 150, 240, false, p);
                a.set(cx - r2, oy - r2, cx + r2, oy + r2); c.drawArc(a, 150, 240, false, p);
                a.set(cx - r3, oy - r3, cx + r3, oy + r3); c.drawArc(a, 150, 240, false, p);
                p.setStyle(Paint.Style.FILL);
                path.reset();
                path.moveTo(cx, oy + s * 0.05f);
                path.lineTo(cx + s * 0.22f, oy + s * 0.38f);
                path.lineTo(cx - s * 0.22f, oy + s * 0.38f);
                path.close();
                c.drawPath(path, p);
                break;
            }
            default:
        }
        p.setStrokeCap(Paint.Cap.BUTT);
        p.setPathEffect(null);
    }
}


/** Fond du lecteur (maquette image 2) : verre violet très sombre, bordure claire + lueur rose-violet. */
final class GlassDrawable extends android.graphics.drawable.Drawable {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final float radius, d;

    GlassDrawable(Context c, float radiusDp) {
        d = c.getResources().getDisplayMetrics().density;
        radius = radiusDp * d;
    }

    @Override public void draw(Canvas c) {
        float w = getBounds().width(), h = getBounds().height();
        float g = 5f * d;
        // lueur extérieure en 3 couches
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        int[] ga = {0x1A, 0x33, 0x55};
        float[] gw = {7f, 4.5f, 2.5f};
        for (int i = 0; i < 3; i++) {
            p.setStrokeWidth(gw[i] * d);
            p.setColor((ga[i] << 24) | 0xC040FF);
            r.set(g, g, w - g, h - g);
            c.drawRoundRect(r, radius, radius, p);
        }
        // corps
        r.set(g, g, w - g, h - g);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, w, 0, new int[]{0xF03A0E90, 0xF01E0558, 0xF02A0A6E}, null, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, radius, radius, p);
        // reflet doux en haut
        p.setShader(new LinearGradient(0, g, 0, h * 0.55f, 0x2EFFFFFF, 0x00FFFFFF, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, radius, radius, p);
        // bordure : rose-violet vif, plus claire en haut
        p.setShader(new LinearGradient(0, g, 0, h - g, new int[]{0xFFEBC8FF, 0xFFB45CFF, 0xFFF04CFF}, null, Shader.TileMode.CLAMP));
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.8f * d);
        c.drawRoundRect(r, radius, radius, p);
        p.setShader(null);
        p.setStrokeWidth(0.8f * d);
        p.setColor(0x99FFFFFF);
        r.inset(1.6f * d, 1.6f * d);
        c.drawRoundRect(r, radius - 1.6f * d, radius - 1.6f * d, p);
    }
    @Override public void setAlpha(int a) { }
    @Override public void setColorFilter(android.graphics.ColorFilter f) { }
    @Override public int getOpacity() { return android.graphics.PixelFormat.TRANSLUCENT; }
}

/** Barre de lecture de la maquette : piste claire, remplissage rose-violet, bille brillante. Tactile. */
final class MusicBar extends View {
    interface OnSeek { void to(float frac); }

    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private float frac;
    private boolean drag;
    private OnSeek cb;

    MusicBar(Context c) { super(c); }

    void setOnSeek(OnSeek c) { cb = c; }
    boolean isDragging() { return drag; }
    void setFrac(float f) { if (!drag) { frac = Math.max(0f, Math.min(1f, f)); invalidate(); } }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), d = getResources().getDisplayMetrics().density;
        float th = 4f * d, kr = 6.5f * d, cy = h / 2f;
        float x0 = kr, x1 = w - kr, kx = x0 + (x1 - x0) * frac;
        p.setShader(null);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x44FFFFFF);
        r.set(x0, cy - th / 2f, x1, cy + th / 2f);
        c.drawRoundRect(r, th / 2f, th / 2f, p);
        p.setShader(new LinearGradient(x0, 0, Math.max(x0 + 1, kx), 0, 0xFFC03CFF, 0xFFE87CFF, Shader.TileMode.CLAMP));
        r.set(x0, cy - th / 2f, kx, cy + th / 2f);
        c.drawRoundRect(r, th / 2f, th / 2f, p);
        p.setShader(new RadialGradient(kx - kr * 0.3f, cy - kr * 0.3f, kr * 1.3f, 0xFFFFFFFF, 0xFFB890F0, Shader.TileMode.CLAMP));
        c.drawCircle(kx, cy, kr, p);
        p.setShader(null);
    }

    @Override public boolean onTouchEvent(MotionEvent e) {
        float kr = 6.5f * getResources().getDisplayMetrics().density;
        float f = Math.max(0f, Math.min(1f, (e.getX() - kr) / Math.max(1f, getWidth() - 2 * kr)));
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                drag = true;
                if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
                frac = f; invalidate(); return true;
            case MotionEvent.ACTION_MOVE:
                frac = f; invalidate(); return true;
            case MotionEvent.ACTION_UP:
                drag = false; frac = f; invalidate();
                if (cb != null) cb.to(f);
                return true;
            case MotionEvent.ACTION_CANCEL:
                drag = false; return true;
            default: return true;
        }
    }
}
